# TUTORIAL - MathBot dengan Penjelasan Jawaban

Dokumen ini menjelaskan cara menjalankan project dan cara kerja fitur penjelasan saat anak salah.

## 1. Apa yang berubah dari versi sebelumnya

| File | Perubahan |
|------|-----------|
| `src/Explain.h` | BARU. Berisi 600 penjelasan, satu untuk tiap soal. |
| `src/Types.h` | `Question` punya field baru `ex` (teks penjelasan). |
| `src/SoalBank.h` | Menambahkan `#include "Explain.h"` di bagian akhir. |
| `src/main.ino` | Soal membawa penjelasannya (`q.ex`). Fungsi baru `drawExplainCard()` dan `showExplanation()`. `handleAnswer()` dan `timeUp()` memanggilnya. |
| `src/Tts.h` | Tanda `>` dan `<` ikut dibacakan ("lebih besar dari", "lebih kecil dari"). |
| `tools/make_explain.py` | BARU. Pembuat `Explain.h` dari bank soal. |

Tidak ada library baru dan tidak ada API key.

## 2. Alur saat anak menjawab

1. **Benar:** robot berjoget, confetti, pujian (seperti sebelumnya).
2. **Salah pertama:** robot sedih, lalu muncul **petunjuk** (`clue`) dan anak boleh mencoba lagi (seperti sebelumnya).
3. **Salah kedua:** pilihan yang benar menyala hijau, lalu muncul **kartu penjelasan** di layar. MathBot juga membacakan:
   "Jawabanmu belum tepat. Yuk lihat caranya." diikuti penjelasannya.
   Sentuh layar untuk melewati bacaan dan lanjut ke soal berikutnya.
4. **Waktu habis:** sama seperti nomor 3, dibuka dengan "Waktu habis! Yuk lihat caranya."

Bila WiFi mati atau suara dimatikan, kartu tetap tampil beberapa detik sesuai panjang teks, jadi anak tetap bisa membacanya.

## 3. Menjalankan project

1. Pasang **VSCode** dan ekstensi **PlatformIO IDE**.
2. Ekstrak zip, lalu `File > Open Folder` ke folder `MathBot_ESP32S3_PIO`. Tunggu PlatformIO mengunduh platform dan library (pertama kali agak lama).
3. Buka `src/Tts.h`, isi `WIFI_SSID` dan `WIFI_PASS` (WiFi 2.4 GHz). WiFi hanya dipakai agar soal dan penjelasan **dibacakan**. Penjelasan tertulis di layar tetap muncul tanpa WiFi.
4. Colokkan ESP32-S3, lalu klik **Build** (centang), **Upload** (panah), dan **Serial Monitor** (colokan) di bar bawah VSCode.
   Lewat terminal: `pio run`, `pio run -t upload`, `pio device monitor`.
5. Pilih kelas, pilih materi, lalu mulai kuis.

## 4. Cara mengetes cepat fitur penjelasan

1. Mulai kuis materi apa saja.
2. Jawab salah satu soal **dua kali** dengan pilihan yang berbeda (tombol A/B/C/D, sentuh layar, atau ucapkan A/B/C/D lewat mic).
3. Kartu "MathBot menjelaskan" harus muncul dan dibacakan.
4. Untuk tes waktu habis: biarkan soal tidak dijawab sampai timer habis (25 detik, bisa diubah di `Q_TIME_MS`).

## 5. Cara mengubah penjelasan

Buka `src/Explain.h`. Isinya larik teks yang urutannya sama dengan bank soal:

```
const char *const EXPL_E0[BANK_N] = {   // E = Kelas 1-2, M = Kelas 3-4, H = Kelas 5-6
"penjelasan untuk soal ke-1 di BANK_E0",
"penjelasan untuk soal ke-2 di BANK_E0",
...
```

- Huruf: **E** = Kelas 1-2, **M** = Kelas 3-4, **H** = Kelas 5-6.
- Angka: **0** = Bilangan Seru, **1** = Tantangan Berhitung, **2** = Detektif Bentuk, **3** = Misi Pengukuran.
- Jadi `EXPL_M2[9]` = penjelasan soal ke-10 materi Detektif Bentuk kelas 3-4.
- Jangan memakai tanda kutip ganda (`"`) di dalam teks. Pakai tanda kutip tunggal (`'`).
- Usahakan di bawah 170 huruf agar tampil dengan huruf besar di layar. Di atas itu hurufnya otomatis mengecil.
- Tulis simbol dengan spasi (`3 x 4 = 12`) supaya dibacakan benar: x = kali, + = tambah, - = kurang, = = sama dengan, : = dibagi.

Jangan menambah atau menghapus baris. Setiap larik harus tetap berisi tepat 50 teks (`BANK_N`).

## 6. Cara kerja pembuat otomatis (`tools/make_explain.py`)

Penjelasan dibuat dari bank soal yang sudah ada:

- **Soal hitungan** (tambah, kurang, kali, bagi, keliling, luas, dst.): hitungan ditulis langkah demi langkah, mis. `15 - 6 = 9`. Hasilnya **diperiksa otomatis** terhadap kunci jawaban. Bila tidak cocok, hitungan tidak dipakai.
- **Soal bertahap** yang petunjuknya hanya setengah jalan: sebagian dilengkapi otomatis, sisanya (53 soal) ditulis tangan di dalam skrip (`OVERRIDE`).
- **Soal konsep** (bentuk, pola, perbandingan, satuan): memakai petunjuk soal lalu kalimat "Jadi jawaban yang benar adalah ...".

Untuk membuat ulang (misal setelah mengganti bank soal):

```
python3 tools/make_explain.py
```

PERINGATAN: perintah ini menimpa `src/Explain.h`, termasuk edit tangan Anda. Simpan salinan dulu.

## 7. Pemecahan masalah

| Gejala | Penyebab / solusi |
|--------|-------------------|
| Error build: `EXPL_PTR was not declared` | `Explain.h` tidak ikut ter-include. Pastikan baris `#include "Explain.h"` ada di akhir `SoalBank.h`. |
| Error build: jumlah elemen larik | Satu larik di `Explain.h` tidak berisi tepat 50 teks. |
| Kartu muncul tapi tidak ada suara | WiFi belum tersambung atau `TTS_ENABLED` = 0. Cek `WIFI_SSID`/`WIFI_PASS` dan pesan di Serial Monitor. |
| Penjelasan terlalu cepat hilang | Sentuh layar akan melewati bacaan. Jangan menyentuh layar saat kartu tampil bila ingin membaca penuh. |
| Teks terpotong di kartu | Teks terlalu panjang. Persingkat penjelasan itu di `Explain.h`. |
