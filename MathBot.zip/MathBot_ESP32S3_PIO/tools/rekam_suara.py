
"""Rekam data latihan huruf A/B/C/D dari mic ESP32 (STT_MODE 3 di SttConfig.h).

Pakai:   pip install pyserial
         python tools/rekam_suara.py COM4            (hasil: folder dataset/)
         python tools/rekam_suara.py COM4 dataset 50  (50 contoh per huruf)

Tiap contoh disimpan sebagai WAV 1 detik, 16 kHz, nama  huruf.001.wav  -> bisa langsung di-upload ke
Edge Impulse (Data acquisition > Upload data > "Infer from filename").
"""
import os, struct, sys, wave

MAGIC = b"MBREC"
WIN = 16000
BAUD = 921600

def plan(per):
    return [
        ("a", per, "ucapkan  A   (a)"),
        ("b", per, "ucapkan  B   (be)"),
        ("c", per, "ucapkan  C   (ce)"),
        ("d", per, "ucapkan  D   (de)"),
        ("unknown", per * 2, "ucapkan KATA PENDEK LAIN (ya, tidak, halo, e, i, u, satu...) atau batuk / ketuk meja"),
    ]

def read_frame(ser):
    """Tunggu satu rekaman dari ESP32. Teks log lain di antaranya diabaikan."""
    while True:
        data = ser.read_until(MAGIC)
        if not data.endswith(MAGIC):
            continue
        head = ser.read(4)
        if len(head) < 4:
            continue
        (n,) = struct.unpack("<I", head)
        if n != WIN:
            continue
        raw = ser.read(n * 2)
        if len(raw) == n * 2:
            return raw

def save_wav(path, raw):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes(raw)

def main(argv, ser=None):
    if len(argv) < 2 and ser is None:
        print(__doc__)
        return 1
    out = argv[2] if len(argv) > 2 else "dataset"
    per = int(argv[3]) if len(argv) > 3 else 40
    os.makedirs(out, exist_ok=True)
    if ser is None:
        import serial
        ser = serial.Serial(argv[1], BAUD, timeout=2)
    print("Tunggu ~30 detik setelah ESP32 menyala sampai mic siap. Ctrl+C untuk berhenti.\n")
    for label, count, how in plan(per):
        have = len([f for f in os.listdir(out) if f.startswith(label + ".")])
        print(f"=== {label.upper()}: {how}  (sudah ada {have}, target {count})")
        i = have
        while i < count:
            raw = read_frame(ser)
            i += 1
            path = os.path.join(out, f"{label}.{i:03d}.wav")
            save_wav(path, raw)
            print(f"  [{i}/{count}] tersimpan {path}")
        print()
    print("Selesai. Upload semua file di folder", out, "ke Edge Impulse.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv))
    except KeyboardInterrupt:
        print("\nDihentikan. File yang sudah tersimpan tetap ada.")
