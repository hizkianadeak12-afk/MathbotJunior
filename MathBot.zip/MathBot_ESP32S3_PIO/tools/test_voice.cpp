#include "../src/Voice.h"
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>

static int16_t buf[VG_CAP_SAMPLES];
static unsigned rng = 12345;
static float rnd() { rng = rng * 1664525u + 1013904223u; return ((rng >> 8) & 0xFFFF) / 32768.0f - 1.0f; }

struct Res { int speech=0, utt=0, rej=0; size_t len=0; };

struct Seg { int ms; float amp; int kind; };

Res run(const std::vector<Seg>& segs, float noiseRms = 40) {
  VoiceGate g; g.begin(buf);
  Res r; float ph = 0;

  std::vector<Seg> all; all.push_back({1500, 0, 0});
  for (auto&s: segs) all.push_back(s);
  all.push_back({1500, 0, 0});
  for (auto& s : all) {
    int blocks = s.ms / VG_BLOCK_MS;
    for (int b = 0; b < blocks; b++) {
      int32_t raw[VG_BLOCK];
      for (int i = 0; i < VG_BLOCK; i++) {
        float v = rnd() * noiseRms * 1.7f;
        if (s.kind == 1) { ph += 0.35f; v += sinf(ph) * s.amp * 1.414f * (0.6f + 0.4f * sinf(ph * 0.02f)); }
        if (s.kind == 2) { float t = (b * VG_BLOCK + i) / 16000.0f; v += rnd() * s.amp * 3.0f * expf(-t * 60.0f); }
        raw[i] = ((int32_t)v) << 14;
      }
      auto ev = g.feedRaw(raw, false);
      if (ev == VoiceGate::EV_SPEECH) r.speech++;
      if (ev == VoiceGate::EV_UTTERANCE) { r.utt++; r.len = g.length(); }
      if (ev == VoiceGate::EV_REJECTED) r.rej++;
    }
  }
  return r;
}

int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while(0)

int main() {

  { auto r = run({}); CHECK(r.utt == 0 && r.speech == 0, "diam saja -> tidak ada kejadian"); }
  { auto r = run({{400, 900, 1}}); printf("   utt=%d len=%zu ms\n", r.utt, r.len * 1000 / 16000);
    CHECK(r.utt == 1 && r.speech == 1, "huruf 400 ms (rms 900) -> 1 ucapan");
    CHECK(r.len > 16000 * 0.4 && r.len < 16000 * 1.1, "panjang rekaman masuk akal"); }
  { auto r = run({{400, 300, 1}}); CHECK(r.utt == 1, "huruf pelan (rms 300) -> tetap terdeteksi"); }
  { auto r = run({{400, 100, 1}}); CHECK(r.utt == 0, "bisikan sangat pelan (rms 100) -> diabaikan"); }
  { auto r = run({{40, 9000, 2}}); printf("   utt=%d rej=%d\n", r.utt, r.rej); CHECK(r.utt == 0, "tepuk tangan -> TIDAK lolos"); }
  { auto r = run({{20, 20000, 1}}); CHECK(r.utt == 0, "ketukan/klik singkat -> TIDAK lolos"); }
  { auto r = run({{2500, 900, 1}}); CHECK(r.utt == 0 && r.rej >= 1, "bicara/musik 2,5 detik -> TIDAK lolos"); }
  { auto r = run({{250, 900, 1}, {100, 0, 0}, {250, 900, 1}}); CHECK(r.utt == 1, "huruf dengan jeda 100 ms di tengah -> 1 ucapan"); }
  { auto r = run({{300, 900, 1}, {1200, 0, 0}, {300, 900, 1}}); CHECK(r.utt == 2, "dua huruf terpisah jeda 1,2 s -> 2 ucapan"); }
  {
    VoiceGate g; g.begin(buf); int utt = 0; float ph = 0;
    for (int b = 0; b < 8000/8 ; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++){ph+=0.3f; raw[i]=((int32_t)(sinf(ph)*700+rnd()*300))<<14;} if (g.feedRaw(raw,false)==VoiceGate::EV_UTTERANCE) utt++; }
    for (int b = 0; b < 1500/8 ; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++) raw[i]=((int32_t)(rnd()*40))<<14; g.feedRaw(raw,false); }
    int utt2 = 0; ph = 0;
    for (int b = 0; b < 400/8 ; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++){ph+=0.35f; raw[i]=((int32_t)(sinf(ph)*900*1.414f+rnd()*60))<<14;} g.feedRaw(raw,false); }
    for (int b = 0; b < 1000/8 ; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++) raw[i]=((int32_t)(rnd()*40))<<14; if (g.feedRaw(raw,false)==VoiceGate::EV_UTTERANCE) utt2++; }
    CHECK(utt == 0 && utt2 == 1, "TV keras 8 s tidak lolos, setelah hening huruf berikutnya tetap terdeteksi"); }
  { VoiceGate g; g.begin(buf); int utt = 0; float ph=0;
    for (int b = 0; b < 1500/8; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++) raw[i]=((int32_t)(rnd()*40))<<14; g.feedRaw(raw,false);}
    for (int b = 0; b < 400/8; b++) { int32_t raw[VG_BLOCK]; for (int i=0;i<VG_BLOCK;i++){ph+=0.35f; raw[i]=((int32_t)(sinf(ph)*1200))<<14;} if (g.feedRaw(raw,true)==VoiceGate::EV_UTTERANCE) utt++; }
    CHECK(utt == 0, "deaf=true -> ucapan di masa tuli tidak dihitung"); }

  { static int16_t w[VG_CAP_SAMPLES];
    for (int i=0;i<VG_CAP_SAMPLES;i++) w[i]=0;
    size_t n=9000; for (size_t i=0;i<n;i++) w[i] = (i<1280)? (int16_t)(20*((i%7)-3)) : (int16_t)(3000*sinf(i*0.2f));
    vgMakeWindow(w, n);
    int pad=0; for(int i=0;i<3000;i++) if (w[i]!=0) pad++;
    CHECK(pad>1000, "jendela: sisi kiri diisi suara latar (bukan nol)");
    int mid=0; for(int i=3500+2000;i<3500+4000;i++) if (abs(w[i])>1000) mid++;
    CHECK(mid>500, "jendela: ucapan ada di tengah");
    vgNormalize16(w, STT_WIN); int pk=0; for(int i=0;i<STT_WIN;i++) if (abs(w[i])>pk) pk=abs(w[i]);
    CHECK(pk>=21000 && pk<=23000, "normalisasi: puncak ~22000"); }
  { static int16_t w[VG_CAP_SAMPLES]; size_t n=17500; for (size_t i=0;i<n;i++) w[i]=(int16_t)(i%1000);
    vgMakeWindow(w, n); CHECK(w[0]==(int16_t)((17500-16000)%1000) && w[15999]==(int16_t)(17499%1000), "jendela: terlalu panjang -> buang bagian depan"); }

  struct T { const char *json; int want; const char *name; };
  T tests[] = {
    { "{\"text\":\"a\",\"is_final\":true}", 1, "a" },
    { "{\"text\":\"b\",\"is_final\":false}\r\n{\"text\":\"be\",\"is_final\":true,\"speech\":{\"tokens\":[{\"token\":\"be\"}]}}", 2, "be (objek terakhir dipakai)" },
    { "{\"text\":\"Ce.\"}", 3, "Ce." },
    { "{\"text\": \"D\"}", 4, "D dengan spasi JSON" },
    { "{\"text\":\"b\\u00e9\"}", 2, "bé escape unicode" },
    { "{\"text\":\"bé\"}", 2, "bé utf-8" },
    { "{\"text\":\"huruf c\"}", 3, "huruf c" },
    { "{\"text\":\"pilihan B\"}", 2, "pilihan B" },
    { "{\"text\":\"halo selamat pagi\"}", 0, "kalimat lain" },
    { "{\"text\":\"a b\"}", 0, "dua huruf sekaligus (ambigu)" },
    { "{\"text\":\"\"}", 0, "kosong" },
    { "{\"text\":\"abc\"}", 0, "abc" },
    { "{\"text\":\"dia\"}", 0, "dia" },
    { "{\"text\":\"di rumah\"}", 0, "di rumah" },
    { "{\"error\":\"x\"}", 0, "tanpa text" },
  };
  for (auto &t : tests) {
    char txt[96]; int got = 0;
    if (sttExtractText(t.json, txt, sizeof(txt))) got = sttLetterFromText(txt);
    char m[160]; snprintf(m, sizeof(m), "parser: %s -> %d", t.name, t.want);
    CHECK(got == t.want, m);
  }
  printf("\n%s (%d gagal)\n", fails ? "ADA YANG GAGAL" : "SEMUA LULUS", fails);
  return fails ? 1 : 0;
}
