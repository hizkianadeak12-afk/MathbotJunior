

import re, os, sys
from fractions import Fraction

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = []
for lv, f in enumerate(['bank_easy.h', 'bank_medium.h', 'bank_hard.h']):
    t = open(os.path.join(ROOT, 'src', f), encoding='utf-8').read()
    parts = re.split(r'^const SoalItem BANK_\w+\[BANK_N\] = \{', t, flags=re.M)[1:]
    assert len(parts) == 4, f
    for tp, part in enumerate(parts):
        items = re.findall(r'^S\("(.*)", "(.*?)", "(.*?)", "(.*?)", "(.*?)", "(.*?)"\),?\s*$', part, re.M)
        assert len(items) == 50, (f, tp, len(items))
        for ix, it in enumerate(items): rows.append((lv, tp, ix) + it)

OVERRIDE = {
    (0, 0, 28): '37 = 30 + 7. Angka 3 ada di tempat puluhan dan angka 7 di tempat satuan. Jadi 3 puluhan dan 7 satuan.',
    (0, 1, 21): 'Susun 47 dan 38. Satuan: 7 + 8 = 15, tulis 5 dan simpan 1 puluhan. Puluhan: 4 + 3 + 1 = 8. Hasilnya 85 kue.',
    (0, 1, 22): 'Susun 56 dan 27. Satuan: 6 + 7 = 13, tulis 3 dan simpan 1 puluhan. Puluhan: 5 + 2 + 1 = 8. Hasilnya 83 bangau.',
    (0, 1, 34): '3 x 6 = 6 + 6 + 6 = 18. 3 x 9 = 9 + 9 + 9 = 27. Jadi jawabannya 18 dan 27.',
    (1, 0, 31): 'Bilangan prima hanya bisa dibagi 1 dan dirinya sendiri. 27 = 3 x 9, jadi 27 bukan bilangan prima. 29 adalah bilangan prima.',
    (1, 1, 20): 'Bagi 250 : 8. Karena 8 x 31 = 248, tiap anak dapat 31 permen. Sisanya 250 - 248 = 2 permen.',
    (1, 2, 23): 'Keliling persegi panjang = 2 x (p + l). 2 x (12 + 7) = 2 x 19 = 38 cm.',
    (1, 2, 25): 'Pagar mengelilingi halaman, jadi hitung keliling. 2 x (20 + 12) = 2 x 32 = 64 m.',
    (1, 2, 27): 'Lis dipasang di tepi papan, jadi hitung keliling. 2 x (25 + 15) = 2 x 40 = 80 cm.',
    (1, 3, 1): '450 cm = 400 cm + 50 cm. 400 cm = 4 m. Jadi 4 m 50 cm.',
    (1, 3, 7): 'Jumlahkan cm dulu: 40 + 70 = 110 cm = 1 m 10 cm. Lalu meter: 8 + 3 = 11 m, tambah 1 m menjadi 12 m. Hasilnya 12 m 10 cm.',
    (1, 3, 13): '750 x 2 = 1.500 g. 1.000 g = 1 kg, sisanya 500 g. Jadi 1 kg 500 g.',
    (1, 3, 18): 'Pukul 21.00 sampai 24.00 = 3 jam. Pukul 24.00 sampai 05.30 = 5 jam 30 menit. Totalnya 8 jam 30 menit.',
    (1, 3, 20): '45 x 3 = 135 menit. 120 menit = 2 jam, sisanya 15 menit. Jadi 2 jam 15 menit.',
    (1, 3, 24): '30 x 6 = 180 menit. 180 : 60 = 3 jam.',
    (1, 3, 42): '1 liter 250 ml = 1.250 ml. 750 + 1.250 = 2.000 ml. 1.000 ml = 1 liter, jadi 2 liter.',
    (1, 3, 48): '5 x 600 = 3.000 ml. 1.000 ml = 1 liter, jadi 3 liter.',
    (2, 0, 20): '0,6 sama dengan 0,60. Bandingkan 0,60 dan 0,58: 60 lebih besar dari 58. Jadi Stella punya air lebih banyak.',
    (2, 0, 21): '0,5 = 50%. Bandingkan 45% dan 50%: 50% lebih besar. Jadi Mentari menghabiskan lebih banyak.',
    (2, 0, 25): '0,5 = 50%. Bandingkan 50% dan 5%: 0,5 lebih besar. Selisihnya 50% - 5% = 45%.',
    (2, 0, 28): '12 = 2 x 2 x 3, 15 = 3 x 5, 20 = 2 x 2 x 5. KPK = 2 x 2 x 3 x 5 = 60.',
    (2, 0, 31): 'KPK 12, 18, 20 = 180 menit. 180 menit = 3 jam. Pukul 06.00 ditambah 3 jam = pukul 09.00.',
    (2, 0, 36): '4 kuadrat = 4 x 4 = 16 dan 3 kuadrat = 3 x 3 = 9. 16 + 9 = 25. Akar kuadrat 25 adalah 5, karena 5 x 5 = 25.',
    (2, 0, 37): '10 kuadrat = 100 dan 6 kuadrat = 36. 100 - 36 = 64. Akar kuadrat 64 adalah 8, karena 8 x 8 = 64.',
    (2, 0, 47): '3 + 4 = 7 bagian. 28 : 7 = 4 per bagian. Armando 3 x 4 = 12 dan Christopher 4 x 4 = 16.',
    (2, 0, 49): '4 + 5 = 9 bagian. 36 : 9 = 4 per bagian. Stella 4 x 4 = 16 dan Ivana 5 x 4 = 20.',
    (2, 1, 32): 'Yang belum dibaca = 100% - 35% = 65%. 65% x 240 = 156 halaman.',
    (2, 1, 42): '4 + 5 = 9 bagian. 90.000 : 9 = 10.000 per bagian. Rose 4 x 10.000 = 40.000 dan Mentari 5 x 10.000 = 50.000.',
    (2, 1, 45): '3 x 45.000 = 135.000. Diskon 20% x 135.000 = 27.000. Bayar 135.000 - 27.000 = 108.000. Kembalian 150.000 - 108.000 = 42.000.',
    (2, 2, 3): 'Luas segitiga = alas x tinggi : 2, jadi tinggi = 2 x luas : alas. 2 x 48 : 12 = 96 : 12 = 8 m.',
    (2, 2, 4): 'Alas = 2 x luas : tinggi. 2 x 35 : 7 = 70 : 7 = 10 cm.',
    (2, 2, 5): 'Luas satu segitiga = 8 x 5 : 2 = 20 cm2. Dua segitiga = 2 x 20 = 40 cm2.',
    (2, 2, 12): 'Diameter 20 cm, jadi jari-jari r = 10 cm. Luas = 3,14 x 10 x 10 = 314 cm2.',
    (2, 2, 16): 'Luas persegi = 6 x 6 = 36 cm2. Luas segitiga juga 36 cm2, jadi luasnya sama.',
    (2, 2, 20): 'Keliling = 2 x pi x r = 2 x 22 per 7 x 14. 22 per 7 x 14 = 44, lalu 2 x 44 = 88 cm.',
    (2, 2, 23): 'Keliling jajargenjang = 2 x (a + b). 2 x (15 + 9) = 2 x 24 = 48 cm.',
    (2, 2, 29): '60 x 30 x 40 = 72.000 cm3. 1.000 cm3 = 1 liter, jadi 72.000 : 1.000 = 72 liter.',
    (2, 2, 33): 'Volume kubus = r x r x r. Karena 8 x 8 x 8 = 512, panjang rusuknya 8 cm.',
    (2, 3, 8): 'Waktu = 45 : 60 jam = 45 menit. Pukul 07.15 ditambah 45 menit = pukul 08.00.',
    (2, 3, 11): '13.20 + 2 jam = 15.20. Lalu tambah 50 menit: 15.20 + 50 menit = pukul 16.10.',
    (2, 3, 13): 'Waktu = 5 : 10 = 0,5 jam. 0,5 jam = 30 menit.',
    (2, 3, 26): '1.440 : 24 = 60 menit. 60 menit = 1 jam.',
    (2, 3, 27): '80 x 40 x 50 = 160.000 cm3. 160.000 : 1.000 = 160 liter.',
    (2, 3, 29): '5 x 3 x 1,2 = 18 m3. 1 m3 = 1.000 liter, jadi 18 x 1.000 = 18.000 liter.',
    (2, 3, 30): '1,5 x 0,8 x 0,5 = 0,6 m3. 0,6 x 1.000 = 600 liter.',
    (2, 3, 32): '5 x 200.000 = 1.000.000 cm. 100.000 cm = 1 km, jadi 1.000.000 : 100.000 = 10 km.',
    (2, 3, 34): '12 x 500.000 = 6.000.000 cm. 6.000.000 : 100.000 = 60 km.',
    (2, 3, 35): '15 km = 1.500.000 cm. Skala = 1.500.000 : 3 = 500.000. Jadi skalanya 1 : 500.000.',
    (2, 3, 36): '12 m = 1.200 cm. 1.200 : 8 = 150. Jadi skalanya 1 : 150.',
    (2, 3, 37): '4 x 250 = 1.000 cm. 100 cm = 1 m, jadi 1.000 : 100 = 10 m.',
    (2, 3, 38): '7,5 x 2.000.000 = 15.000.000 cm. 15.000.000 : 100.000 = 150 km.',
    (2, 3, 45): 'Menit: 45 + 50 = 95 menit = 1 jam 35 menit. Jam: 2 + 1 = 3 jam. Totalnya 4 jam 35 menit.',
    (2, 3, 49): '3 x 400 = 1.200 m. 0,8 km = 800 m. 1.200 + 800 = 2.000 m = 2 km.',
}

def num(tok):
    """'1.470' -> 1470 ; '0,5' -> 0.5 ; return Fraction or None"""
    tok = tok.strip()
    if re.fullmatch(r'\d+', tok): return Fraction(int(tok))
    if re.fullmatch(r'\d{1,3}(\.\d{3})+', tok): return Fraction(int(tok.replace('.', '')))
    if re.fullmatch(r'\d+,\d+', tok):
        a, b = tok.split(','); return Fraction(int(a)) + Fraction(int(b), 10 ** len(b))
    return None

def fmt(v):
    if v.denominator == 1:
        s = f"{int(v):,}".replace(',', '.'); return s

    d = v.denominator
    while d % 2 == 0: d //= 2
    while d % 5 == 0: d //= 5
    if d != 1: return None
    x = float(v); s = f"{x:.6f}".rstrip('0').rstrip('.'); return s.replace('.', ',')

def find_expr(clue):
    best = None
    for m in re.finditer(r'\(?\s*\d[\d.,]*(?:\s*[-+x:]\s*\(?\s*\d[\d.,]*\s*\)?)+', clue):
        s = m.group(0).strip()
        if '/' in clue[max(0,m.start()-1):m.end()+2]: continue
        toks = [t.rstrip('.,') if t[0].isdigit() else t for t in re.findall(r'\d[\d.,]*|[-+x:()]', s)]
        vals = []; ok = True; py = ''
        for t in toks:
            if t in '+-()': py += t
            elif t == 'x': py += '*'
            elif t == ':': py += '/'
            else:
                n = num(t)
                if n is None: ok = False; break
                py += f'Fraction({n.numerator},{n.denominator})'
        if not ok or py.count('(') != py.count(')'): continue
        try: v = eval(py, {'Fraction': Fraction})
        except Exception: continue
        shown = re.sub(r'\s+', ' ', s).rstrip('.,')
        if best is None or len(shown) > len(best[0]): best = (shown, v)
    return best

def nums_in(c):
    out = []
    for t in re.findall(r'\d[\d.,]*\d|\d', c):
        n = num(t.rstrip('.,'))
        if n is not None: out.append(n)
    return out

def q_numbers(text):
    out = []
    for t in re.findall(r'\d[\d.,]*\d|\d', text):
        n = num(t.rstrip('.,'))
        if n is not None and n not in out: out.append(n)
    return out

def clue_ops(clue):
    ops = []
    if ' x ' in clue or clue.startswith('Kali') or 'kali' in clue.lower(): ops.append('x')
    if ' : ' in clue or clue.startswith('Bagi') or 'Bagi' in clue: ops.append(':')
    if ' + ' in clue or clue.startswith(('Tambah', 'Jumlah')): ops.append('+')
    if ' - ' in clue or clue.startswith('Kurang'): ops.append('-')
    return ops

def combo(r):
    """Cari 'a op b = hasil' dari angka di soal (+ angka di clue) yang cocok dengan jawaban & operator di clue."""
    lv, tp, ix, q, c, w1, w2, w3, clue = r
    target = nums_in(c)
    ops = clue_ops(clue)
    if not ops or len(target) != 1: return None
    if '/' in c or '/' in q or '/' in clue: return None
    if '=' in clue and re.search(r'\d', clue): return None
    pool = q_numbers(q)
    for n in q_numbers(clue):
        if n not in pool: pool.append(n)
    if len(pool) > 7: pool = pool[:7]
    cands = []
    for op in ops:
        for a in pool:
            for b in pool:
                if a == b and pool.count(a) == 1 and op in '+-' : pass
                try:
                    v = {'x': a * b, ':': (a / b if b else None), '+': a + b, '-': a - b}[op]
                except Exception: v = None
                if v is None or v not in target: continue
                cands.append((a, op, b, v))

    qn = q_numbers(q)
    cands.sort(key=lambda t: -((t[0] in qn) + (t[2] in qn)))
    if not cands: return None
    a, op, b, v = cands[0]
    if a == b and op in ':-': return None
    if (a not in qn) and (b not in qn): return None
    fa, fb, fv = fmt(a), fmt(b), fmt(v)
    if None in (fa, fb, fv): return None
    return f"{fa} {op} {fb} = {fv}"

def finish(r, clue):
    lv, tp, ix, q, c, w1, w2, w3, clue_ = r
    if '/' in clue or '/' in c or '/' in q: return None
    target = nums_in(c)
    if len(target) != 1: return None
    m = re.findall(r'=\s*(\d[\d.,]*\d|\d)', clue)
    if not m: return None
    v = num(m[-1])
    if v is None or v in target: return None
    pool = [n for n in q_numbers(q) if n != v] + [n for n in q_numbers(clue) if n != v and n not in q_numbers(q)]
    for n in pool:
        for op, f in (('+', lambda a, b: a + b), ('-', lambda a, b: a - b), ('x', lambda a, b: a * b), (':', lambda a, b: a / b if b else None)):
            for a, b in ((v, n), (n, v)):
                try: res = f(a, b)
                except Exception: res = None
                if res is not None and res in target and res > 0:
                    fa, fb, fr = fmt(a), fmt(b), fmt(res)
                    if None in (fa, fb, fr): continue
                    return f"{fa} {op} {fb} = {fr}"
    return None

def sentence(s):
    s = s.strip()
    return s if s[-1:] in '.!?)' else s + '.'

LEAD = [('Kurangkan', 'Ini soal pengurangan.'), ('Tambahkan', 'Ini soal penjumlahan.'), ('Jumlahkan', 'Ini soal penjumlahan.'),
        ('Kali', 'Ini soal perkalian.'), ('Bagi', 'Ini soal pembagian.')]

def explain(r):
    lv, tp, ix, q, c, w1, w2, w3, clue = r
    SYM = {'=': 'sama dengan (=)', '<': 'lebih kecil dari (<)', '>': 'lebih besar dari (>)'}
    cshow = SYM.get(c.strip(), c)
    e = find_expr(clue)
    if e:
        shown, v = e
        f = fmt(v)
        if f is not None and v in nums_in(c) and len(nums_in(c)) == 1:
            lead = next((t for k, t in LEAD if clue.startswith(k)), 'Kita hitung:')
            ex = f"{lead} {shown} = {f}. Jadi jawabannya {c}."
            return ex, True
    cb = combo(r)
    if cb:
        rule = sentence(clue)

        if re.match(r'^(Kurangkan|Tambahkan|Jumlahkan|Kali:|Bagi:)', clue): rule = 'Kita hitung.'
        return f"{rule} {cb}. Jadi jawabannya {c}.", True
    fz = finish(r, clue)
    if fz:
        return f"{sentence(clue)} Lalu {fz}. Jadi jawaban yang benar adalah {cshow}.", True
    if (lv, tp, ix) in OVERRIDE: return OVERRIDE[(lv, tp, ix)], True
    return f"{sentence(clue)} Jadi jawaban yang benar adalah {cshow}.", False

def clean(s): return s.replace('\\', '').replace('"', "'")
exs = {}; ok_n = 0
for r in rows:
    ex, ok = explain(r); ok_n += ok
    exs[(r[0], r[1], r[2])] = clean(ex)
NAMES = ['E', 'M', 'H']
lines = ['// Explain.h - Penjelasan jawaban untuk 600 soal (dibuat oleh tools/make_explain.py, boleh diedit tangan).',
         '// Urutannya SAMA dengan bank soal: EXPL_E0[0] = soal pertama di BANK_E0, dst.',
         '// Dibacakan & ditampilkan saat anak salah dua kali atau waktu habis. Tulis tanpa tanda kutip ganda (").',
         '#pragma once', '']
for lv in range(3):
    for tp in range(4):
        lines.append(f'const char *const EXPL_{NAMES[lv]}{tp}[BANK_N] = {{')
        for ix in range(50): lines.append('"' + exs[(lv, tp, ix)] + '",')
        lines.append('};')
    lines.append('')
lines.append('// EXPL_PTR[jenjang][materi] sejajar dengan BANK_PTR di SoalBank.h')
lines.append('const char *const *const EXPL_PTR[3][4] = {')
for lv in range(3):
    lines.append('  { ' + ', '.join(f'EXPL_{NAMES[lv]}{tp}' for tp in range(4)) + ' },')
lines.append('};')
open(os.path.join(ROOT, 'src', 'Explain.h'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('Explain.h dibuat: 600 penjelasan,', ok_n, 'berisi hitungan terverifikasi,', 600 - ok_n, 'berbasis petunjuk soal.')
print('penjelasan terpanjang:', max(len(v) for v in exs.values()), 'huruf')
