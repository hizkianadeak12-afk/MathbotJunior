#ifndef TYPES_H
#define TYPES_H

#include <Arduino.h>

struct Rect {
    int16_t x;
    int16_t y;
    int16_t w;
    int16_t h;
};

struct Question {
    String sub;
    String q;
    String opt[4];
    String clue;
    String ex;
    uint8_t correct;
};

enum Screen {
    S_LEVEL,
    S_HOME,
    S_MATERI,
    S_QUIZ,
    S_SUMMARY,
    S_GAME,
    S_GMENU
};

#endif
