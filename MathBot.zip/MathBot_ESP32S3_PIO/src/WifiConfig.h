#pragma once

#define TTS_ENABLED   1
#define WIFI_SSID     "NAMA_WIFI_KAMU"
#define WIFI_PASS     "PASSWORD_WIFI"
#define TTS_LANG      "id"
