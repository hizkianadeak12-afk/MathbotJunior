#pragma once
#include "esp_heap_caps.h"

#include "WifiConfig.h"
#define TTS_VOLUME_PCT     40
#define TTS_READ_OPTIONS   1
#define TTS_CHUNK_CHARS    100
#define TTS_MAX_CHUNKS     24
#define TTS_MP3_MAX        36864
#define TTS_PIPELINE       1
#define TTS_RETRY          3
#define TTS_KEEP_TLS       1
#define TTS_FIRST_CHARS    30
#define TTS_IDLE_MS        30000
#define TTS_CACHE          1
#define TTS_CACHE_MAX_CHARS 100
#define TTS_CACHE_MAX_BYTES 900000
#define TTS_PREFETCH       1
#define TTS_PREFETCH_BACKOFF_MS 20000
#define TTS_CACHE_CLEAR    0
#define TTS_RATE_DEFAULT   24000
#define TTS_MAX_FREEZE_MS  30000
#define TTS_COOLDOWN_MS    15000
#define TTS_ERR_SHOW_MS    12000
#define TTS_LISTEN_GAP_MS  300
#define TTS_ECHO_TAIL_MS   100
#define TTS_LIVE_SAVE_MAX  60
#define TTS_DRAIN_MS       (((SPK_DMA_COUNT) * (SPK_DMA_LEN) * 1000) / (TTS_RATE_DEFAULT) + 15)
#ifndef TTS_WIFI_BOOT_WAIT_MS
#define TTS_WIFI_BOOT_WAIT_MS 8000
#endif
#ifndef TTS_WIFI_NOTICE_MS
#define TTS_WIFI_NOTICE_MS    15000
#endif

volatile bool     ttsBusy    = false;
volatile uint32_t ttsStartMs = 0;
volatile bool     ttsConnOpen = false;
volatile bool     ttsFreeReq  = false;
volatile bool     ttsDropReq  = false;
volatile uint32_t ttsErrAt    = 0;
volatile uint32_t ttsErrSeq   = 0;
char              ttsErrMsg[48] = "";
static volatile bool ttsQuiet = false;
static void ttsRepeatErr() { ttsErrAt = millis() ? millis() : 1; ttsErrSeq = ttsErrSeq + 1; }
static void ttsSetErr(const char *m) { if (ttsQuiet) return; strncpy(ttsErrMsg, m, sizeof(ttsErrMsg) - 1); ttsErrMsg[sizeof(ttsErrMsg) - 1] = 0; ttsErrAt = millis() ? millis() : 1; ttsErrSeq = ttsErrSeq + 1; }

#if TTS_ENABLED

static TaskHandle_t      ttsTaskH   = nullptr;
static SemaphoreHandle_t ttsMx      = nullptr;
static String            ttsPending;
static bool              ttsHasPending = false;
static uint32_t          ttsLastRetry  = 0;

static volatile uint8_t  ttsWifiReason = 0;
static uint32_t          ttsDownSince  = 0;
static uint32_t          ttsLastEvLog  = 0;

bool ttsWifiUnset() { return WIFI_SSID[0] == 0 || strcmp(WIFI_SSID, "NAMA_WIFI_KAMU") == 0; }

bool ttsWifiOK() { return WiFi.status() == WL_CONNECTED; }

const char *ttsWifiWhy() {
  if (ttsWifiUnset()) return "nama & password WiFi belum diisi";
  switch (ttsWifiReason) {
    case 201: return "nama WiFi tidak ditemukan (ejaan salah, WiFi 5 GHz, atau terlalu jauh)";
    case 2: case 15: case 202: case 204: return "password salah";
    case 200: return "sinyal terlalu lemah";
    case 203: case 205: return "router menolak sambungan";
    case 0: return "router belum menjawab (cek nama, password, dan WiFi harus 2,4 GHz)";
    default: return "gagal tersambung (cek nama, password, dan WiFi 2,4 GHz)";
  }
}

static void ttsWifiEvent(arduino_event_id_t ev, arduino_event_info_t info) {
  if (ev == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
    ttsDownSince = 0;
    Serial.printf("WiFi: TERSAMBUNG ke \"%s\", IP %s, sinyal %d dBm\n", WIFI_SSID, WiFi.localIP().toString().c_str(), (int)WiFi.RSSI());
  } else if (ev == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
    ttsWifiReason = info.wifi_sta_disconnected.reason;
    if (millis() - ttsLastEvLog > 10000 || !ttsLastEvLog) {
      ttsLastEvLog = millis();
      Serial.printf("WiFi: belum tersambung ke \"%s\" (kode %u: %s)\n", WIFI_SSID, (unsigned)ttsWifiReason, ttsWifiWhy());
    }
  }
}

static bool ttsWifiReady() {
  if (WiFi.status() == WL_CONNECTED) { ttsDownSince = 0; return true; }
  if (!ttsDownSince) ttsDownSince = millis();
  uint32_t waitMs = (millis() < 30000) ? 15000 : (millis() - ttsDownSince < 20000 ? 3000 : 0);
  for (uint32_t w = 0; w < waitMs && WiFi.status() != WL_CONNECTED && !ttsAbort; w += 100) vTaskDelay(pdMS_TO_TICKS(100));
  if (WiFi.status() == WL_CONNECTED) { ttsDownSince = 0; return true; }
  return false;
}

static void ttsLogNoWifi() {
  Serial.printf("TTS: WiFi belum tersambung (%s) - bacaan yang butuh internet dilewati. Isi/cek src/WifiConfig.h\n", ttsWifiWhy());
}

class AudioOutputSpk : public AudioOutput {
 public:
  bool begin() override { n_ = 0; return true; }
  bool SetRate(int hz) override {
    flushBuf();
    i2s_set_clk(SPK_PORT, hz, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO);
    return true;
  }
  bool ConsumeSample(int16_t s[2]) override {
    int32_t v = ((int32_t)s[0] * TTS_VOLUME_PCT) / 100;
    if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
    buf_[n_ * 2] = buf_[n_ * 2 + 1] = (int16_t)v;
    if (++n_ >= BLK) flushBuf();
    return true;
  }
  bool stop() override { flushBuf(); return true; }
 private:
  static const int BLK = 256;
  int16_t buf_[BLK * 2];
  int n_ = 0;
  void flushBuf() {
    if (!n_) return;
    size_t w;
    i2s_write(SPK_PORT, buf_, n_ * 4, &w, portMAX_DELAY);
    n_ = 0;
  }
};

static volatile bool ttsPrefMode   = false;
static volatile bool ttsPrefCancel = false;

static inline bool ttsMicBusy() { return sttBusy || micState == 1 || micState == 2; }
static inline bool ttsStopNow() { return ttsPrefMode ? (ttsPrefCancel || ttsBusy || ttsDropReq || ttsMicBusy()) : (bool)ttsAbort; }

class TtsSink : public Stream {
 public:
  uint8_t *b; size_t cap, n;
  bool full = false;
  TtsSink(uint8_t *buf, size_t c) : b(buf), cap(c), n(0) {}
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  size_t write(uint8_t c) override { return write(&c, 1); }
  size_t write(const uint8_t *p, size_t l) override {
    if (ttsStopNow()) return 0;
    if (n + l > cap) { full = true; return 0; }
    memcpy(b + n, p, l); n += l; return l;
  }
};

static String ttsUrlEncode(const String &s) {
  static const char *hex = "0123456789ABCDEF";
  String o;
  o.reserve(s.length() * 3);
  for (size_t i = 0; i < s.length(); i++) {
    uint8_t c = (uint8_t)s[i];
    if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
    else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
  }
  return o;
}

static void ttsUnit(String &s, const char *u, const char *word, bool needDigit = true) {
  int ul = strlen(u), pos = 0;
  while ((pos = s.indexOf(u, pos)) >= 0) {
    int e = pos + ul, L = s.length();
    bool nextOk = (e >= L) || !isalpha((uint8_t)s[e]);
    int p = pos - 1;
    while (p >= 0 && s[p] == ' ') p--;
    bool prevOk = (pos == 0 || !isalpha((uint8_t)s[pos - 1])) && (!needDigit || (p >= 0 && isdigit((uint8_t)s[p])));
    if (nextOk && prevOk) {
      String r = String(" ") + word;
      s = s.substring(0, pos) + r + s.substring(e);
      pos += r.length();
    } else {
      pos = e;
    }
  }
}

static void ttsColon(String &s) {
  static const char *kw[] = { "bandingan", "rasio", "skala", "peta", "denah" };
  String out;
  int L = s.length(), start = 0;
  while (start <= L) {
    int e = start;
    while (e < L && s[e] != '\n' && s[e] != '|') e++;
    String piece = s.substring(start, e);
    String lc = piece;
    lc.toLowerCase();
    int k = 9999;
    for (int i = 0; i < 5; i++) { int p = lc.indexOf(kw[i]); if (p >= 0 && p < k) k = p; }
    int pos = 0;
    while ((pos = piece.indexOf(" : ", pos)) >= 0) {
      const char *w = (pos > k) ? " banding " : " dibagi ";
      piece = piece.substring(0, pos) + w + piece.substring(pos + 3);
      pos += strlen(w);
    }
    out += piece;
    if (e < L) out += s[e];
    start = e + 1;
  }
  s = out;
}

static void ttsRange(String &s) {
  for (int i = 1; i + 1 < (int)s.length(); i++) {
    if (s[i] == '-' && isdigit((uint8_t)s[i - 1]) && isdigit((uint8_t)s[i + 1])) {
      s = s.substring(0, i) + " sampai " + s.substring(i + 1);
      i += 7;
    }
  }
}

String ttsNormalize(String s) {
  ttsColon(s);
  ttsRange(s);
  s.replace("...", " dan seterusnya");
  s.replace("\n", ". ");
  s.replace("|", ". ");
  s.replace(" . ", ". ");
  s.replace("#", "");
  s.replace("&", " dan ");
  s.replace("FPB", "ef pe be");
  s.replace("KPK", "ka pe ka");
  s.replace("Akar(", "akar kuadrat dari (");
  s.replace(" deg", " derajat");
  s.replace("cm3", "sentimeter kubik");
  s.replace("m3", "meter kubik");
  s.replace("cm2", "sentimeter persegi");
  s.replace("km2", "kilometer persegi");
  s.replace("m2", "meter persegi");
  s.replace(" x ", " kali ");
  s.replace(" + ", " tambah ");
  s.replace(" - ", " kurang ");
  s.replace(" = ", " sama dengan ");
  s.replace(" > ", " lebih besar dari ");
  s.replace(" < ", " lebih kecil dari ");
  s.replace("(=)", "");
  s.replace("(>)", "");
  s.replace("(<)", "");
  s.replace(" : ", " dibagi ");
  s.replace("Rp", "rupiah ");
  s.replace("/", " per ");
  s.replace("%", " persen");
  ttsUnit(s, "cm", "sentimeter", false);
  ttsUnit(s, "km", "kilometer", false);
  ttsUnit(s, "kg", "kilogram", false);
  ttsUnit(s, "ml", "mililiter", false);
  ttsUnit(s, "m", "meter");
  ttsUnit(s, "g", "gram");
  ttsUnit(s, "l", "liter");
  ttsUnit(s, "L", "liter");
  ttsUnit(s, "d", "detik");
  s.replace("..", ".");
  s.replace("  ", " ");
  s.trim();
  return s;
}

static int ttsFirstChars  = TTS_CHUNK_CHARS;
static int ttsSecondChars = TTS_CHUNK_CHARS;

static void ttsPush(String *out, int &n, int maxOut, const String &piece) {
  if (!piece.length()) return;
  int lim = (n == 1) ? ttsFirstChars : (n == 2 ? ttsSecondChars : TTS_CHUNK_CHARS);
  if (n > 0 && (int)(out[n - 1].length() + 1 + piece.length()) <= lim) {
    out[n - 1] += " ";
    out[n - 1] += piece;
  } else if (n < maxOut) {
    out[n++] = piece;
  }
}

int ttsSplit(const String &t, String *out, int maxOut) {
  int n = 0, i = 0, L = t.length();
  while (i < L) {
    int j = i;
    while (j < L) {
      char c = t[j++];
      if ((c == '.' || c == '?' || c == '!') && (j >= L || t[j] == ' ')) break;
    }
    String sent = t.substring(i, j);
    sent.trim();
    i = j;
    while ((int)sent.length() > TTS_CHUNK_CHARS) {
      int cut = sent.lastIndexOf(',', TTS_CHUNK_CHARS);
      if (cut < 40) cut = sent.lastIndexOf(' ', TTS_CHUNK_CHARS);
      if (cut < 1) cut = TTS_CHUNK_CHARS;
      String head = sent.substring(0, cut);
      head.trim();
      ttsPush(out, n, maxOut, head);
      sent = sent.substring(cut + 1);
      sent.trim();
    }
    ttsPush(out, n, maxOut, sent);
  }
  return n;
}

static uint8_t *ttsBuf = nullptr;
static uint8_t *ttsBuf2 = nullptr;
static WiFiClientSecure *ttsClient = nullptr;
static HTTPClient       *ttsHttp   = nullptr;
static uint32_t          ttsLastUse = 0;

static void ttsRelease(uint8_t *p) { if (p && p != ttsBuf && p != ttsBuf2) free(p); }

static bool     ttsLowRam   = false;
static uint8_t  ttsConnHost = 0;
static uint32_t ttsCooldownUntil = 0;
static int      ttsFailRun = 0;

static uint8_t *ttsFetch(HTTPClient &http, WiFiClientSecure &client, const String &text, uint32_t &outLen, bool &full, int &code, uint8_t *dst = nullptr, uint8_t variant = 0) {
  outLen = 0; full = false; code = 0;
  String url = String(variant ? "https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl="
                              : "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=") + TTS_LANG +
               "&q=" + ttsUrlEncode(text);
  if (variant != ttsConnHost) { client.stop(); ttsConnHost = variant; }
  uint8_t *buf = dst ? dst : (ttsBuf ? ttsBuf : (uint8_t *)malloc(TTS_MP3_MAX));
  if (!buf) { Serial.println("TTS: RAM tidak cukup"); code = -100; return nullptr; }

  http.setReuse(TTS_KEEP_TLS);
  http.setConnectTimeout(ttsPrefMode ? 3000 : 5000);
  http.setTimeout(ttsPrefMode ? 4000 : 6000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36");
  if (!http.begin(client, url)) { ttsRelease(buf); code = -101; return nullptr; }
  http.addHeader("Referer", "https://translate.google.com/");
  code = http.GET();
  if (code != 200) {
    char tls[80] = "";
    if (code < 0) client.lastError(tls, sizeof(tls));
    Serial.printf("TTS: HTTP %d (%s)%s%s | RAM bebas %u, blok terbesar %u, PSRAM %s\n", code,
                  code < 0 ? HTTPClient::errorToString(code).c_str() : (code == 429 ? "Google membatasi permintaan" : "ditolak server"),
                  tls[0] ? " TLS: " : "", tls, (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap(), psramFound() ? "aktif" : "TIDAK aktif");
    if (code < 0 && ESP.getMaxAllocHeap() < 20000) ttsSetErr("RAM kurang");
    else if (code < 0) ttsSetErr(tls[0] ? "TLS gagal" : "internet putus");
    else { char m[24]; snprintf(m, sizeof(m), "HTTP %d", code); ttsSetErr(m); }
    http.end(); ttsRelease(buf); return nullptr;
  }
  int expect = http.getSize();
  TtsSink sink(buf, TTS_MP3_MAX);
  http.writeToStream(&sink);
  http.end();
  if (ttsStopNow()) { ttsRelease(buf); return nullptr; }
  if (sink.full) { full = true; outLen = (uint32_t)sink.n; return buf; }
  if (sink.n < 200 || (expect > 0 && sink.n < (size_t)expect)) {
    Serial.printf("TTS: unduhan tidak lengkap (%u dari %d byte)\n", (unsigned)sink.n, expect);
    ttsRelease(buf); code = -102; return nullptr;
  }
  outLen = (uint32_t)sink.n;
  return buf;
}

static void ttsPlayMp3(uint8_t *buf, uint32_t len) {
  for (int w = 0; sndBusy && w < 150; w++) vTaskDelay(pdMS_TO_TICKS(10));
  if (ttsAbort) return;

  ttsPlaying = true;
  sndBusy = true;
  i2s_set_clk(SPK_PORT, TTS_RATE_DEFAULT, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO);

  AudioFileSourcePROGMEM *src = new AudioFileSourcePROGMEM(buf, len);
  AudioOutputSpk *out = new AudioOutputSpk();
  AudioGeneratorMP3 *mp3 = new AudioGeneratorMP3();
  if (mp3->begin(src, out)) {
    while (mp3->isRunning() && !ttsAbort) {
      if (!mp3->loop()) break;
    }
  } else {
    Serial.println("TTS: gagal membuka MP3 (data bukan MP3?)");
  }
  if (mp3->isRunning()) mp3->stop();
  out->stop();
  delete mp3; delete out; delete src;

  if (ttsAbort) i2s_zero_dma_buffer(SPK_PORT);
  else vTaskDelay(pdMS_TO_TICKS(TTS_DRAIN_MS));
  i2s_set_clk(SPK_PORT, SPK_RATE, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO);
  sndQuietUntil = millis() + TTS_ECHO_TAIL_MS;
  sndBusy = false;
  ttsPlaying = false;
}

static bool     ttsCacheOK = false;
static uint32_t ttsCacheBytes = 0;
static bool     ttsNoNet = false;

static void ttsCachePath(const String &text, char *out, size_t cap) {
  uint64_t h = 1469598103934665603ULL;
  for (const char *p = TTS_LANG; *p; p++) { h ^= (uint8_t)*p; h *= 1099511628211ULL; }
  h ^= (uint8_t)'|'; h *= 1099511628211ULL;
  for (unsigned i = 0; i < text.length(); i++) { h ^= (uint8_t)text[i]; h *= 1099511628211ULL; }
  snprintf(out, cap, "/c%08lx%08lx.mp3", (unsigned long)(h >> 32), (unsigned long)(h & 0xffffffffULL));
}

#define TTS_KEEP_N 48
static char    ttsKeep[TTS_KEEP_N][24];
static uint8_t ttsKeepHead = 0;
static void ttsKeepAdd(const char *path) {
  for (int i = 0; i < TTS_KEEP_N; i++) if (!strcmp(ttsKeep[i], path)) return;
  strncpy(ttsKeep[ttsKeepHead], path, sizeof(ttsKeep[0]) - 1);
  ttsKeep[ttsKeepHead][sizeof(ttsKeep[0]) - 1] = 0;
  ttsKeepHead = (ttsKeepHead + 1) % TTS_KEEP_N;
}
static bool ttsKeepHas(const char *path) {
  for (int i = 0; i < TTS_KEEP_N; i++) if (!strcmp(ttsKeep[i], path)) return true;
  return false;
}

static bool ttsCacheEvictOne() {
#if TTS_CACHE
  String victim;
  size_t vsz = 0;
  File root = LittleFS.open("/");
  for (File f = root.openNextFile(); f; f = root.openNextFile()) {
    if (f.isDirectory()) continue;
    String p = f.path();
    if (p.length() < 5 || p == "/tmp.bin" || ttsKeepHas(p.c_str())) continue;
    victim = p; vsz = f.size();
    break;
  }
  root.close();
  if (!victim.length() || !LittleFS.remove(victim)) return false;
  ttsCacheBytes = (ttsCacheBytes > vsz) ? ttsCacheBytes - (uint32_t)vsz : 0;
  return true;
#else
  return false;
#endif
}

static void ttsCacheInit() {
#if TTS_CACHE
  if (!LittleFS.begin(true)) { Serial.println("TTS: cache flash tidak tersedia (tidak ada partisi LittleFS) - bacaan tetap lewat WiFi"); return; }
#if TTS_CACHE_CLEAR
  LittleFS.format();
#endif
  int n = 0;
  File root = LittleFS.open("/");
  for (File f = root.openNextFile(); f; f = root.openNextFile()) { ttsCacheBytes += f.size(); n++; }
  ttsCacheOK = true;
  Serial.printf("TTS: cache flash siap, %d frasa tersimpan (%u byte)\n", n, (unsigned)ttsCacheBytes);
#endif
}

static bool ttsCacheLoad(const String &text, uint8_t *buf, uint32_t &len) {
#if TTS_CACHE
  if (!ttsCacheOK || !buf || text.length() > TTS_CACHE_MAX_CHARS) return false;
  char path[40];
  ttsCachePath(text, path, sizeof(path));
  if (!LittleFS.exists(path)) return false;
  ttsKeepAdd(path);
  File f = LittleFS.open(path, "r");
  if (!f) return false;
  size_t n = f.size();
  if (n < 200 || n > TTS_MP3_MAX) { f.close(); return false; }
  size_t got = f.read(buf, n);
  f.close();
  if (got != n) return false;
  len = (uint32_t)n;
  return true;
#else
  return false;
#endif
}

static void ttsCacheSave(const String &text, const uint8_t *mp3, uint32_t len) {
#if TTS_CACHE
  if (!ttsCacheOK || text.length() > TTS_CACHE_MAX_CHARS || len < 200) return;
  char path[40];
  ttsCachePath(text, path, sizeof(path));
  if (LittleFS.exists(path)) { ttsKeepAdd(path); return; }
  for (int guard = 0; guard < 40; guard++) {
    bool roomLeft = (ttsCacheBytes + len <= TTS_CACHE_MAX_BYTES) &&
                    (LittleFS.totalBytes() - LittleFS.usedBytes() >= (size_t)len + 65536);
    if (roomLeft) break;
    if (!ttsCacheEvictOne()) return;
  }
  File f = LittleFS.open("/tmp.bin", "w");
  if (!f) return;
  size_t w = f.write(mp3, len);
  f.close();
  if (w != len || !LittleFS.rename("/tmp.bin", path)) { LittleFS.remove("/tmp.bin"); return; }
  ttsCacheBytes += len;
  ttsKeepAdd(path);
  Serial.printf("TTS: disimpan ke cache (%u byte): %s\n", (unsigned)len, text.c_str());
#endif
}

static void ttsPlayMp3(uint8_t *buf, uint32_t len);

static bool ttsChunk(HTTPClient &http, WiFiClientSecure &client, const String &text, int depth) {
  { uint32_t clen = 0;
    if (!ttsAbort && ttsCacheLoad(text, ttsBuf, clen)) {
      Serial.printf("TTS: dari cache (%u byte): %s\n", (unsigned)clen, text.c_str());
      ttsPlayMp3(ttsBuf, clen);
      return true;
    }
  }
  if (ttsNoNet) return false;
  if ((int32_t)(ttsCooldownUntil - millis()) > 0) { ttsNoNet = true; ttsRepeatErr(); return false; }
  { bool up = ttsWifiReady();
    if (ttsAbort) return false;
    if (!up) { ttsNoNet = true; ttsSetErr("WiFi mati"); ttsLogNoWifi(); return false; } }
  for (int attempt = 1; attempt <= TTS_RETRY && !ttsAbort; attempt++) {
    uint32_t t0 = millis(), len = 0;
    bool full = false;
    int code = 0;
    uint8_t *mp3 = ttsFetch(http, client, text, len, full, code, nullptr, (uint8_t)(attempt - 1));
    Serial.printf("TTS: percobaan %d/%d, %u byte, %u ms, RAM bebas %u (blok terbesar %u)%s\n", attempt, TTS_RETRY, (unsigned)len,
                  (unsigned)(millis() - t0), (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap(), full ? "  <-- KEPENUHAN" : "");
    if (mp3 && full) {
      ttsRelease(mp3);
      int mid = text.length() / 2, cut = text.lastIndexOf(' ', mid);
      if (cut < 8) cut = text.indexOf(' ', mid);
      if (depth < 3 && cut > 8 && cut < (int)text.length() - 4) {
        String l = text.substring(0, cut), r = text.substring(cut + 1);
        bool a = ttsChunk(http, client, l, depth + 1);
        bool b = ttsChunk(http, client, r, depth + 1);
        return a && b;
      }
      Serial.println("TTS: potongan terlalu panjang & tidak bisa dibelah - dilewati");
      return false;
    }
    if (mp3) {
      ttsFailRun = 0;
      if (!TTS_KEEP_TLS || (ttsLowRam && ESP.getMaxAllocHeap() < 40000)) client.stop();
      ttsPlayMp3(mp3, len);
      if (text.length() <= TTS_LIVE_SAVE_MAX) ttsCacheSave(text, mp3, len);
      ttsRelease(mp3);
      return true;
    }
    client.stop();
    for (int w = 0; w < (code == 429 ? 150 : (attempt == 1 ? 8 : 30 * (attempt - 1))) && !ttsAbort; w++) vTaskDelay(pdMS_TO_TICKS(10));
    if (WiFi.status() != WL_CONNECTED) { Serial.println("TTS: WiFi putus, menyambung ulang"); WiFi.reconnect(); for (int w = 0; w < 100 && WiFi.status() != WL_CONNECTED && !ttsAbort; w++) vTaskDelay(pdMS_TO_TICKS(100)); }
  }
  return false;
}

#if TTS_PIPELINE
struct TtsItem { int8_t idx; uint32_t len; };
static QueueHandle_t     ttsFreeQ = nullptr;
static QueueHandle_t     ttsFullQ = nullptr;
static SemaphoreHandle_t ttsDoneSem = nullptr;
static bool              ttsPipeOK = false;

struct TtsSave { String text; uint8_t *data; uint32_t len; };
static TtsSave ttsSaves[4];
static uint8_t ttsSaveN = 0;
static void ttsDeferSave(const String &text, const uint8_t *mp3, uint32_t len) {
#if TTS_CACHE
  if (!ttsCacheOK || text.length() > TTS_LIVE_SAVE_MAX || len < 200 || ttsSaveN >= 4) return;
  uint8_t *c = (uint8_t *)heap_caps_malloc(len, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!c) return;
  memcpy(c, mp3, len);
  ttsSaves[ttsSaveN].text = text; ttsSaves[ttsSaveN].data = c; ttsSaves[ttsSaveN].len = len;
  ttsSaveN++;
#endif
}
static void ttsFlushSaves() {
  for (uint8_t i = 0; i < ttsSaveN; i++) {
#if TTS_CACHE
    if (!ttsHasPending) ttsCacheSave(ttsSaves[i].text, ttsSaves[i].data, ttsSaves[i].len);
#endif
    free(ttsSaves[i].data);
    ttsSaves[i].data = nullptr;
    ttsSaves[i].text = "";
  }
  ttsSaveN = 0;
}

static void ttsPlayTask(void *arg) {
  for (;;) {
    TtsItem it;
    if (xQueueReceive(ttsFullQ, &it, portMAX_DELAY) != pdTRUE) continue;
    if (it.idx < 0) { xSemaphoreGive(ttsDoneSem); continue; }
    ttsPlayMp3(it.idx ? ttsBuf2 : ttsBuf, it.len);
    uint8_t i = (uint8_t)it.idx;
    xQueueSend(ttsFreeQ, &i, portMAX_DELAY);
    if (TTS_LISTEN_GAP_MS > 0 && !ttsAbort) {
      TtsItem nx;
      if (!(xQueuePeek(ttsFullQ, &nx, 0) == pdTRUE && nx.idx < 0))
        for (int g = 0; g < TTS_LISTEN_GAP_MS / 10 && !ttsAbort; g++) vTaskDelay(pdMS_TO_TICKS(10));
    }
  }
}

static int ttsTakeFree() {
  uint8_t i;
  while (!ttsAbort) if (xQueueReceive(ttsFreeQ, &i, pdMS_TO_TICKS(20)) == pdTRUE) return i;
  return -1;
}
static void ttsGiveFree(int idx) { uint8_t i = (uint8_t)idx; xQueueSend(ttsFreeQ, &i, portMAX_DELAY); }
static void ttsEnqueue(int idx, uint32_t len) { TtsItem it = { (int8_t)idx, len }; xQueueSend(ttsFullQ, &it, portMAX_DELAY); }

static void ttsPipeFinish() {
  TtsItem end = { -1, 0 };
  xQueueSend(ttsFullQ, &end, portMAX_DELAY);
  xSemaphoreTake(ttsDoneSem, portMAX_DELAY);
}

static bool ttsChunkP(HTTPClient &http, WiFiClientSecure &client, const String &text, int depth) {
  int idx = ttsTakeFree();
  if (idx < 0) return false;
  uint8_t *dst = idx ? ttsBuf2 : ttsBuf;
  uint32_t len = 0;
  if (!ttsAbort && ttsCacheLoad(text, dst, len)) {
    Serial.printf("TTS: dari cache (%u byte): %s\n", (unsigned)len, text.c_str());
    ttsEnqueue(idx, len);
    return true;
  }
  if (ttsNoNet) { ttsGiveFree(idx); return false; }
  if ((int32_t)(ttsCooldownUntil - millis()) > 0) { ttsNoNet = true; ttsRepeatErr(); ttsGiveFree(idx); return false; }
  { bool up = ttsWifiReady();
    if (ttsAbort) { ttsGiveFree(idx); return false; }
    if (!up) { ttsNoNet = true; ttsSetErr("WiFi mati"); ttsLogNoWifi(); ttsGiveFree(idx); return false; } }
  for (int attempt = 1; attempt <= TTS_RETRY && !ttsAbort; attempt++) {
    uint32_t t0 = millis(), n = 0;
    bool full = false;
    int code = 0;
    uint8_t *mp3 = ttsFetch(http, client, text, n, full, code, dst, (uint8_t)(attempt - 1));
    Serial.printf("TTS: percobaan %d/%d, %u byte, %u ms, RAM bebas %u (blok terbesar %u)%s\n", attempt, TTS_RETRY, (unsigned)n,
                  (unsigned)(millis() - t0), (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap(), full ? "  <-- KEPENUHAN" : "");
    if (mp3 && full) {
      ttsGiveFree(idx);
      int mid = text.length() / 2, cut = text.lastIndexOf(' ', mid);
      if (cut < 8) cut = text.indexOf(' ', mid);
      if (depth < 3 && cut > 8 && cut < (int)text.length() - 4) {
        String l = text.substring(0, cut), r = text.substring(cut + 1);
        bool a = ttsChunkP(http, client, l, depth + 1);
        bool b = ttsChunkP(http, client, r, depth + 1);
        return a && b;
      }
      Serial.println("TTS: potongan terlalu panjang & tidak bisa dibelah - dilewati");
      return false;
    }
    if (mp3) {
      ttsFailRun = 0;
      ttsDeferSave(text, dst, n);
      ttsEnqueue(idx, n);
      return true;
    }
    client.stop();
    for (int w = 0; w < (code == 429 ? 150 : (attempt == 1 ? 8 : 30 * (attempt - 1))) && !ttsAbort; w++) vTaskDelay(pdMS_TO_TICKS(10));
    if (WiFi.status() != WL_CONNECTED) { Serial.println("TTS: WiFi putus, menyambung ulang"); WiFi.reconnect(); for (int w = 0; w < 100 && WiFi.status() != WL_CONNECTED && !ttsAbort; w++) vTaskDelay(pdMS_TO_TICKS(100)); }
  }
  ttsGiveFree(idx);
  return false;
}
#endif

static void ttsRun(String text) {
  ttsNoNet = false;
  if (ttsAbort) return;
  text = ttsNormalize(text);
  static String chunks[TTS_MAX_CHUNKS];
  int nc = ttsSplit(text, chunks, TTS_MAX_CHUNKS);
  Serial.printf("TTS: %d potongan, WiFi %d dBm: %s\n", nc, (int)WiFi.RSSI(), text.c_str());

  if (!ttsClient) {
    ttsClient = new WiFiClientSecure();
    ttsHttp = new HTTPClient();
    if (ttsClient) ttsClient->setInsecure();
  }
  if (!ttsClient || !ttsHttp) { Serial.println("TTS: RAM tidak cukup untuk koneksi"); return; }
  WiFiClientSecure &client = *ttsClient;
  HTTPClient &http = *ttsHttp;
  int fails = 0;
  for (int i = 0; i < nc && !ttsAbort; i++) {
#if TTS_PIPELINE
    bool okc = ttsPipeOK ? ttsChunkP(http, client, chunks[i], 0) : ttsChunk(http, client, chunks[i], 0);
#else
    bool okc = ttsChunk(http, client, chunks[i], 0);
#endif
    if (okc) fails = 0;
    else if (!ttsAbort) {
      Serial.printf("TTS: potongan %d gagal setelah %d percobaan\n", i + 1, TTS_RETRY);
      if (++fails >= 3) {
        Serial.printf("TTS: tiga potongan berturut-turut gagal - bacaan dihentikan, unduhan dijeda %d detik (cek WiFi / Google)\n", TTS_COOLDOWN_MS / 1000);
        ttsCooldownUntil = millis() + TTS_COOLDOWN_MS;
        break;
      }
    }
  }
#if TTS_PIPELINE
  if (ttsPipeOK) { ttsPipeFinish(); ttsFlushSaves(); }
#endif
  if (ttsLowRam || !TTS_KEEP_TLS) client.stop();
  ttsLastUse = millis();
  ttsConnOpen = client.connected();
}

static String            ttsPrefText;
static volatile bool     ttsPrefHas = false;
static uint32_t          ttsPrefBackoffUntil = 0;

static void ttsPrefRun() {
#if TTS_PREFETCH && TTS_CACHE
  if (!ttsCacheOK || !ttsBuf || !ttsWifiOK() || ttsWifiUnset()) { ttsPrefHas = false; return; }
  if (ttsMicBusy()) return;
  if ((int32_t)(ttsPrefBackoffUntil - millis()) > 0 || (int32_t)(ttsCooldownUntil - millis()) > 0) { ttsPrefHas = false; return; }
  if (ttsLowRam && ESP.getMaxAllocHeap() < 40000) { ttsPrefHas = false; return; }

  xSemaphoreTake(ttsMx, portMAX_DELAY);
  String raw = ttsPrefText;
  xSemaphoreGive(ttsMx);

  static String chunks[TTS_MAX_CHUNKS * 2];
  static String tmp[TTS_MAX_CHUNKS];
  int nc = 0, ps = 0, RL = raw.length();
  while (ps <= RL && nc < TTS_MAX_CHUNKS * 2) {
    int pe = raw.indexOf('\x01', ps);
    if (pe < 0) pe = RL;
    String part = raw.substring(ps, pe);
    int k = ttsSplit(ttsNormalize(part), tmp, TTS_MAX_CHUNKS);
    for (int j = 0; j < k && nc < TTS_MAX_CHUNKS * 2; j++) chunks[nc++] = tmp[j];
    ps = pe + 1;
  }

  if (!ttsClient) {
    ttsClient = new WiFiClientSecure();
    ttsHttp = new HTTPClient();
    if (ttsClient) ttsClient->setInsecure();
  }
  if (!ttsClient || !ttsHttp) { ttsPrefHas = false; return; }

  ttsPrefCancel = false;
  if (ttsBusy) return;
  ttsPrefMode = true;
  ttsQuiet = true;
  bool finished = true;
  int fetched = 0;
  uint32_t t0 = millis();
  for (int i = 0; i < nc; i++) {
    if (ttsStopNow()) { finished = false; break; }
    if (chunks[i].length() > TTS_CACHE_MAX_CHARS) continue;
    char path[40];
    ttsCachePath(chunks[i], path, sizeof(path));
    if (LittleFS.exists(path)) { ttsKeepAdd(path); continue; }
    uint32_t len = 0;
    bool full = false;
    int code = 0;
    uint8_t *mp3 = ttsFetch(*ttsHttp, *ttsClient, chunks[i], len, full, code, ttsBuf, (uint8_t)0);
    if (ttsStopNow()) { finished = false; break; }
    if (mp3 && !full) { ttsCacheSave(chunks[i], mp3, len); fetched++; }
    else if (!mp3) {
      ttsPrefBackoffUntil = millis() + TTS_PREFETCH_BACKOFF_MS;
      Serial.printf("TTS: unduhan latar gagal (kode %d) - dicoba lagi nanti\n", code);
      ttsClient->stop();
      finished = false;
      break;
    }
  }
  ttsPrefMode = false;
  ttsQuiet = false;
  if (ttsDropReq) { ttsPrefHas = false; ttsClient->stop(); }
  if (finished) {
    xSemaphoreTake(ttsMx, portMAX_DELAY);
    if (ttsPrefText.length() && ttsPrefText == raw) ttsPrefHas = false;
    xSemaphoreGive(ttsMx);
    if (fetched) Serial.printf("TTS: soal berikutnya siap di cache (%d potongan baru, %u ms)\n", fetched, (unsigned)(millis() - t0));
  }
  if (ttsLowRam || !TTS_KEEP_TLS) ttsClient->stop();
  ttsLastUse = millis();
  ttsConnOpen = ttsClient->connected();
#else
  ttsPrefHas = false;
#endif
}

static void ttsTask(void *arg) {
  for (;;) {
    if (!ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(200))) {
      if (ttsPrefHas && !ttsBusy) ttsPrefRun();
      if (ttsClient && (ttsDropReq || (millis() - ttsLastUse > (ttsLowRam ? 6000UL : (uint32_t)TTS_IDLE_MS))) && ttsClient->connected()) ttsClient->stop();
      ttsDropReq = false;
      if (ttsFreeReq) {
        if (ttsClient) ttsClient->stop();
        if (ttsHttp)   { delete ttsHttp;   ttsHttp = nullptr; }
        if (ttsClient) { delete ttsClient; ttsClient = nullptr; }
        ttsFreeReq = false;
      }
      ttsConnOpen = ttsClient && ttsClient->connected();
      continue;
    }
    for (;;) {
      xSemaphoreTake(ttsMx, portMAX_DELAY);
      if (!ttsHasPending) { ttsBusy = false; xSemaphoreGive(ttsMx); break; }
      String text = ttsPending;
      ttsHasPending = false;
      ttsAbort = false;
      xSemaphoreGive(ttsMx);
      ttsRun(text);
    }
  }
}

void ttsInit() {
  ttsMx = xSemaphoreCreateMutex();
  ttsLowRam = !psramFound();
  Serial.printf("TTS: PSRAM %s -> %s\n", psramFound() ? "aktif" : "TIDAK aktif",
                ttsLowRam ? "mode HEMAT RAM (tanpa pemutar paralel, koneksi dilepas tiap potongan)" : "mode lengkap");
  ttsBuf = (uint8_t *)heap_caps_malloc(TTS_MP3_MAX, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!ttsBuf) ttsBuf = (uint8_t *)heap_caps_malloc(TTS_MP3_MAX, MALLOC_CAP_8BIT);
  Serial.printf("TTS: buffer MP3 %u byte %s\n", (unsigned)TTS_MP3_MAX, ttsBuf ? "siap" : "GAGAL (RAM kurang) - pakai alokasi per potongan");
#if TTS_PIPELINE
  if (ttsBuf && !ttsLowRam) {
    ttsBuf2 = (uint8_t *)heap_caps_malloc(TTS_MP3_MAX, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!ttsBuf2) ttsBuf2 = (uint8_t *)heap_caps_malloc(TTS_MP3_MAX, MALLOC_CAP_8BIT);
    ttsFreeQ = xQueueCreate(2, sizeof(uint8_t));
    ttsFullQ = xQueueCreate(3, sizeof(TtsItem));
    ttsDoneSem = xSemaphoreCreateBinary();
    if (ttsBuf2 && ttsFreeQ && ttsFullQ && ttsDoneSem &&
        xTaskCreatePinnedToCore(ttsPlayTask, "ttsPlay", 10240, NULL, 4, NULL, 1) == pdPASS) {
      for (uint8_t i = 0; i < 2; i++) xQueueSend(ttsFreeQ, &i, 0);
      ttsPipeOK = true;
    }
  }
  Serial.printf("TTS: pemutar paralel %s\n", ttsPipeOK ? "AKTIF (unduh & putar bersamaan)" : "mati - bacaan urut satu-satu");
#endif
#if TTS_PIPELINE
  if (ttsPipeOK) { ttsFirstChars = TTS_FIRST_CHARS; ttsSecondChars = 60; }
#endif
  ttsCacheInit();
  if (ttsWifiUnset())
    Serial.println("WiFi: !!! WIFI_SSID di src/WifiConfig.h masih nilai bawaan. Isi WIFI_SSID & WIFI_PASS lalu upload ulang. "
                   "Tanpa WiFi, hanya frasa yang sudah ada di cache flash yang bisa dibacakan (soal, pujian, penjelasan TIDAK) !!!");
  WiFi.onEvent(ttsWifiEvent);
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.printf("WiFi: menyambung ke \"%s\" ...\n", WIFI_SSID);
  xTaskCreatePinnedToCore(ttsTask, "ttsTask", 16384, NULL, 3, &ttsTaskH, 0);
}

void ttsStop() {
  if (!ttsMx) return;
  ttsPrefCancel = true;
  xSemaphoreTake(ttsMx, portMAX_DELAY);
  ttsHasPending = false;
  ttsAbort = true;
  xSemaphoreGive(ttsMx);
}

void ttsFreeMemory(uint32_t maxMs = 1500) {
  if (!ttsMx) return;
  ttsStop();
  ttsFreeReq = true;
  uint32_t t0 = millis();
  while (ttsFreeReq && millis() - t0 < maxMs) delay(10);
}

void ttsSpeak(const String &text, bool append = false) {
  if (!ttsMx || !ttsTaskH || text.length() == 0) return;
  ttsPrefCancel = true;

  if (WiFi.status() != WL_CONNECTED && millis() > 20000 && millis() - ttsLastRetry > 10000) {
    ttsLastRetry = millis();
    Serial.printf("TTS: WiFi belum tersambung (%s) - mencoba menyambung ulang. Cek src/WifiConfig.h\n", ttsWifiWhy());
    WiFi.reconnect();
  }
  xSemaphoreTake(ttsMx, portMAX_DELAY);
  if (append && ttsBusy) {
    if (ttsHasPending) { ttsPending += " "; ttsPending += text; }
    else { ttsPending = text; ttsHasPending = true; }
    xSemaphoreGive(ttsMx);
    return;
  }
  ttsPending = text;
  ttsHasPending = true;
  ttsAbort = true;
  ttsBusy = true;
  ttsStartMs = millis();
  xSemaphoreGive(ttsMx);
  xTaskNotifyGive(ttsTaskH);
}

void ttsWait(uint32_t maxMs = 9000, bool allowSkip = true) {
  uint32_t t0 = millis();
  while (ttsBusy && millis() - t0 < maxMs) {
    if (allowSkip && millis() - t0 > 800 && ts.touched()) { ttsStop(); break; }
    delay(20);
  }
}

static String ttsQuestionText(const Question &q, int num) {
  String t;
  if (num > 0) { t += "Soal nomor "; t += num; t += ". "; }
  t += q.q;
#if TTS_READ_OPTIONS
  t += " ";
  for (int i = 0; i < 4; i++) {
    t += BTN_LTR[i];
    t += ", ";
    t += q.opt[i];
    t += ". ";
  }
#endif
  return t;
}

void ttsSpeakQuestion(const Question &q, int num = 0) {
  ttsSpeak(ttsQuestionText(q, num));
}

static int ttsQuestionChunks(const Question &q, int num, String *out) {
  return ttsSplit(ttsNormalize(ttsQuestionText(q, num)), out, TTS_MAX_CHUNKS);
}

bool ttsQuestionReady(const Question &q, int num = 0) {
#if TTS_CACHE
  if (!ttsCacheOK) return true;
  static String ch[TTS_MAX_CHUNKS];
  int nc = ttsQuestionChunks(q, num, ch);
  for (int i = 0; i < nc; i++) {
    if (ch[i].length() > TTS_CACHE_MAX_CHARS) continue;
    char path[40];
    ttsCachePath(ch[i], path, sizeof(path));
    if (!LittleFS.exists(path)) return false;
  }
#endif
  return true;
}

void ttsPrefetchRaw(const String &t) {
#if TTS_PREFETCH && TTS_CACHE
  if (!ttsMx || !ttsTaskH || !t.length()) return;
  xSemaphoreTake(ttsMx, portMAX_DELAY);
  ttsPrefText = t;
  ttsPrefHas = true;
  xSemaphoreGive(ttsMx);
#endif
}

void ttsPrefetchQuestion(const Question &q, int num = 0, const String &extra = "") {
  String t = ttsQuestionText(q, num);
  if (extra.length()) t = extra + String('\x01') + t;
  ttsPrefetchRaw(t);
}

bool ttsFailedRecently() { return ttsErrAt && millis() - ttsErrAt < TTS_ERR_SHOW_MS; }

bool ttsPreloadQuestion(const Question &q, int num, uint32_t maxMs) {
#if TTS_PREFETCH && TTS_CACHE
  if (!ttsMx || !ttsTaskH || !ttsCacheOK || ttsWifiUnset() || !ttsWifiOK()) return true;
  if (ttsQuestionReady(q, num)) return true;
  ttsPrefetchQuestion(q, num);
  uint32_t t0 = millis();
  while (ttsPrefHas && !ttsQuestionReady(q, num) && millis() - t0 < maxMs) {
    if (millis() - t0 > 700 && ts.touched()) break;
    delay(30);
  }
  return ttsQuestionReady(q, num);
#else
  return true;
#endif
}

#else

void ttsInit() {}
void ttsStop() {}
void ttsFreeMemory(uint32_t = 0) {}
void ttsSpeak(const String &, bool = false) {}
void ttsWait(uint32_t = 0, bool = true) {}
void ttsSpeakQuestion(const Question &, int = 0) {}
void ttsPrefetchRaw(const String &) {}
void ttsPrefetchQuestion(const Question &, int = 0, const String & = "") {}
bool ttsQuestionReady(const Question &, int = 0) { return true; }
bool ttsPreloadQuestion(const Question &, int, uint32_t) { return true; }
bool ttsWifiOK() { return true; }
bool ttsFailedRecently() { return false; }
bool ttsWifiUnset() { return false; }
const char *ttsWifiWhy() { return ""; }

#endif
