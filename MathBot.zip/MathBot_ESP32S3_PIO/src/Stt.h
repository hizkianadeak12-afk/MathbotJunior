#pragma once
#include "Voice.h"
#include "esp_heap_caps.h"

#if STT_ENABLED

static_assert(VG_CAP_SAMPLES >= STT_WIN, "buffer rekaman lebih kecil dari jendela 1 detik");

static int16_t     *sttPcm   = nullptr;
static size_t       sttLen   = 0;
static uint32_t     sttEpochAtSubmit = 0;
static TaskHandle_t sttTaskH = nullptr;

#if STT_MODE == 1

static int sttRecognize(int16_t *pcm, size_t n, int &letter) {
  letter = 0;
  if (strncmp(WIT_TOKEN, "ISI_", 4) == 0) { Serial.println("STT: WIT_TOKEN belum diisi di SttConfig.h"); return 1; }
  if (WiFi.status() != WL_CONNECTED) { Serial.println("STT: WiFi belum tersambung"); return 1; }
  vgNormalize16(pcm, n);
  ttsDropReq = true;
  for (int w = 0; w < 30 && ttsConnOpen; w++) vTaskDelay(pdMS_TO_TICKS(50));

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setReuse(false);
  http.setConnectTimeout(6000);
  http.setTimeout(8000);
  if (!http.begin(client, WIT_URL)) return 1;
  http.addHeader("Authorization", String("Bearer ") + WIT_TOKEN);
  http.addHeader("Content-Type", "audio/raw;encoding=signed-integer;bits=16;rate=16000;endian=little");
  uint32_t t0 = millis();
  int code = http.POST((uint8_t *)pcm, n * sizeof(int16_t));
  if (code != 200) {
    Serial.printf("STT: HTTP %d %s\n", code, code == 401 ? "(token Wit.ai salah - pakai Server Access Token)" : (code < 0 ? HTTPClient::errorToString(code).c_str() : ""));
    http.end();
    return 1;
  }
  String body = http.getString();
  http.end();

  char txt[96];
  if (!sttExtractText(body.c_str(), txt, sizeof(txt))) txt[0] = 0;
  letter = sttLetterFromText(txt);
#if STT_DEBUG
  Serial.printf("STT: %u ms, %u sampel, dengar \"%s\" -> %s\n", (unsigned)(millis() - t0), (unsigned)n, txt,
                letter ? String(char('A' + letter - 1)).c_str() : "tidak dikenali (diabaikan)");
#endif
  return 0;
}

#elif STT_MODE == 2

static_assert(EI_CLASSIFIER_RAW_SAMPLE_COUNT == STT_WIN, "Edge Impulse: window size harus 1000 ms pada 16 kHz");

static int eiGetData(size_t offset, size_t length, float *out) {
  for (size_t i = 0; i < length; i++) out[i] = (float)sttPcm[offset + i];
  return 0;
}

static int sttLabelLetter(const char *l) {
  if (!l || !l[0] || l[1]) return 0;
  char c = (char)(l[0] | 0x20);
  return (c >= 'a' && c <= 'd') ? (c - 'a' + 1) : 0;
}

static int sttRecognize(int16_t *pcm, size_t n, int &letter) {
  letter = 0;
  vgMakeWindow(pcm, n);
  vgNormalize16(pcm, STT_WIN);
  signal_t sig;
  sig.total_length = EI_CLASSIFIER_RAW_SAMPLE_COUNT;
  sig.get_data = &eiGetData;
  ei_impulse_result_t res;
  memset(&res, 0, sizeof(res));
  uint32_t t0 = millis();
  EI_IMPULSE_ERROR e = run_classifier(&sig, &res, false);
  if (e != EI_IMPULSE_OK) { Serial.printf("STT: run_classifier gagal (kode %d)\n", (int)e); return 1; }
  int best = -1;
  float bv = 0;
  for (size_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++)
    if (res.classification[i].value > bv) { bv = res.classification[i].value; best = (int)i; }
  if (best >= 0 && bv >= EI_MIN_CONF) letter = sttLabelLetter(res.classification[best].label);
#if STT_DEBUG
  Serial.printf("STT: %u ms, terbaik \"%s\" %.0f%% -> %s\n", (unsigned)(millis() - t0),
                best >= 0 ? res.classification[best].label : "-", bv * 100.0f,
                letter ? String(char('A' + letter - 1)).c_str() : "diabaikan");
#endif
  return 0;
}

#else

static int sttRecognize(int16_t *pcm, size_t n, int &letter) {
  letter = 0;
  vgMakeWindow(pcm, n);
  vgNormalize16(pcm, STT_WIN);
  uint32_t cnt = STT_WIN;
  Serial.write((const uint8_t *)"MBREC", 5);
  Serial.write((const uint8_t *)&cnt, 4);
  Serial.write((const uint8_t *)pcm, STT_WIN * sizeof(int16_t));
  Serial.flush();
  return 0;
}
#endif

static void sttTask(void *arg) {
  for (;;) {
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
    int letter = 0;
    int err = sttRecognize(sttPcm, sttLen, letter);
    if (sttEpochAtSubmit != micEpoch) {
      micState = 0;
    } else if (letter >= 1 && letter <= 4) {
      micResult = (uint8_t)letter;
      micState = 0;
    } else {
      micState = err ? 4 : 3;
    }
    sttBusy = false;
  }
}

int16_t *sttInit() {
  size_t bytes = (size_t)VG_CAP_SAMPLES * sizeof(int16_t);
  sttPcm = (int16_t *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!sttPcm) sttPcm = (int16_t *)heap_caps_malloc(bytes, MALLOC_CAP_8BIT);
  if (!sttPcm) { Serial.println("STT: RAM tidak cukup untuk buffer suara - jawaban suara mati"); return nullptr; }
  xTaskCreatePinnedToCore(sttTask, "sttTask", (STT_MODE == 2) ? 16384 : 12288, NULL, 2, &sttTaskH, 0);
  return sttPcm;
}

void sttSubmit(size_t samples) {
  sttLen = samples;
  sttEpochAtSubmit = micEpoch;
  sttBusy = true;
  micState = 2;
  xTaskNotifyGive(sttTaskH);
}

#else

int16_t *sttInit() { return nullptr; }
void sttSubmit(size_t) {}

#endif
