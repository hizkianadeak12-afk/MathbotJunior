#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>

#define VG_BLOCK        128
#define VG_BLOCK_MS     8
#define VG_PRE_BLOCKS   20
#define VG_HANG_BLOCKS  30
#define VG_TAIL_BLOCKS  8
#define VG_MIN_MS       110
#define VG_MAX_MS       900
#define VG_MAX_BLOCKS   ((VG_MAX_MS / VG_BLOCK_MS) + 1)

#define VG_CAP_SAMPLES  ((VG_PRE_BLOCKS + VG_MAX_BLOCKS + VG_HANG_BLOCKS + 4) * VG_BLOCK)

static const float VG_MIN_RMS   = 220.0f;
static const float VG_RATIO_ON  = 3.5f;
static const float VG_RATIO_OFF = 2.0f;

class VoiceGate {
 public:
  enum Event { EV_NONE = 0, EV_SPEECH, EV_UTTERANCE, EV_REJECTED };

  void begin(int16_t *buf) { buf_ = buf; noise_ = 60.0f; dcX_ = dcY_ = 0; reset(); }
  bool ready() const { return buf_ != nullptr; }
  const int16_t *data() const { return buf_; }
  size_t length() const { return outLen_; }

  void reset() { st_ = IDLE; ringPos_ = ringCnt_ = 0; onCnt_ = 0; nBlk_ = 0; quiet_ = 0; dropQuiet_ = 0; announced_ = false; }

  Event feedRaw(const int32_t *raw, bool deaf) {
    int16_t blk[VG_BLOCK];
    float sumSq = 0;
    for (int i = 0; i < VG_BLOCK; i++) {
      float x = (float)(raw[i] >> 14);
      float y = x - dcX_ + 0.995f * dcY_;
      dcX_ = x; dcY_ = y;
      sumSq += y * y;
      if (y > 32767.0f) y = 32767.0f; else if (y < -32768.0f) y = -32768.0f;
      blk[i] = (int16_t)y;
    }
    return feed(blk, sqrtf(sumSq / VG_BLOCK), deaf);
  }

  Event feed(const int16_t *blk, float rms, bool deaf) {
    float thrOn  = fmaxf(VG_MIN_RMS, VG_RATIO_ON * noise_);
    float thrOff = fmaxf(VG_MIN_RMS * 0.6f, VG_RATIO_OFF * noise_);

    if (st_ == IDLE) {
      noise_ += (rms - noise_) * 0.02f;
      memcpy(ring_[ringPos_], blk, sizeof(int16_t) * VG_BLOCK);
      ringPos_ = (ringPos_ + 1) % VG_PRE_BLOCKS;
      if (ringCnt_ < VG_PRE_BLOCKS) ringCnt_++;
      if (!deaf && rms > thrOn) onCnt_++; else onCnt_ = 0;
      if (onCnt_ >= 2) {
        nBlk_ = 0;
        int first = (ringCnt_ == VG_PRE_BLOCKS) ? ringPos_ : 0;
        for (int k = 0; k < ringCnt_; k++) {
          memcpy(buf_ + (size_t)nBlk_ * VG_BLOCK, ring_[(first + k) % VG_PRE_BLOCKS], sizeof(int16_t) * VG_BLOCK);
          nBlk_++;
        }
        speechStart_ = nBlk_ - 2;
        quiet_ = 0; onCnt_ = 0; announced_ = false;
        st_ = SPEECH;
      }
      return EV_NONE;
    }

    if (st_ == DROP) {
      noise_ += (rms - noise_) * 0.01f;
      if (rms < thrOff) { if (++dropQuiet_ >= VG_HANG_BLOCKS) { st_ = IDLE; ringCnt_ = ringPos_ = 0; onCnt_ = 0; } }
      else dropQuiet_ = 0;
      return EV_NONE;
    }

    if ((size_t)(nBlk_ + 1) * VG_BLOCK > VG_CAP_SAMPLES) { st_ = DROP; dropQuiet_ = 0; return EV_REJECTED; }
    memcpy(buf_ + (size_t)nBlk_ * VG_BLOCK, blk, sizeof(int16_t) * VG_BLOCK);
    nBlk_++;
    if (rms > thrOff) quiet_ = 0; else quiet_++;
    int speechBlk = nBlk_ - speechStart_ - quiet_;
    int speechMs = speechBlk * VG_BLOCK_MS;

    if (speechMs > VG_MAX_MS) { st_ = DROP; dropQuiet_ = 0; return EV_REJECTED; }
    if (quiet_ >= VG_HANG_BLOCKS) {
      st_ = IDLE; ringCnt_ = ringPos_ = 0; onCnt_ = 0;
      if (speechMs < VG_MIN_MS) return EV_REJECTED;
      int keep = nBlk_ - (quiet_ > VG_TAIL_BLOCKS ? quiet_ - VG_TAIL_BLOCKS : 0);
      outLen_ = (size_t)keep * VG_BLOCK;
      return EV_UTTERANCE;
    }
    if (!announced_ && speechMs >= VG_MIN_MS) { announced_ = true; return EV_SPEECH; }
    return EV_NONE;
  }

  float noiseLevel() const { return noise_; }

  bool active() const { return st_ == SPEECH; }

  void keep(const int32_t *raw) {
    if (st_ != IDLE) reset();
    int16_t blk[VG_BLOCK];
    dcBlock(raw, blk);
    memcpy(ring_[ringPos_], blk, sizeof(int16_t) * VG_BLOCK);
    ringPos_ = (ringPos_ + 1) % VG_PRE_BLOCKS;
    if (ringCnt_ < VG_PRE_BLOCKS) ringCnt_++;
  }

  void forceStart(int preBlocks, int onsetBlocks) {
    if (st_ != IDLE || ringCnt_ == 0) return;
    int n = ringCnt_ < preBlocks ? ringCnt_ : preBlocks;
    int first = (ringCnt_ == VG_PRE_BLOCKS) ? ringPos_ : 0;
    nBlk_ = 0;
    for (int k = ringCnt_ - n; k < ringCnt_; k++) {
      memcpy(buf_ + (size_t)nBlk_ * VG_BLOCK, ring_[(first + k) % VG_PRE_BLOCKS], sizeof(int16_t) * VG_BLOCK);
      nBlk_++;
    }
    speechStart_ = nBlk_ > onsetBlocks ? nBlk_ - onsetBlocks : 0;
    quiet_ = 0; onCnt_ = 0; announced_ = true;
    st_ = SPEECH;
  }

 private:
  float dcBlock(const int32_t *raw, int16_t *blk) {
    float sumSq = 0;
    for (int i = 0; i < VG_BLOCK; i++) {
      float x = (float)(raw[i] >> 14);
      float y = x - dcX_ + 0.995f * dcY_;
      dcX_ = x; dcY_ = y;
      sumSq += y * y;
      if (y > 32767.0f) y = 32767.0f; else if (y < -32768.0f) y = -32768.0f;
      blk[i] = (int16_t)y;
    }
    return sqrtf(sumSq / VG_BLOCK);
  }
  enum { IDLE, SPEECH, DROP } st_;
  int16_t *buf_ = nullptr;
  int16_t ring_[VG_PRE_BLOCKS][VG_BLOCK];
  int ringPos_, ringCnt_, onCnt_, nBlk_, speechStart_ = 0, quiet_, dropQuiet_;
  bool announced_;
  size_t outLen_ = 0;
  float noise_ = 60.0f, dcX_ = 0, dcY_ = 0;
};

static const char *const STT_WORDS[4][8] = {
    { "a", "aa", "ah", "ay", "ei", "ey", nullptr },
    { "b", "be", "bee", "bi", "beh", nullptr },
    { "c", "ce", "cee", "se", "see", "si", "ci", "ceh" },
    { "d", "de", "dee", "di", "deh", nullptr },
};
static const char *const STT_FILLER[] = { "huruf", "pilihan", "jawaban", "jawab", "opsi", "pilih", "option", "answer", "letter", nullptr };

static bool sttExtractText(const char *json, char *out, size_t cap) {
  const char *last = nullptr;
  for (const char *p = json; (p = strstr(p, "\"text\"")) != nullptr; p += 6) last = p;
  if (!last) return false;
  const char *p = last + 6;
  while (*p == ' ' || *p == ':' || *p == '\t') p++;
  if (*p != '"') return false;
  p++;
  size_t n = 0;
  while (*p && *p != '"' && n + 1 < cap) {
    if (*p == '\\') {
      p++;
      if (*p == 'u' && p[1] && p[2] && p[3] && p[4]) {
        if (!strncmp(p + 1, "00e9", 4) || !strncmp(p + 1, "00e8", 4) || !strncmp(p + 1, "00ea", 4)) out[n++] = 'e';
        p += 5; continue;
      }
      if (*p == 0) break;
    }
    out[n++] = *p++;
  }
  out[n] = 0;
  return true;
}

static void sttNormalize(const char *in, char *out, size_t cap) {
  size_t n = 0; bool sp = true;
  for (const unsigned char *p = (const unsigned char *)in; *p && n + 2 < cap; p++) {
    char c = 0;
    if (*p >= 'A' && *p <= 'Z') c = (char)(*p - 'A' + 'a');
    else if (*p >= 'a' && *p <= 'z') c = (char)*p;
    else if (*p == 0xC3 && p[1] >= 0xA8 && p[1] <= 0xAA) { c = 'e'; p++; }
    if (c) { out[n++] = c; sp = false; }
    else if (!sp) { out[n++] = ' '; sp = true; }
  }
  while (n > 0 && out[n - 1] == ' ') n--;
  out[n] = 0;
}

static int sttLetterFromText(const char *text) {
  char t[96];
  sttNormalize(text, t, sizeof(t));
  const char *s = t;
  for (bool again = true; again;) {
    again = false;
    for (int i = 0; STT_FILLER[i]; i++) {
      size_t L = strlen(STT_FILLER[i]);
      if (!strncmp(s, STT_FILLER[i], L) && s[L] == ' ') { s += L + 1; again = true; break; }
    }
  }
  for (int k = 0; k < 4; k++)
    for (int i = 0; i < 8 && STT_WORDS[k][i]; i++)
      if (!strcmp(s, STT_WORDS[k][i])) return k + 1;
  return 0;
}

#define STT_WIN 16000

static void vgMakeWindow(int16_t *p, size_t n) {
  static int16_t bg[1280];
  size_t ns = n < 1280 ? n : 1280;
  if (ns == 0) { memset(p, 0, STT_WIN * sizeof(int16_t)); return; }
  memcpy(bg, p, ns * sizeof(int16_t));
  for (size_t i = ns; i < 1280; i++) bg[i] = bg[i - ns];
  if (n >= STT_WIN) {
    memmove(p, p + (n - STT_WIN), STT_WIN * sizeof(int16_t));
    return;
  }
  size_t off = (STT_WIN - n) / 2;
  memmove(p + off, p, n * sizeof(int16_t));
  for (size_t i = 0; i < off; i++) p[i] = bg[i % 1280];
  for (size_t i = off + n; i < STT_WIN; i++) p[i] = bg[i % 1280];
}

static void vgNormalize16(int16_t *p, size_t n) {
  int32_t pk = 1;
  for (size_t i = 0; i < n; i++) { int32_t a = p[i] < 0 ? -(int32_t)p[i] : p[i]; if (a > pk) pk = a; }
  float g = 22000.0f / (float)pk;
  if (g > 12.0f) g = 12.0f;
  if (g < 1.0f) g = 1.0f;
  for (size_t i = 0; i < n; i++) {
    int32_t v = (int32_t)(p[i] * g);
    p[i] = (int16_t)(v > 32767 ? 32767 : (v < -32768 ? -32768 : v));
  }
}
