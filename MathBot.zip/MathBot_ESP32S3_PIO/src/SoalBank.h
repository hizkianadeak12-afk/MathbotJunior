#pragma once
#include <Arduino.h>

struct SoalItem { const char *q, *c, *w1, *w2, *w3, *clue; };
#define S(q, c, a, b, d, k) { q, c, a, b, d, k }

const int BANK_N = 50;

#include "bank_easy.h"
#include "bank_medium.h"
#include "bank_hard.h"

const SoalItem *const BANK_PTR[3][4] = {
  { BANK_E0, BANK_E1, BANK_E2, BANK_E3 },
  { BANK_M0, BANK_M1, BANK_M2, BANK_M3 },
  { BANK_H0, BANK_H1, BANK_H2, BANK_H3 }
};

#include "Explain.h"
