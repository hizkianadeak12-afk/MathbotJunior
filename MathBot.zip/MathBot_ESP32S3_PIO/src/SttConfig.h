#pragma once

#define STT_ENABLED   1
#define STT_DEBUG     1

#define STT_MODE      2

#define WIT_TOKEN     "ISI_SERVER_ACCESS_TOKEN_WIT"
#define WIT_URL       "https://api.wit.ai/dictation?v=20240304"

#define EI_LIB_HEADER <cebai-project-1_inferencing.h>
#define EI_MIN_CONF   0.60f

#define REC_BAUD      921600
