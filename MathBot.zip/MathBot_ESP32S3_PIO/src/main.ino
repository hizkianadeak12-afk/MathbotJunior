#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <XPT2046_Touchscreen.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <AudioFileSourcePROGMEM.h>
#include <AudioGeneratorMP3.h>
#include <AudioOutput.h>
#include "Types.h"
#include "SoalBank.h"
#include "driver/i2s.h"
#include "SttConfig.h"
#include "Voice.h"
#include <Fonts/FreeSansBold9pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <Fonts/FreeSansBold18pt7b.h>
#if STT_ENABLED && STT_MODE == 2
#include EI_LIB_HEADER
#endif

#define TFT_CS     10
#define TFT_DC      9
#define TFT_RST     8
#define TFT_MOSI   11
#define TFT_SCK    12

#define T_CLK      18
#define T_DIN      17
#define T_DO       14
#define T_CS       16

#define KEY_SDA     3
#define KEY_SCL    46

#define DEBUG_TOUCH 0
#define TS_MINX  200
#define TS_MAXX 3800
#define TS_MINY  200
#define TS_MAXY 3800
#define TS_MINZ    0

Adafruit_ILI9341 tft(TFT_CS, TFT_DC, TFT_RST);
SPIClass touchSPI(HSPI);
XPT2046_Touchscreen ts(T_CS);

#define RGB(r,g,b) ((uint16_t)((((r)&0xF8)<<8)|(((g)&0xFC)<<3)|((b)>>3)))
#define C_BG       RGB(255,251,235)
#define C_PANEL    RGB(241,245,249)
#define C_INK      RGB(30,41,59)
#define C_MUTED    RGB(100,116,139)
#define C_INDIGO   RGB(99,102,241)
#define C_LIGHTIND RGB(224,231,255)
#define C_CORAL    RGB(255,122,92)
#define C_PURPLE   RGB(143,136,255)
#define C_GOLDBG   RGB(255,244,222)
#define C_GOLDTXT  RGB(154,106,0)
#define C_OKBG     RGB(209,250,229)
#define C_OKTXT    RGB(5,150,105)
#define C_ERRBG    RGB(254,226,226)
#define C_ERRTXT   RGB(185,28,28)
#define C_WHITE    0xFFFF
#define C_CARD     0xFFFF
#define C_CELEB    RGB(255,243,176)
#define C_TRACK    RGB(226,232,240)
#define C_RED      RGB(239,68,68)
#define C_ORANGE   RGB(249,115,22)
#define C_YELLOW   RGB(250,204,21)
#define C_GREEN    RGB(16,185,129)
#define C_SKY      RGB(59,130,246)
#define C_PINK     RGB(236,72,153)

const uint16_t BTN_COL[4] = { RGB(239,68,68), RGB(16,185,129), RGB(250,204,21), RGB(59,130,246) };
const char BTN_LTR[4] = { 'A', 'B', 'C', 'D' };
const uint16_t CONF_COL[8] = { RGB(239,68,68), RGB(249,115,22), RGB(250,204,21), RGB(16,185,129),
                               RGB(59,130,246), RGB(168,85,247), RGB(236,72,153), RGB(20,184,166) };
const uint16_t LV_COL[3]     = { RGB(16,185,129), RGB(245,158,11), RGB(236,72,153) };
const uint16_t BANNER_COL[6] = { RGB(255,122,92), RGB(99,102,241), RGB(16,185,129),
                                 RGB(236,72,153), RGB(59,130,246), RGB(168,85,247) };

#define MIC_SCK    4
#define MIC_WS     5
#define MIC_SD    13
#define MIC_PORT  I2S_NUM_1
#define MIC_RATE  16000
#define MIC_CHANNEL I2S_CHANNEL_FMT_ONLY_LEFT
#define MIC_BLOCK VG_BLOCK
#if STT_ENABLED && STT_MODE == 2
static_assert(EI_CLASSIFIER_FREQUENCY == MIC_RATE, "Model Edge Impulse harus dilatih pada 16 kHz (sama dengan MIC_RATE)");
#endif

const uint32_t VOICE_DEAF_MS  = 300;
const uint32_t VOICE_AFTER_TTS_MS = 60;

#ifndef BARGE_IN
#define BARGE_IN          1
#endif
#define BARGE_MIN_RMS     200.0f
#define BARGE_RATIO       1.8f
#define BARGE_BLOCKS      6
#define BARGE_GRACE_MS    400
#define BARGE_DECAY       0.992f
#define BARGE_RESUME_MS   1600
#define BARGE_DEBUG       1
volatile bool     bargeOpen    = false;
volatile bool     bargeUttered = false;
volatile uint32_t bargeAt      = 0;
volatile uint8_t  bargeFails   = 0;

volatile uint8_t micResult = 0;
volatile uint8_t micState  = 0;
volatile uint32_t micEpoch = 0;
volatile bool    micFlush  = false;
volatile bool    micOn     = true;
volatile uint8_t micHw     = 0;
volatile float   micRms    = 0;
volatile uint32_t micLastLive = 0;
volatile bool    micTestMode = false;
volatile uint16_t micLastUttMs = 0;
volatile uint8_t micLastEv = 0;
volatile uint32_t micEvAt = 0;

#ifndef MIC_GAIN
#define MIC_GAIN 3
#endif
volatile bool    sttBusy   = false;
volatile bool    sndBusy   = false;
volatile uint32_t sndQuietUntil = 0;
int clapPreview = -1;

extern volatile bool ttsBusy;
extern volatile bool ttsPlaying;
extern volatile uint32_t ttsStartMs;
extern volatile bool ttsConnOpen;
extern volatile bool ttsDropReq;
extern volatile bool qActive;
void ttsStop();

#include "Stt.h"

static VoiceGate vg;

void micClear() {
  micResult = 0;
  micState = 0;
  micEpoch = micEpoch + 1;
  micFlush = true;
}

static i2s_channel_fmt_t micChan = MIC_CHANNEL;
static bool micInstall(i2s_channel_fmt_t ch);
static bool micProbe();
static void micRedetect();
#define MIC_ALIVE_RMS 0.3f

void micTask(void *arg) {
  static int32_t raw[MIC_BLOCK];
  uint32_t deafUntil = 0, lastLog = 0, lastRedetect = 0;
  bool wasTts = false;
  bool bargeRec = false, wasBargeMode = false;
  uint32_t playEdge = 0, lastBargeLog = 0;
  float echoPk = 0;
  int bargeCnt = 0;
  micLastLive = millis();

  for (;;) {
    size_t br = 0;
    i2s_read(MIC_PORT, raw, sizeof(raw), &br, portMAX_DELAY);
    if (br != sizeof(raw)) continue;
    uint32_t now = millis();

    {
      float mean = 0, sq = 0;
      for (int i = 0; i < MIC_BLOCK; i++) mean += (float)(raw[i] >> 14);
      mean /= MIC_BLOCK;
      for (int i = 0; i < MIC_BLOCK; i++) { float d = (float)(raw[i] >> 14) - mean; sq += d * d; }
      float rms = sqrtf(sq / MIC_BLOCK);
      micRms = rms;
      if (rms > MIC_ALIVE_RMS) micLastLive = now;
      micHw = ((int32_t)(now - micLastLive) > 8000) ? 2 : 1;
    }

    if (micHw == 2 && (int32_t)(now - lastRedetect) > 6000) {
      lastRedetect = now;
      micRedetect();
      vg.reset();
      continue;
    }

    bool ttsHold = ttsPlaying;
    if (ttsHold) wasTts = true;
    else if (wasTts) { wasTts = false; deafUntil = now + VOICE_AFTER_TTS_MS; }

    if (micFlush) {
      micFlush = false;
      vg.reset();
      bargeRec = false; bargeCnt = 0;
      deafUntil = now + VOICE_DEAF_MS;
    }
    if (bargeRec && (int32_t)(now - bargeAt) > 2500) bargeRec = false;

#if BARGE_IN && STT_MODE != 3
    const bool bargeAllowed = micOn && qActive && !sttBusy && !micTestMode && vg.ready() && bargeFails == 0;

    if (bargeAllowed && !bargeRec && ttsPlaying && vg.active()) {
      bargeRec = true; bargeAt = now; bargeUttered = false; bargeOpen = true; micState = 1;
      ttsStop();
      Serial.println("BARGE: anak bicara di sela bacaan -> bacaan dihentikan, mendengarkan");
    }
    const bool bargeMode = bargeAllowed && !bargeRec && ttsPlaying;
    if (bargeMode && !wasBargeMode) { playEdge = now; bargeCnt = 0; }
    wasBargeMode = bargeMode;
#else
    const bool bargeMode = false;
#endif

    bool blocked = !vg.ready() || (sndBusy && !ttsPlaying) || (ttsHold && !bargeMode && !bargeRec) || sttBusy || (!bargeRec && (int32_t)(now - sndQuietUntil) < 0);
#if STT_DEBUG
    if (micOn && qActive && now - lastLog > 3000) {
      lastLog = now;
      Serial.printf("MIC: suara %.0f (hw %u) %s | vg.ready=%d sndBusy=%d tts(main/busy)=%d/%d sttBusy=%d\n", (double)micRms, (unsigned)micHw,
                    blocked ? "DIBLOKIR" : "mendengarkan", (int)vg.ready(), (int)sndBusy, (int)ttsPlaying, (int)ttsBusy, (int)sttBusy);
    }
#endif
#if STT_MODE != 3
    blocked = blocked || (!micTestMode && (!micOn || !qActive));
#endif
    if (micTestMode) blocked = !vg.ready() || sttBusy;
    if (blocked) {
      vg.reset();
      continue;
    }
    static int32_t amp[MIC_BLOCK];
    for (int i = 0; i < MIC_BLOCK; i++) {
      int64_t v = (int64_t)raw[i] * MIC_GAIN;
      amp[i] = (v > 2147483647LL) ? 2147483647 : (v < -2147483648LL) ? (int32_t)-2147483648LL : (int32_t)v;
    }
#if BARGE_IN && STT_MODE != 3
    if (bargeMode) {

      vg.keep(amp);
      bool learn = (int32_t)(now - playEdge) < BARGE_GRACE_MS || (int32_t)(now - deafUntil) < 0;
      float thr = fmaxf(BARGE_MIN_RMS, BARGE_RATIO * echoPk);
      float r = micRms;
      if (!learn && r > thr) bargeCnt++;
      else { bargeCnt = 0; echoPk = fmaxf(r, echoPk * BARGE_DECAY); }
#if BARGE_DEBUG
      if (now - lastBargeLog > 1000) {
        lastBargeLog = now;
        Serial.printf("BARGE: gema=%d batas=%d suara=%d %s\n", (int)echoPk, (int)thr, (int)r, learn ? "(belajar)" : "(siaga)");
      }
#endif
      if (bargeCnt >= BARGE_BLOCKS) {
        bargeCnt = 0;
        vg.forceStart(BARGE_BLOCKS + 4, BARGE_BLOCKS);
        bargeRec = true; bargeAt = now; bargeUttered = false; bargeOpen = true; micState = 1;
        ttsStop();
        Serial.printf("BARGE: suara %d > batas %d -> bacaan dihentikan, mendengarkan jawaban\n", (int)r, (int)thr);
      }
      continue;
    }
#endif
    VoiceGate::Event ev = vg.feedRaw(amp, !micTestMode && (int32_t)(now - deafUntil) < 0);
    if (ev == VoiceGate::EV_SPEECH) {
      if (micState == 0) micState = 1;
#if BARGE_IN && STT_MODE != 3
      if (ttsBusy && !bargeRec && micOn && qActive && bargeFails == 0) {
        bargeRec = true; bargeAt = now; bargeUttered = false; bargeOpen = true;
        ttsStop();
        Serial.println("BARGE: anak bicara di sela bacaan -> bacaan dihentikan");
      }
#endif
    } else if (ev == VoiceGate::EV_UTTERANCE) {
      micLastUttMs = (uint16_t)((uint32_t)vg.length() * 1000UL / MIC_RATE); micLastEv = 1; micEvAt = now;
      bargeUttered = true; bargeRec = false;
      sttSubmit(vg.length());
    } else if (ev == VoiceGate::EV_REJECTED) {
      micLastEv = 2; micEvAt = now;
      bargeRec = false;
      if (micState == 1) micState = 0;
    }
  }
}

static bool micInstall(i2s_channel_fmt_t ch) {
  i2s_config_t cfg;
  memset(&cfg, 0, sizeof(cfg));
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  cfg.sample_rate = MIC_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
  cfg.channel_format = ch;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 12;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;

  i2s_pin_config_t pins;
  memset(&pins, 0, sizeof(pins));
  pins.mck_io_num = I2S_PIN_NO_CHANGE;
  pins.bck_io_num = MIC_SCK;
  pins.ws_io_num = MIC_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = MIC_SD;

  if (i2s_driver_install(MIC_PORT, &cfg, 0, NULL) != ESP_OK) return false;
  i2s_set_pin(MIC_PORT, &pins);
  i2s_zero_dma_buffer(MIC_PORT);
  micChan = ch;
  return true;
}

static bool micProbe() {
  static int32_t raw[MIC_BLOCK];
  float best = 0;
  for (int i = 0; i < 60; i++) {
    size_t br = 0;
    if (i2s_read(MIC_PORT, raw, sizeof(raw), &br, pdMS_TO_TICKS(200)) != ESP_OK || br != sizeof(raw)) continue;
    if (i < 40) continue;
    float mean = 0, sq = 0;
    for (int k = 0; k < MIC_BLOCK; k++) mean += (float)(raw[k] >> 14);
    mean /= MIC_BLOCK;
    for (int k = 0; k < MIC_BLOCK; k++) { float d = (float)(raw[k] >> 14) - mean; sq += d * d; }
    float rms = sqrtf(sq / MIC_BLOCK);
    if (rms > best) best = rms;
  }
  Serial.printf("Mic: uji sinyal kanal %s = %.1f (harus > %.0f)\n", micChan == I2S_CHANNEL_FMT_ONLY_LEFT ? "KIRI" : "KANAN", (double)best, (double)MIC_ALIVE_RMS);
  return best > MIC_ALIVE_RMS;
}

static void micRedetect() {
  Serial.println("Mic: belum ada sinyal - deteksi ulang kanal KIRI / KANAN ...");
  i2s_driver_uninstall(MIC_PORT);
  i2s_channel_fmt_t other = (micChan == I2S_CHANNEL_FMT_ONLY_LEFT) ? I2S_CHANNEL_FMT_ONLY_RIGHT : I2S_CHANNEL_FMT_ONLY_LEFT;
  i2s_channel_fmt_t order[2] = { other, micChan };
  bool live = false;
  for (int k = 0; k < 2 && !live; k++) {
    if (micInstall(order[k])) {
      if (micProbe()) live = true; else i2s_driver_uninstall(MIC_PORT);
    }
  }
  if (!live) micInstall(MIC_CHANNEL);
  if (live) {
    micLastLive = millis();
    micHw = 1;
    Serial.printf("Mic: TERDETEKSI di kanal %s\n", micChan == I2S_CHANNEL_FMT_ONLY_LEFT ? "KIRI" : "KANAN");
  }
}

void micInit() {
  if (!micInstall(MIC_CHANNEL)) { Serial.println("Mic: gagal install I2S"); micHw = 2; return; }
  bool live = micProbe();
  if (!live) {
    i2s_driver_uninstall(MIC_PORT);
    i2s_channel_fmt_t other = (MIC_CHANNEL == I2S_CHANNEL_FMT_ONLY_LEFT) ? I2S_CHANNEL_FMT_ONLY_RIGHT : I2S_CHANNEL_FMT_ONLY_LEFT;
    if (micInstall(other)) {
      if (micProbe()) { live = true; Serial.println("Mic: sinyal ditemukan di kanal lain - kanal dipindah otomatis (cek pin L/R INMP441)"); }
      else { i2s_driver_uninstall(MIC_PORT); micInstall(MIC_CHANNEL); }
    } else {
      micInstall(MIC_CHANNEL);
    }
  }
  micHw = live ? 1 : 2;
  micLastLive = millis();
  if (!live) Serial.println("Mic: TIDAK ADA SINYAL dari INMP441. Cek kabel: VDD=3V3, GND, SCK=GPIO4, WS=GPIO5, SD=GPIO13, L/R=GND, dan solderan pin.");
  else Serial.println("Mic: INMP441 terdeteksi dan mengirim sinyal.");
  int16_t *pcm = sttInit();
  if (pcm) vg.begin(pcm);
  xTaskCreatePinnedToCore(micTask, "micTask", 6144, NULL, 5, NULL, 0);
}

#define SND_ENABLED 1
#define SPK_BCLK   15
#define SPK_LRC     7
#define SPK_DIN     6
#define SPK_PORT   I2S_NUM_0
#define SPK_RATE   16000
#define SPK_DMA_COUNT 12
#define SPK_DMA_LEN   256
const int SPK_VOLUME = 4000;

enum { SND_NONE = 0, SND_CLICK, SND_OK, SND_WRONG, SND_TIMEUP, SND_TICK, SND_WIN, SND_LOSE };

const uint16_t S_CLICK[]  = { 1300, 30 };
const uint16_t S_OK[]     = { 523, 100, 659, 100, 784, 100, 1047, 100, 1319, 260 };
const uint16_t S_WRONG[]  = { 311, 170, 233, 340 };
const uint16_t S_TIMEUP[] = { 988, 130, 0, 60, 988, 130, 0, 60, 988, 130, 0, 60, 740, 420 };
const uint16_t S_TICK[]   = { 1000, 70 };
const uint16_t S_WIN[]    = { 523, 120, 659, 120, 784, 120, 1047, 120, 784, 120, 1047, 120, 1319, 400 };
const uint16_t S_LOSE[]   = { 392, 220, 349, 220, 330, 220, 262, 520 };

QueueHandle_t sndQ = nullptr;
volatile bool ttsPlaying = false;
volatile bool ttsAbort   = false;

void sndPlay(uint8_t id) {
#if SND_ENABLED
  if (ttsBusy && (id == SND_CLICK || id == SND_TICK)) return;
  if (ttsBusy) Serial.printf("TTS: bacaan dihentikan oleh efek suara #%u (1 klik/sentuh, 2 benar, 3 salah, 4 waktu habis, 5 tik)\n", (unsigned)id);
  ttsAbort = true;
  if (sndQ) xQueueOverwrite(sndQ, &id);
#endif
}

bool sndTone(uint16_t f, uint16_t ms) {
  static int16_t buf[128 * 2];
  int total = (int)((uint32_t)SPK_RATE * ms / 1000);
  int ramp = SPK_RATE / 200;
  float phase = 0, step = 2.0f * PI * f / SPK_RATE;
  int i = 0;
  while (i < total) {
    int n = total - i;
    if (n > 128) n = 128;
    for (int j = 0; j < n; j++, i++) {
      float env = 1.0f;
      if (i < ramp) env = (float)i / ramp;
      else if (total - i < ramp) env = (float)(total - i) / ramp;
      int16_t s = f ? (int16_t)(sinf(phase) * SPK_VOLUME * env) : 0;
      phase += step;
      buf[j * 2] = s;
      buf[j * 2 + 1] = s;
    }
    size_t w;
    i2s_write(SPK_PORT, buf, n * 4, &w, portMAX_DELAY);
    if (uxQueueMessagesWaiting(sndQ) > 0) return false;
  }
  return true;
}

void sndTask(void *arg) {
  uint8_t id;
  for (;;) {
    if (xQueueReceive(sndQ, &id, portMAX_DELAY) != pdTRUE) continue;
    const uint16_t *seq = nullptr;
    int n = 0;
    switch (id) {
      case SND_CLICK:  seq = S_CLICK;  n = sizeof(S_CLICK)  / 4; break;
      case SND_OK:     seq = S_OK;     n = sizeof(S_OK)     / 4; break;
      case SND_WRONG:  seq = S_WRONG;  n = sizeof(S_WRONG)  / 4; break;
      case SND_TIMEUP: seq = S_TIMEUP; n = sizeof(S_TIMEUP) / 4; break;
      case SND_TICK:   seq = S_TICK;   n = sizeof(S_TICK)   / 4; break;
      case SND_WIN:    seq = S_WIN;    n = sizeof(S_WIN)    / 4; break;
      case SND_LOSE:   seq = S_LOSE;   n = sizeof(S_LOSE)   / 4; break;
    }
    if (!seq) continue;
    for (int w = 0; ttsPlaying && w < 40; w++) vTaskDelay(pdMS_TO_TICKS(10));
    sndBusy = true;
    for (int i = 0; i < n; i++) if (!sndTone(seq[i * 2], seq[i * 2 + 1])) break;
    sndBusy = false;
    sndQuietUntil = millis() + 200;
  }
}

void sndInit() {
#if SND_ENABLED
  i2s_config_t cfg;
  memset(&cfg, 0, sizeof(cfg));
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  cfg.sample_rate = SPK_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = SPK_DMA_COUNT;
  cfg.dma_buf_len = SPK_DMA_LEN;
  cfg.tx_desc_auto_clear = true;

  i2s_pin_config_t pins;
  memset(&pins, 0, sizeof(pins));
  pins.mck_io_num = I2S_PIN_NO_CHANGE;
  pins.bck_io_num = SPK_BCLK;
  pins.ws_io_num = SPK_LRC;
  pins.data_out_num = SPK_DIN;
  pins.data_in_num = I2S_PIN_NO_CHANGE;

  if (i2s_driver_install(SPK_PORT, &cfg, 0, NULL) != ESP_OK) { Serial.println("Speaker: gagal install I2S"); return; }
  i2s_set_pin(SPK_PORT, &pins);
  i2s_zero_dma_buffer(SPK_PORT);
  sndQ = xQueueCreate(1, sizeof(uint8_t));
  xTaskCreatePinnedToCore(sndTask, "sndTask", 4096, NULL, 2, NULL, 0);
#endif
}

#include "Tts.h"

bool hit(const Rect &r, int16_t px, int16_t py) {
  return px >= r.x && px < r.x + r.w && py >= r.y && py < r.y + r.h;
}

int wrapText(const String &s, int cpl, String *out, int maxLines) {
  int n = 0, i = 0, len = s.length();
  String line = "";
  while (i <= len && n < maxLines) {
    int j = s.indexOf(' ', i);
    if (j < 0) j = len;
    String w = s.substring(i, j);
    if (line.length() == 0) line = w;
    else if ((int)(line.length() + 1 + w.length()) <= cpl) line += " " + w;
    else { out[n++] = line; line = w; }
    i = j + 1;
  }
  if (line.length() && n < maxLines) out[n++] = line;
  return n;
}

void printCenter(const String &s, int cx, int y, int size, uint16_t col) {
  tft.setTextSize(size);
  tft.setTextColor(col);
  int w = s.length() * 6 * size;
  tft.setCursor(cx - w / 2, y);
  tft.print(s);
}

void textInBox(const String &s, const Rect &r, uint16_t col, int maxSize = 2) {
  String ln[10];
  int size = maxSize, n = 0;
  while (true) {
    int cpl = (r.w - 8) / (6 * size);
    if (cpl < 1) cpl = 1;
    n = wrapText(s, cpl, ln, 10);
    if (n * 8 * size <= r.h - 2 || size == 1) break;
    size--;
  }
  int lh = 8 * size;
  int y = r.y + (r.h - n * lh) / 2;
  tft.setTextSize(size);
  tft.setTextColor(col);
  for (int i = 0; i < n; i++) {
    int w = ln[i].length() * 6 * size;
    tft.setCursor(r.x + (r.w - w) / 2, y);
    tft.print(ln[i]);
    y += lh;
  }
}

uint16_t shade(uint16_t c, uint8_t k) {
  uint16_t r = ((c >> 11) & 0x1F) * k / 255;
  uint16_t g = ((c >> 5) & 0x3F) * k / 255;
  uint16_t b = (c & 0x1F) * k / 255;
  return (r << 11) | (g << 5) | b;
}

uint16_t txtOn(uint16_t c) { return (c == BTN_COL[2]) ? C_INK : C_WHITE; }

uint16_t inkOf(uint16_t c) { return (c == BTN_COL[2]) ? RGB(161,98,7) : c; }

void keyChip(int x, int y, int idx) {
  tft.fillRoundRect(x, y, 16, 14, 5, C_WHITE);
  tft.setTextSize(1);
  tft.setTextColor(inkOf(BTN_COL[idx]));
  tft.setCursor(x + 5, y + 3);
  tft.print(BTN_LTR[idx]);
}

void drawRobot(int x, int y, int s) {
  tft.fillRoundRect(x + 4 * s, y + 8 * s, 32 * s, 28 * s, 10 * s, C_PURPLE);
  tft.fillRoundRect(x + 11 * s, y + 2 * s, 18 * s, 5 * s, 2 * s, C_INK);
  tft.fillCircle(x + 14 * s, y + 21 * s, 3 * s, C_INK);
  tft.fillCircle(x + 26 * s, y + 21 * s, 3 * s, C_INK);
  tft.fillCircle(x + 14 * s, y + 20 * s, max(1, s), C_WHITE);
  tft.fillCircle(x + 26 * s, y + 20 * s, max(1, s), C_WHITE);
  tft.drawLine(x + 13 * s, y + 29 * s, x + 17 * s, y + 31 * s, C_INK);
  tft.drawLine(x + 17 * s, y + 31 * s, x + 23 * s, y + 31 * s, C_INK);
  tft.drawLine(x + 23 * s, y + 31 * s, x + 27 * s, y + 29 * s, C_INK);
  if (s > 1) {
    tft.drawLine(x + 13 * s, y + 29 * s + 1, x + 17 * s, y + 31 * s + 1, C_INK);
    tft.drawLine(x + 17 * s, y + 31 * s + 1, x + 23 * s, y + 31 * s + 1, C_INK);
    tft.drawLine(x + 23 * s, y + 31 * s + 1, x + 27 * s, y + 29 * s + 1, C_INK);
  }
}

void drawStar(Adafruit_GFX &g, int cx, int cy, int r, uint16_t col) {
  int16_t px[10], py[10];
  for (int i = 0; i < 10; i++) {
    float a = -1.5708f + i * 0.62832f;
    float rr = (i % 2 == 0) ? r : r * 0.45f;
    px[i] = cx + (int)(cosf(a) * rr);
    py[i] = cy + (int)(sinf(a) * rr);
  }
  for (int i = 0; i < 10; i++) g.fillTriangle(cx, cy, px[i], py[i], px[(i + 1) % 10], py[(i + 1) % 10], col);
}

void thickLine(Adafruit_GFX &g, int x0, int y0, int x1, int y1, uint16_t c) {
  for (int d = -1; d <= 1; d++) {
    g.drawLine(x0 + d, y0, x1 + d, y1, c);
    g.drawLine(x0, y0 + d, x1, y1 + d, c);
  }
}

void drawStripe(int y, int h) {
  for (int i = 0; i < 8; i++) tft.fillRect(i * 40, y, 40, h, CONF_COL[i]);
}

void drawBalloon(int x, int y, uint16_t col) {
  tft.fillCircle(x, y, 13, col);
  tft.fillTriangle(x - 3, y + 12, x + 3, y + 12, x, y + 18, col);
  tft.drawLine(x, y + 18, x - 4, y + 29, C_MUTED);
  tft.drawLine(x - 4, y + 29, x + 2, y + 40, C_MUTED);
  tft.fillCircle(x - 5, y - 5, 3, C_WHITE);
}

void printCenterShadow(const String &s, int cx, int y, int size, uint16_t col, uint16_t sh) {
  printCenter(s, cx + 1, y + 2, size, sh);
  printCenter(s, cx, y, size, col);
}

#define C_NAVY    RGB(30,58,138)
#define C_BLUE2   RGB(37,99,235)
#define C_SKY1    RGB(147,205,250)
#define C_SKY2    RGB(226,243,255)
#define C_CLOUD   RGB(250,253,255)
#define C_CLOUD2  RGB(196,225,249)
#define C_VISOR   RGB(15,23,42)
#define C_EYE     RGB(125,211,252)
#define C_BOTW    RGB(246,249,255)
#define C_BOTE    RGB(186,214,250)
#define C_BOTB    RGB(59,130,246)
#define C_BLUSH   RGB(251,113,133)
#define C_SUNY    RGB(253,224,71)
#define C_SUNY2   RGB(234,179,8)
#define C_GRN2    RGB(34,197,94)
#define C_PUR2    RGB(168,85,247)
#define C_PINK2   RGB(244,114,182)

uint16_t fxFlatBg = 0;
bool fxClouds = true;
bool fxIntro = false;
uint16_t endBg = RGB(255,246,214);

inline void introWait(int ms) { if (fxIntro) delay(ms); }

uint16_t mix565(uint16_t a, uint16_t b, int t) {
  int ar = (a >> 11) & 31, ag = (a >> 5) & 63, ab = a & 31;
  int br = (b >> 11) & 31, bg = (b >> 5) & 63, bb = b & 31;
  int r = (ar * (255 - t) + br * t) / 255;
  int g = (ag * (255 - t) + bg * t) / 255;
  int bl = (ab * (255 - t) + bb * t) / 255;
  return (uint16_t)((r << 11) | (g << 5) | bl);
}

uint16_t skyCol(int y) {
  y &= ~3;
  if (y < 0) y = 0;
  if (y > 239) y = 239;
  return mix565(C_SKY1, C_SKY2, y * 255 / 239);
}
uint16_t bgAt(int y) { return fxFlatBg ? fxFlatBg : skyCol(y); }

void paintSkyOn(Adafruit_GFX &g, int ox, int oy, int x, int y, int w, int h) {
  for (int by = y & ~3; by < y + h; by += 4) {
    int y0 = (by > y) ? by : y;
    int y1 = (by + 4 < y + h) ? by + 4 : y + h;
    if (y1 > y0) g.fillRect(x - ox, y0 - oy, w, y1 - y0, bgAt(by));
  }
}

const int16_t CLOUD_LIST[][3] = { {12,238,30}, {50,243,25}, {92,246,21}, {160,252,18},
                                  {214,247,23}, {252,241,29}, {296,236,28} };
void paintCloudsOn(Adafruit_GFX &g, int ox, int oy) {
  int n = sizeof(CLOUD_LIST) / sizeof(CLOUD_LIST[0]);
  for (int i = 0; i < n; i++) g.fillCircle(CLOUD_LIST[i][0] - ox, CLOUD_LIST[i][1] - oy + 3, CLOUD_LIST[i][2], C_CLOUD2);
  for (int i = 0; i < n; i++) g.fillCircle(CLOUD_LIST[i][0] - ox, CLOUD_LIST[i][1] - oy, CLOUD_LIST[i][2], C_CLOUD);
}

void drawSky(bool clouds = true) {
  fxFlatBg = 0;
  fxClouds = clouds;
  paintSkyOn(tft, 0, 0, 0, 0, 320, 240);
  if (clouds) paintCloudsOn(tft, 0, 0);
}

const GFXfont *FNT_L = &FreeSansBold18pt7b;
const GFXfont *FNT_M = &FreeSansBold12pt7b;
const GFXfont *FNT_S = &FreeSansBold9pt7b;

int textW(const GFXfont *f, const String &s) {
  if (!f) return s.length() * 6;
  int16_t x1, y1; uint16_t w, h;
  tft.setTextSize(1);
  tft.setFont(f);
  tft.getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  tft.setFont();
  return w;
}

int capH(const GFXfont *f) {
  if (f == FNT_L) return 24;
  if (f == FNT_M) return 17;
  if (f == FNT_S) return 12;
  return 8;
}

const GFXfont *fitFont(const String &s, int maxW, int maxPt) {
  const GFXfont *list[3] = { FNT_L, FNT_M, FNT_S };
  const int pts[3] = { 18, 12, 9 };
  for (int i = 0; i < 3; i++) {
    if (pts[i] > maxPt) continue;
    if (textW(list[i], s) <= maxW) return list[i];
  }
  return nullptr;
}

void gText(Adafruit_GFX &g, const GFXfont *f, const String &s, int cx, int base, uint16_t col) {
  g.setTextSize(1);
  g.setTextColor(col);
  if (!f) {
    int w = s.length() * 6;
    g.setFont();
    g.setCursor(cx - w / 2, base);     g.print(s);
    g.setCursor(cx - w / 2 + 1, base); g.print(s);
    return;
  }
  int16_t x1, y1; uint16_t w, h;
  g.setFont(f);
  g.getTextBounds(s, 0, 0, &x1, &y1, &w, &h);
  g.setCursor(cx - (int)w / 2 - x1, base);
  g.print(s);
  g.setFont();
}

void gOutline(const GFXfont *f, const String &s, int cx, int base, uint16_t col, uint16_t ol, int o) {
  for (int dy = -o; dy <= o; dy += o)
    for (int dx = -o; dx <= o; dx += o)
      if (dx || dy) gText(tft, f, s, cx + dx, base + dy, ol);
  gText(tft, f, s, cx, base, col);
}

void labelIn(const String &s, int x, int y, int w, int h, uint16_t col, int maxPt = 12) {
  const GFXfont *f = fitFont(s, w - 8, maxPt);
  if (f) gText(tft, f, s, x + w / 2, y + (h + capH(f)) / 2, col);
  else {
    Rect r = { (int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h };
    textInBox(s, r, col, (h >= 30) ? 2 : 1);
  }
}

void txtB(int cx, int y, const String &s, uint16_t col) {
  gText(tft, nullptr, s, cx, y, col);
}

void fxButton(int x, int y, int w, int h, uint16_t c) {
  tft.fillRoundRect(x, y + 3, w, h - 3, 11, shade(c, 140));
  tft.fillRoundRect(x, y, w, h - 4, 11, c);
  tft.fillRoundRect(x + 4, y + 3, w - 8, (h - 4) / 3, 6, mix565(c, 0xFFFF, 70));
  tft.drawRoundRect(x, y, w, h - 4, 11, C_WHITE);
  tft.drawRoundRect(x + 1, y + 1, w - 2, h - 6, 10, C_WHITE);
}

void fxPill(int x, int y, int w, int h, uint16_t c, const String &s, uint16_t tc, int maxPt) {
  tft.fillRoundRect(x, y + 3, w, h - 3, h / 2, shade(c, 150));
  tft.fillRoundRect(x, y, w, h - 3, h / 2, c);
  tft.drawRoundRect(x, y, w, h - 3, h / 2, C_WHITE);
  if (s.length()) labelIn(s, x, y, w, h - 3, tc, maxPt);
}

void drawBtn(const Rect &r, uint16_t bg, const String &label, uint16_t fg = C_WHITE, int maxSize = 2) {
  fxButton(r.x, r.y, r.w, r.h, bg);
  if (label.length()) labelIn(label, r.x, r.y, r.w, r.h - 4, fg, (maxSize >= 2) ? 12 : 9);
}

const Rect R_BACK_FACE = { 2, 2, 104, 28 };
void drawBackButton(const char *label, uint16_t col) {
  const Rect &r = R_BACK_FACE;
  tft.fillRoundRect(r.x, r.y + 3, r.w, r.h - 3, 12, shade(col, 150));
  tft.fillRoundRect(r.x, r.y, r.w, r.h - 4, 12, C_WHITE);
  tft.drawRoundRect(r.x, r.y, r.w, r.h - 4, 12, col);
  tft.drawRoundRect(r.x + 1, r.y + 1, r.w - 2, r.h - 6, 11, col);
  int cy = r.y + (r.h - 4) / 2;
  tft.fillTriangle(r.x + 9, cy, r.x + 19, cy - 7, r.x + 19, cy + 7, col);
  labelIn(label, r.x + 20, r.y, r.w - 22, r.h - 4, inkOf(col), 9);
}

void icoFace(int cx, int cy, int r) {
  tft.fillCircle(cx, cy, r, C_WHITE);
  tft.fillCircle(cx - r / 3, cy - r / 5, 2, C_VISOR);
  tft.fillCircle(cx + r / 3, cy - r / 5, 2, C_VISOR);
  tft.drawLine(cx - r / 3, cy + r / 3, cx - 1, cy + r / 2, C_VISOR);
  tft.drawLine(cx - 1, cy + r / 2, cx + 1, cy + r / 2, C_VISOR);
  tft.drawLine(cx + 1, cy + r / 2, cx + r / 3, cy + r / 3, C_VISOR);
  tft.fillCircle(cx - r / 2 - 1, cy + r / 6, 2, C_BLUSH);
  tft.fillCircle(cx + r / 2 + 1, cy + r / 6, 2, C_BLUSH);
}
void icoNum(int cx, int cy) {
  gOutline(FNT_M, "1", cx - 16, cy + 8, C_SUNY2, C_WHITE, 1);
  gOutline(FNT_M, "2", cx,      cy + 6, C_PINK2, C_WHITE, 1);
  gOutline(FNT_M, "3", cx + 16, cy + 8, C_GRN2,  C_WHITE, 1);
}
void icoCalc(int cx, int cy) {
  tft.fillRoundRect(cx - 10, cy - 12, 20, 24, 4, RGB(79,70,229));
  tft.drawRoundRect(cx - 10, cy - 12, 20, 24, 4, C_WHITE);
  tft.fillRect(cx - 7, cy - 9, 14, 6, RGB(190,230,255));
  for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) tft.fillRect(cx - 7 + c * 5, cy + r * 5 - 1, 3, 3, C_WHITE);
  tft.fillCircle(cx + 13, cy - 10, 4, C_SUNY);
}
void icoShapes(int cx, int cy) {
  tft.fillTriangle(cx - 15, cy + 11, cx - 3, cy + 11, cx - 9, cy - 3, RGB(14,165,233));
  tft.fillCircle(cx + 3, cy - 5, 7, C_SUNY);
  tft.fillRoundRect(cx + 1, cy + 1, 12, 11, 2, RGB(249,115,22));
}
void icoRuler(int cx, int cy) {
  tft.fillRoundRect(cx - 15, cy - 6, 30, 13, 3, RGB(147,197,253));
  tft.drawRoundRect(cx - 15, cy - 6, 30, 13, 3, C_WHITE);
  for (int i = 0; i < 7; i++) tft.drawFastVLine(cx - 12 + i * 4, cy - 5, (i & 1) ? 4 : 7, C_NAVY);
}
void icoTopic(int i, int cx, int cy) {
  if (i == 0) icoNum(cx, cy);
  else if (i == 1) icoCalc(cx, cy);
  else if (i == 2) icoShapes(cx, cy);
  else icoRuler(cx, cy);
}
void icoBulb(int cx, int cy) {
  tft.fillCircle(cx, cy - 3, 8, C_SUNY);
  tft.drawCircle(cx, cy - 3, 8, C_SUNY2);
  tft.fillRect(cx - 3, cy + 4, 7, 5, C_MUTED);
  tft.drawLine(cx - 12, cy - 3, cx - 15, cy - 3, C_SUNY2);
  tft.drawLine(cx + 12, cy - 3, cx + 15, cy - 3, C_SUNY2);
  tft.drawLine(cx - 9, cy - 11, cx - 12, cy - 14, C_SUNY2);
  tft.drawLine(cx + 9, cy - 11, cx + 12, cy - 14, C_SUNY2);
}
void icoPad(int cx, int cy) {
  tft.fillRoundRect(cx - 14, cy - 7, 28, 15, 7, C_WHITE);
  tft.fillRect(cx - 9, cy - 1, 7, 3, C_NAVY);
  tft.fillRect(cx - 7, cy - 3, 3, 7, C_NAVY);
  tft.fillCircle(cx + 6, cy - 2, 2, C_RED);
  tft.fillCircle(cx + 10, cy + 2, 2, C_SKY);
}
void icoStarBadge(int cx, int cy) { drawStar(tft, cx, cy, 6, C_SUNY); }

#define BK(v) (((v) * k + 5) / 10)
static void botHand(int st, int k, int &hx, int &hy) {
  int x = 22, y = 70;
  switch (st) {
    case 1: x = 27; y = 44; break;
    case 2: x = 31; y = 36; break;
    case 3: x = 25; y = 26; break;
    case 4: x = 15; y = 42; break;
    case 5: x = 11; y = 35; break;
    default: break;
  }
  hx = BK(x); hy = BK(y);
}

void drawBotOn(Adafruit_GFX &g, int cx, int top, int k, int mood, int armL, int armR, int t) {
  const int ey = top + BK(29), exl = cx - BK(9), exr = cx + BK(9);
  const int hr = (BK(4) < 2) ? 2 : BK(4);

  for (int s = 0; s < 2; s++) {
    int st = s ? armR : armL, dir = s ? 1 : -1;
    int hx, hy;
    botHand(st, k, hx, hy);
    int sx = cx + dir * BK(14), sy = top + BK(58);
    thickLine(g, sx, sy, cx + dir * hx, top + hy, C_BOTE);
    g.fillCircle(cx + dir * hx, top + hy, hr, C_BOTW);
    g.drawCircle(cx + dir * hx, top + hy, hr, C_BOTB);
  }

  g.fillRoundRect(cx - BK(12), top + BK(74), BK(10), BK(6), BK(2), C_BOTB);
  g.fillRoundRect(cx + BK(2),  top + BK(74), BK(10), BK(6), BK(2), C_BOTB);

  g.fillRoundRect(cx - BK(15), top + BK(52), BK(30), BK(25), BK(9), C_BOTW);
  g.drawRoundRect(cx - BK(15), top + BK(52), BK(30), BK(25), BK(9), C_BOTE);
  g.fillRoundRect(cx - BK(9), top + BK(57), BK(18), BK(14), BK(3), C_BOTB);
  int py = top + BK(64);
  g.drawFastHLine(cx - BK(6), py, BK(5) + 1, C_WHITE);
  g.drawFastVLine(cx - BK(4), py - BK(2), BK(4) + 1, C_WHITE);
  g.drawLine(cx + BK(2), py - BK(2), cx + BK(6), py + BK(2), C_WHITE);
  g.drawLine(cx + BK(2), py + BK(2), cx + BK(6), py - BK(2), C_WHITE);

  int ax = cx + ((t & 1) ? BK(1) : -BK(1));
  g.drawLine(cx, top + BK(12), ax, top + BK(6), C_BOTE);
  g.fillCircle(ax, top + BK(3), (BK(3) < 2) ? 2 : BK(3), C_BOTB);

  g.fillRoundRect(cx - BK(32), top + BK(24), BK(7), BK(15), BK(3), C_BOTB);
  g.fillRoundRect(cx + BK(25), top + BK(24), BK(7), BK(15), BK(3), C_BOTB);
  g.fillRoundRect(cx - BK(26), top + BK(12), BK(52), BK(38), BK(14), C_BOTW);
  g.drawRoundRect(cx - BK(26), top + BK(12), BK(52), BK(38), BK(14), C_BOTE);

  g.fillRoundRect(cx - BK(21), top + BK(17), BK(42), BK(28), BK(11), C_VISOR);

  for (int s = 0; s < 2; s++) {
    int ex = s ? exr : exl;
    if (mood == 1) {
      g.drawFastHLine(ex - BK(5), ey + 1, BK(10), C_EYE);
      g.drawFastHLine(ex - BK(5), ey + 2, BK(10), C_EYE);
    } else if (mood == 4) {
      int d2 = s ? -1 : 1;
      for (int d = 0; d < 2; d++) {
        g.drawLine(ex - d2 * BK(4), ey - BK(4) + d, ex + d2 * BK(3), ey + d, C_EYE);
        g.drawLine(ex + d2 * BK(3), ey + d, ex - d2 * BK(4), ey + BK(4) + d, C_EYE);
      }
    } else if (mood == 2) {
      g.fillCircle(ex, ey, BK(4), C_EYE);
      g.fillCircle(ex - 1, ey - 1, (BK(1) < 1) ? 1 : BK(1), C_WHITE);
      int ty = ey + BK(4) + ((t * 3 + s * 5) % BK(14));
      g.fillCircle(ex, ty, (BK(2) < 1) ? 1 : BK(2), RGB(147,197,253));
    } else if (mood == 3) {
      g.fillCircle(ex, ey, BK(6), C_BOTW);
      g.fillCircle(ex + ((t & 1) ? 1 : -1), ey, (BK(2) < 1) ? 1 : BK(2), C_VISOR);
    } else {
      for (int d = 0; d < 2; d++) {
        g.drawLine(ex - BK(5), ey + BK(2) + d, ex, ey - BK(3) + d, C_EYE);
        g.drawLine(ex, ey - BK(3) + d, ex + BK(5), ey + BK(2) + d, C_EYE);
      }
    }
  }
  if (mood == 2) {
    g.drawLine(exl - BK(5), ey - BK(6), exl + BK(3), ey - BK(9), C_EYE);
    g.drawLine(exr + BK(5), ey - BK(6), exr - BK(3), ey - BK(9), C_EYE);
  }

  int my = top + BK(37);
  if (mood == 0 || mood == 4) {
    g.fillCircle(cx, my - BK(1), BK(4), C_BLUSH);
    g.fillRect(cx - BK(5), my - BK(5) - 1, BK(10) + 1, BK(4) + 1, C_VISOR);
  } else if (mood == 1) {
    g.drawLine(cx - BK(4), my - BK(1), cx - BK(2), my + 1, C_EYE);
    g.drawLine(cx - BK(2), my + 1, cx + BK(2), my + 1, C_EYE);
    g.drawLine(cx + BK(2), my + 1, cx + BK(4), my - BK(1), C_EYE);
  } else if (mood == 2) {
    g.drawLine(cx - BK(4), my + BK(2), cx - BK(2), my, C_EYE);
    g.drawLine(cx - BK(2), my, cx + BK(2), my, C_EYE);
    g.drawLine(cx + BK(2), my, cx + BK(4), my + BK(2), C_EYE);
  } else {
    g.drawCircle(cx, my, (BK(3) < 2) ? 2 : BK(3), C_EYE);
  }

  int br = (BK(2) < 1) ? 1 : BK(2);
  g.fillCircle(cx - BK(16), top + BK(37), br, C_BLUSH);
  g.fillCircle(cx + BK(16), top + BK(37), br, C_BLUSH);
}

GFXcanvas16 *mcv = nullptr;
int mcW = 0, mcH = 0;
void fxFree() { if (mcv) { delete mcv; mcv = nullptr; } mcW = mcH = 0; }

typedef void (*FxDeco)(Adafruit_GFX &g, int w, int h, int step);
bool fxBotOn = false;
int fxBx = 0, fxBy = 0, fxBw = 0, fxBh = 0, fxBk = 10, fxBStep = 0;
FxDeco fxBdeco = nullptr;
uint32_t fxBT = 0;

void fxBotDraw() {
  if (!mcv || mcW != fxBw || mcH != fxBh) {
    fxFree();
    mcv = new GFXcanvas16(fxBw, fxBh);
    mcW = fxBw; mcH = fxBh;
  }
  if (!mcv || !mcv->getBuffer()) { fxBotOn = false; return; }
  paintSkyOn(*mcv, fxBx, fxBy, fxBx, fxBy, fxBw, fxBh);
  if (!fxFlatBg && fxClouds) paintCloudsOn(*mcv, fxBx, fxBy);
  int s = fxBStep;
  int bob = (int)(sinf(s * 0.5f) * 3);
  int mood = (s % 23 == 22) ? 1 : (s % 37 == 36) ? 4 : 0;
  int aR = ((s >> 1) & 1) ? 1 : 2;
  int top = fxBh - (84 * fxBk + 5) / 10 - 3 + bob;
  drawBotOn(*mcv, fxBw / 2, top, fxBk, mood, 0, aR, s);
  if (fxBdeco) fxBdeco(*mcv, fxBw, fxBh, s);
  tft.drawRGBBitmap(fxBx, fxBy, mcv->getBuffer(), fxBw, fxBh);
}

void decoBubble123(Adafruit_GFX &g, int w, int h, int s) {
  int bx = w - 48, by = 2 + ((s >> 2) & 1);
  g.fillRoundRect(bx, by, 46, 27, 12, C_WHITE);
  g.drawRoundRect(bx, by, 46, 27, 12, C_BOTB);
  g.fillTriangle(bx + 8, by + 24, bx + 17, by + 24, bx + 6, by + 33, C_WHITE);
  const uint16_t cc[3] = { C_SUNY2, C_PINK2, C_GRN2 };
  g.setFont();
  g.setTextSize(2);
  for (int i = 0; i < 3; i++) { g.setTextColor(cc[i]); g.setCursor(bx + 6 + i * 12, by + 6); g.print(i + 1); }
}

void decoBubbleGame(Adafruit_GFX &g, int w, int h, int s) {
  int by = 4 + ((s >> 2) & 1);
  g.fillRoundRect(2, by, w - 4, 46, 12, C_WHITE);
  g.drawRoundRect(2, by, w - 4, 46, 12, C_BOTB);
  g.fillTriangle(w / 2 + 6, by + 44, w / 2 + 17, by + 44, w / 2 + 15, by + 55, C_WHITE);
  g.setFont();
  g.setTextSize(1);
  g.setTextColor(C_NAVY);
  g.setCursor(8, by + 9);  g.print("Pilih");
  g.setCursor(8, by + 21); g.print("favoritmu");
  g.setCursor(8, by + 33); g.print("yuk!");
}

void fxBotStart(int x, int y, int w, int h, int k, int deco) {
  fxBx = x; fxBy = y; fxBw = w; fxBh = h; fxBk = k;
  fxBdeco = (deco == 1) ? decoBubble123 : (deco == 2) ? decoBubbleGame : nullptr;
  fxBStep = 0; fxBT = millis(); fxBotOn = true;
  fxBotDraw();
}

struct FxStar { int16_t x, y; uint8_t r, c; uint16_t bg; };
FxStar fxS[10];
uint8_t fxSph[10];
int fxSn = 0, fxSi = 0;
uint32_t fxST = 0;

void fxStarAdd(int x, int y, int r, int c, uint16_t bg = 0) {
  if (fxSn >= 10) return;
  fxS[fxSn].x = x; fxS[fxSn].y = y; fxS[fxSn].r = r; fxS[fxSn].c = c; fxS[fxSn].bg = bg;
  fxSph[fxSn] = 0;
  drawStar(tft, x, y, r, CONF_COL[c]);
  fxSn++;
}

void fxStarTick() {
  uint32_t now = millis();
  if (!fxSn || now - fxST < 230) return;
  fxST = now;
  FxStar &s = fxS[fxSi];
  fxSph[fxSi] = (fxSph[fxSi] + 1) & 3;
  int ph = fxSph[fxSi];
  int rr = (ph == 0) ? s.r : (ph == 2) ? s.r / 2 : (s.r * 3) / 4;
  if (rr < 2) rr = 2;
  int e = s.r + 1;
  if (s.bg) tft.fillRect(s.x - e, s.y - e, 2 * e + 1, 2 * e + 1, s.bg);
  else paintSkyOn(tft, 0, 0, s.x - e, s.y - e, 2 * e + 1, 2 * e + 1);
  drawStar(tft, s.x, s.y, rr, CONF_COL[s.c]);
  fxSi = (fxSi + 1) % fxSn;
}

bool fxPOn = false, fxPf = false;
int fxPx = 0, fxPy = 0, fxPw = 0, fxPh = 0, fxPr = 11;
uint16_t fxPc1 = 0, fxPc2 = 0;
uint32_t fxPT = 0;

void fxPulseSet(int x, int y, int w, int h, int r, uint16_t c1, uint16_t c2) {
  fxPx = x; fxPy = y; fxPw = w; fxPh = h; fxPr = r; fxPc1 = c1; fxPc2 = c2;
  fxPOn = true; fxPf = false; fxPT = millis();
}

void fxPulseTick() {
  if (!fxPOn || millis() - fxPT < 320) return;
  fxPT = millis();
  fxPf = !fxPf;
  uint16_t c = fxPf ? fxPc2 : fxPc1;
  tft.drawRoundRect(fxPx, fxPy, fxPw, fxPh, fxPr, c);
  tft.drawRoundRect(fxPx + 1, fxPy + 1, fxPw - 2, fxPh - 2, fxPr - 1, c);
}

void fxTick() {
  if (fxBotOn && millis() - fxBT >= 110) { fxBT = millis(); fxBStep++; fxBotDraw(); }
  fxStarTick();
  fxPulseTick();
}

void fxReset() {
  fxBotOn = false; fxBdeco = nullptr;
  fxSn = 0; fxSi = 0;
  fxPOn = false;
  fxIntro = false;
  fxFree();
}

const int16_t TW_LEVEL[][4] = { {70,24,8,2}, {92,62,6,6}, {250,24,8,1}, {228,60,6,4}, {24,196,9,2},
                                {296,196,9,6}, {160,226,5,3}, {16,100,6,5}, {304,100,6,0} };
const int16_t (*twList)[4] = nullptr;
int twN = 0, twIdx = 0;
bool twOn[12];
uint32_t twT = 0;

void twinkleStart() {
  twList = TW_LEVEL;
  twN = sizeof(TW_LEVEL) / sizeof(TW_LEVEL[0]);
  for (int i = 0; i < twN; i++) { twOn[i] = true; drawStar(tft, twList[i][0], twList[i][1], twList[i][2], CONF_COL[twList[i][3]]); }
  twIdx = 0; twT = millis();
}

void twinkleTick() {
  if (!twList || millis() - twT < 280) return;
  twT = millis();
  twOn[twIdx] = !twOn[twIdx];
  drawStar(tft, twList[twIdx][0], twList[twIdx][1], twList[twIdx][2], twOn[twIdx] ? CONF_COL[twList[twIdx][3]] : C_BG);
  twIdx = (twIdx + 1) % twN;
}

const int DW = 160, DH = 148;
GFXcanvas16 *dcv = nullptr;
GFXcanvas16 *getCanvas() { if (!dcv) dcv = new GFXcanvas16(DW, DH); return dcv; }
void freeCanvas() { if (dcv) { delete dcv; dcv = nullptr; } }

void drawDancerOn(Adafruit_GFX &g, int ox, int oy, int step, bool badge, uint16_t bg) {
  int pose = step & 3;
  int jump = (step & 1) ? 10 : 0;
  int cx = ox + 80 + ((pose < 2) ? -4 : 4);
  int top = oy + 30 - jump;

  int sw = 54 - jump * 2;
  g.fillRoundRect(ox + 80 - sw / 2, oy + 140, sw, 6, 3, shade(bg, 205));

  if (!badge) {
    for (int i = 0; i < 12; i++) {
      int x = ox + 6 + (i * 53) % 148;
      int y = oy + (i * 37 + step * (6 + (i % 3) * 3)) % 138;
      g.fillRect(x, y, 4, 3 + (i & 1), CONF_COL[i & 7]);
    }
  }

  drawBotOn(g, cx, top, 13, (pose == 3) ? 4 : 0, (step & 1) ? 3 : 1, (step & 1) ? 1 : 3, step);

  if (!badge) {
    int tx = ox + 10, ty = oy + 96;
    g.drawCircle(tx - 1, ty + 7, 5, C_ORANGE);
    g.drawCircle(tx + 25, ty + 7, 5, C_ORANGE);
    g.fillRoundRect(tx, ty, 24, 20, 7, C_YELLOW);
    g.fillRect(tx + 10, ty + 20, 4, 8, C_YELLOW);
    g.fillRoundRect(tx + 3, ty + 28, 18, 6, 2, C_ORANGE);
    drawStar(g, tx + 12, ty + 10, 6, C_WHITE);
  }

  int kb = (step & 1) ? -3 : 0;
  drawStar(g, ox + 20, oy + 22 + kb, 13, CONF_COL[(step + 1) & 7]);
  drawStar(g, ox + 144, oy + 126, 8, CONF_COL[(step + 4) & 7]);
  drawStar(g, ox + 12, oy + 70, 6, CONF_COL[(step + 6) & 7]);
  if (badge) {
    int bx = ox + 130, by = oy + 31 + kb;
    for (int k = 0; k < 12; k++) {
      float a = k * 0.5236f;
      g.fillCircle(bx + (int)(cosf(a) * 24), by + (int)(sinf(a) * 24), 5, C_ORANGE);
    }
    g.fillCircle(bx, by, 22, C_YELLOW);
    g.drawCircle(bx, by, 18, C_WHITE);
    g.setFont();
    g.setTextColor(C_INK);
    g.setTextSize(2); g.setCursor(bx - 17, by - 13); g.print("+20");
    g.setTextSize(1); g.setCursor(bx - 9, by + 5);   g.print("EXP");
  }
}

void drawDancer(int dx, int dy, int step, bool badge, uint16_t bg) {
  GFXcanvas16 *cv = getCanvas();
  if (cv && cv->getBuffer()) {
    cv->fillScreen(bg);
    drawDancerOn(*cv, 0, 0, step, badge, bg);
    tft.drawRGBBitmap(dx, dy, cv->getBuffer(), DW, DH);
  } else {
    tft.fillRect(dx, dy, DW, DH, bg);
    drawDancerOn(tft, dx, dy, step, badge, bg);
  }
}

Screen screen = S_LEVEL;

int level = 0;
int exp_ = 0;
const char *LEVEL_NAME[3]  = { "EASY", "MEDIUM", "HARD" };
const char *LEVEL_LABEL[3] = { "Kelas 1-2 SD", "Kelas 3-4 SD", "Kelas 5-6 SD" };

const char *LEVEL_SAY[3] = { "Kelas 1 sampai 2 SD", "Kelas 3 sampai 4 SD", "Kelas 5 sampai 6 SD" };
const char *TOPIC_NAME[4] = { "Bilangan Seru", "Tantangan Berhitung", "Detektif Bentuk", "Misi Pengukuran" };

const int N_Q = 10;
Question Q[N_Q];
int qIdx = 0;
int attemptsLeft = 2;
bool locked[4];

const char *NAMES[] = { "Hizkia", "Raja", "Rama", "Armando", "Christopher", "Reno", "Alensky",
                        "Geraldo", "Pablo", "Bima", "Siti", "Cika", "Kevin", "Aris", "Daffa", "Nabila" };
const int N_NAMES = sizeof(NAMES) / sizeof(NAMES[0]);

String pickName(const String &not_) {
  String n;
  do { n = NAMES[random(N_NAMES)]; } while (n == not_);
  return n;
}

String rp(long v) {
  String s = String(v), o = "";
  int c = 0;
  for (int k = s.length() - 1; k >= 0; k--) {
    o = String(s[k]) + o;
    if (++c % 3 == 0 && k > 0) o = "." + o;
  }
  return "Rp " + o;
}

void setQ(Question &q, const String &sub, const String &text, const String &c,
          const String &w1, const String &w2, const String &w3, const String &clue) {
  q.sub = sub; q.q = text; q.clue = clue;
  String o[4] = { c, w1, w2, w3 };
  uint8_t idx[4] = { 0, 1, 2, 3 };
  for (int i = 3; i > 0; i--) { int j = random(i + 1); uint8_t t = idx[i]; idx[i] = idx[j]; idx[j] = t; }
  for (int k = 0; k < 4; k++) {
    q.opt[k] = o[idx[k]];
    if (idx[k] == 0) q.correct = k;
  }
}

void genQuestion(int topic, int lv, int i, Question &q) {
  const SoalItem &s = BANK_PTR[lv][topic][(i - 1) % BANK_N];
  setQ(q, TOPIC_NAME[topic], s.q, s.c, s.w1, s.w2, s.w3, s.clue);
  q.ex = EXPL_PTR[lv][topic][(i - 1) % BANK_N];
}

struct Materi { const char *head; const char *text; };

const char *MATERI_TITLE[3] = { "Trik & Rumus - Kelas 1-2 SD", "Trik & Rumus - Kelas 3-4 SD", "Trik & Rumus - Kelas 5-6 SD" };

const Materi MATERI[3][4] = {
  {
    { "1. Bilangan & Urutan (0-100)",
      "#Genap = Akhiran 0,2,4,6,8 | Ganjil = Akhiran 1,3,5,7,9\n#2 Digit = Puluhan + Satuan (37 = 3 Puluhan + 7 Satuan)\n#Perbandingan: > (lebih besar), < (lebih kecil), = (sama dengan)\n#Sebelum = Angka - 1 | Sesudah = Angka + 1\n!Contoh: Armando dapat nomor 23. Akhirannya 3, jadi 23 adalah bilangan Ganjil.\n!Contoh 2: Sebelum 40 adalah 39 (40 - 1), sesudah 40 adalah 41 (40 + 1)." },
    { "2. Tantangan Berhitung",
      "#Sisa Benda = Jumlah Awal - Terpakai\n#Perkalian (Tambah Berulang): a x b = b + b + ... (a kali)\n#Pembagian (Bagi Rata): Hasil = Total Benda : Banyak Kelompok\n#Bersusun: Kerjakan dari Satuan (kanan), lalu Puluhan (kiri)\n!Contoh: Ivana punya 3 piring, tiap piring 4 kue. Perkalian: 3 x 4 = 4 + 4 + 4 = 12 kue.\n!Contoh 2: Rose membagi 18 bunga ke 3 vas. Pembagian: 18 : 3 = 6 bunga per vas." },
    { "3. Detektif Bentuk",
      "#Persegi: 4 sisi sama panjang & 4 sudut\n#Persegi Panjang: 4 sisi (2 pasang sejajar) & 4 sudut\n#Segitiga: 3 sisi & 3 sudut | Lingkaran: 1 sisi lengkung (0 sudut)\n#Bangun Ruang: Kubus (Dadu), Balok (Kotak Sepatu), Tabung (Kaleng), Bola\n!Contoh: Ivana menggambar persegi. Sisinya ada 4 dan sudutnya ada 4.\n!Contoh 2: Pola \"O [] O [] O ...\" Gambar berikutnya adalah [] (Persegi)." },
    { "4. Misi Pengukuran",
      "#1 Meter (m) = 100 Centimeter (cm)\n#1 Jam = 60 Menit | 1 Minggu = 7 Hari | 1 Tahun = 12 Bulan\n#Jam Pas: Jarum pendek di angka X & panjang di 12 = Pukul X\n#Kembalian = Uang Diberikan - Total Belanja\n!Contoh: Jarum pendek di angka 6, jarum panjang di 12. Pukul 06.00.\n!Contoh 2: Rama beli buku Rp4.000 + pensil Rp1.000 (Total Rp5.000) pakai Rp10.000. Kembalian = Rp10.000 - Rp5.000 = Rp5.000." }
  },
  {
    { "1. Bilangan, Nilai Tempat & Pecahan",
      "#Bentuk Panjang: 6.274 = 6.000 + 200 + 70 + 4\n#Kelipatan: Angka x 1, 2, 3... (Kelipatan 4: 4, 8, 12, 16...)\n#Faktor: Pembagi habis (Faktor 12: 1, 2, 3, 4, 6, 12)\n#FPB (Bagi Sama): Faktor persekutuan terbesar\n#KPK (Jadwal Bersama): Kelipatan persekutuan terkecil\n!Contoh: Lampu merah 6d, hijau 8d. Menyala bersama = KPK(6,8) = 24d lagi.\n!Contoh 2: Pecahan senilai 1/2 = 2/4 = 3/6." },
    { "2. Perkalian & Pembagian Bersusun",
      "#Perkalian Bersusun: Kalikan dari satuan, puluhan, lalu ratusan\n#Porogapit (Pembagian Bersusun): Bagi dari nilai tempat terbesar\n#Hitung Campuran: Utamakan () lalu x atau : baru + atau -\n#Pecahan Penyebut Sama: a/c + b/c = (a+b)/c\n!Contoh: (50 : 5) + 3 x 6 = 10 + 18 = 28.\n!Contoh 2: 1/4 + 1/2 = 1/4 + 2/4 = 3/4." },
    { "3. Keliling & Luas Bangun Datar",
      "#Persegi: Keliling = 4 x s | Luas = s x s\n#Persegi Panjang: Keliling = 2 x (p + l) | Luas = p x l\n#Sudut: Siku-siku (90 deg), Lancip (< 90 deg), Tumpul (> 90 deg)\n#Simetri Lipat: Persegi (4), Persegi Panjang (2), Segitiga Sama Sisi (3)\n!Contoh: Persegi panjang p = 12 cm, l = 7 cm. Keliling = 2 x (12 + 7) = 38 cm.\n!Contoh 2: Luas persegi bersisi 9 cm = 9 x 9 = 81 cm2." },
    { "4. Berat, Waktu, Volume & Uang",
      "#1 km = 1.000 m | 1 m = 100 cm | 1 kg = 1.000 g | 1 L = 1.000 ml\n#Durasi Waktu = Waktu Selesai - Waktu Mulai\n#Jumlah Ubin = Luas Lantai : Luas 1 Ubin\n!Contoh: Belajar 08.15 sampai 09.45. Durasi = 09.45 - 08.15 = 1 jam 30 menit.\n!Contoh 2: Ember 10 Liter diisi gayung 500 ml (0,5 L). Butuh = 10 : 0,5 = 20 gayung." }
  },
  {
    { "1. Pecahan, Desimal, Persen & Rasio",
      "#Pecahan ke Desimal: 3/5 = 6/10 = 0,6 | Ke Persen: 3/4 x 100% = 75%\n#Diskon = Persen Diskon x Harga Awal | Bayar = Awal - Diskon\n#Akar Kuadrat: Akar(144) = 12 karena 12 x 12 = 144\n#Rasio A : B = Nilai A : Nilai B (Sederhanakan bagi FPB)\n!Contoh: Sepatu Rp200.000 diskon 10%. Diskon = 20.000. Bayar = Rp180.000.\n!Contoh 2: Rasio kelereng A dan B = 3 : 4, Total = 28. A = 3/7 x 28 = 12." },
    { "2. Operasi Campuran Pecahan & Desimal",
      "#Perkalian Pecahan: (a/b) x (c/d) = (a x c) / (b x d)\n#Pembagian Pecahan: (a/b) : (c/d) = (a/b) x (d/c)\n#Penyebut Berbeda: Samakan penyebut dengan KPK dulu\n!Contoh: 2/3 x 3/4 = 6/12 = 1/2.\n!Contoh 2: 3,45 kg + 2,8 kg = 6,25 kg." },
    { "3. Geometri Lanjut & Bangun Ruang",
      "#Luas Segitiga = (Alas x Tinggi) : 2 | Luas Lingkaran = pi x r x r\n#Keliling Lingkaran = 2 x pi x r (pi = 22/7 atau 3,14)\n#Volume Kubus = r x r x r | Volume Balok = p x l x t\n#Luas Permukaan Balok = 2 x (p x l + p x t + l x t)\n!Contoh: Segitiga alas 10 cm, tinggi 6 cm. Luas = (10 x 6) : 2 = 30 cm2.\n!Contoh 2: Balok 10 x 6 x 5 cm. Volume = 10 x 6 x 5 = 300 cm3." },
    { "4. Kecepatan, Debit, Skala & Konversi",
      "#Jarak = Kecepatan x Waktu | Kecepatan = Jarak : Waktu\n#Debit = Volume : Waktu | Volume = Debit x Waktu\n#Skala = Jarak Peta : Jarak Sebenarnya\n#Jarak Sebenarnya = Jarak Peta x Skala\n!Contoh: Mobil 60 km/jam selama 2 jam. Jarak = 60 x 2 = 120 km.\n!Contoh 2: Peta 1 : 200.000, Jarak Peta 5 cm. Jarak Asli = 5 x 200.000 = 10 km." }
  }
};
int materiPage = 0;

const Rect R_LEVEL[3]  = { {4, 112, 102, 52}, {109, 112, 102, 52}, {214, 112, 102, 52} };
const Rect R_START     = { 20, 168, 280, 54 };

const Rect R_HOME_BACK = { 0, 0, 112, 34 };
const Rect R_TOPIC[4]  = { {6, 76, 151, 48}, {163, 76, 151, 48}, {6, 128, 151, 48}, {163, 128, 151, 48} };
const Rect R_MATERI    = { 6, 184, 151, 42 };
const Rect R_GAME      = { 163, 184, 151, 42 };

const Rect R_QUIT      = { 0, 0, 112, 34 };
const Rect R_MAT_PREV  = { 6, 202, 96, 34 };
const Rect R_MAT_MENU  = { 112, 202, 96, 34 };
const Rect R_MAT_NEXT  = { 218, 202, 96, 34 };

const Rect R_AGAIN     = { 60, 200, 200, 36 };
const Rect R_GAME_AGAIN = { 14, 200, 140, 36 };
const Rect R_GAME_MENU  = { 166, 200, 140, 36 };

Rect optRect(int i) { return { (int16_t)(4 + (i % 2) * 158), (int16_t)(122 + (i / 2) * 60), 154, 56 }; }

const uint32_t Q_TIME_MS = 30000;
const int WARN_FROM = 5;
volatile bool qActive = false;
uint32_t qStart = 0;
int lastBarW = -1, lastSec = 99;
uint16_t lastBarCol = 0;

void drawTimerBar(long rem, bool force = false) {
  if (rem < 0) rem = 0;
  int w = (int)(rem * 308 / Q_TIME_MS);
  uint16_t col = (rem > 7000) ? C_GREEN : (rem > 5000) ? C_ORANGE : C_RED;
  if (!force && w == lastBarW && col == lastBarCol) return;
  if (force || col != lastBarCol || lastBarW < 0) {
    tft.fillRect(6 + w, 32, 308 - w, 5, C_TRACK);
    if (w > 0) tft.fillRect(6, 32, w, 5, col);
  } else if (w < lastBarW) {
    tft.fillRect(6 + w, 32, lastBarW - w, 5, C_TRACK);
  }
  lastBarW = w; lastBarCol = col;
}

void drawWarning(int sec) {
  uint16_t c = (sec % 2) ? C_RED : C_ORANGE;
  for (int t = 0; t < 2; t++) tft.drawRect(t, t, 320 - 2 * t, 240 - 2 * t, c);
  tft.fillRoundRect(114, 3, 130, 26, 13, c);
  tft.setTextColor(C_WHITE);
  tft.setTextSize(1); tft.setCursor(130, 12); tft.print("SISA WAKTU");
  tft.setTextSize(3); tft.setCursor(204, 5);  tft.print(sec);
}

void drawPill(int x, int y, int w, const String &txt, uint16_t bg, uint16_t fg) {
  tft.fillRoundRect(x, y, w, 20, 10, bg);
  const GFXfont *f = fitFont(txt, w - 8, 9);
  if (f) gText(tft, f, txt, x + w / 2, y + 16, fg);
  else   printCenter(txt, x + w / 2, y + 6, 1, fg);
}

const uint16_t LV_BTN[3] = { RGB(34,197,94), RGB(59,130,246), RGB(168,85,247) };
const char *LV_LINE1[3]  = { "Kelas 1-2", "Kelas 3-4", "Kelas 5-6" };
const char *LV_NUM[3]    = { "1-2", "3-4", "5-6" };
const char *TOPIC_SHORT[4] = { "Bilangan", "Berhitung", "Bentuk", "Pengukuran" };
const uint16_t TOPIC_COL[4] = { RGB(59,130,246), RGB(236,72,153), RGB(34,197,94), RGB(168,85,247) };

void drawLevelBtns() {
  paintSkyOn(tft, 0, 0, 0, 108, 320, 58);
  for (int i = 0; i < 3; i++) {
    const Rect &r = R_LEVEL[i];
    fxButton(r.x, r.y, r.w, r.h, LV_BTN[i]);

    tft.fillCircle(r.x + 16, r.y + 16, 12, C_WHITE);
    tft.drawCircle(r.x + 16, r.y + 16, 12, BTN_COL[i]);
    tft.drawCircle(r.x + 16, r.y + 16, 11, BTN_COL[i]);
    gText(tft, FNT_S, String(BTN_LTR[i]), r.x + 16, r.y + 22, inkOf(BTN_COL[i]));
    gText(tft, FNT_S, "Kelas", r.x + 66, r.y + 16, C_WHITE);
    gText(tft, FNT_M, String(LV_NUM[i]) + " SD", r.x + r.w / 2 + 2, r.y + 40, C_WHITE);
    if (i == level) {
      tft.drawRoundRect(r.x - 2, r.y - 2, r.w + 4, r.h, 13, C_SUNY);
      tft.drawRoundRect(r.x - 3, r.y - 3, r.w + 6, r.h + 2, 14, C_SUNY);
      drawStar(tft, r.x + r.w - 9, r.y + 8, 6, C_SUNY);
    }
    introWait(70);
  }
}

void drawLevelScreen() {
  drawSky(true);

  const int wa = textW(FNT_L, "MathBot"), wb = textW(FNT_L, "AI"), gap = 10;
  int x0 = 214 - (wa + gap + wb) / 2;
  int ca = x0 + wa / 2, cb = x0 + wa + gap + wb / 2;
  gText(tft, FNT_L, "MathBot", ca + 3, 43, C_NAVY);
  gText(tft, FNT_L, "AI",      cb + 3, 43, C_NAVY);
  gOutline(FNT_L, "MathBot", ca, 40, C_BLUE2, C_WHITE, 2);
  gOutline(FNT_L, "AI",      cb, 40, C_SUNY2, C_WHITE, 2);
  introWait(90);
  fxPill(118, 48, 194, 19, C_SUNY, "Belajar Matematika Jadi Seru!", C_NAVY, 9);
  introWait(70);
  labelIn("Halo! Aku MathBot AI", 112, 70, 204, 20, C_NAVY, 12);
  gText(tft, FNT_S, "Pilih kelasmu dulu ya!", 214, 104, RGB(51,65,85));
  introWait(70);
  drawLevelBtns();

  fxButton(R_START.x, R_START.y, R_START.w, R_START.h, C_SUNY);
  tft.fillCircle(R_START.x + 24, R_START.y + 23, 14, C_WHITE);
  tft.drawCircle(R_START.x + 24, R_START.y + 23, 14, BTN_COL[3]);
  tft.drawCircle(R_START.x + 24, R_START.y + 23, 13, BTN_COL[3]);
  gText(tft, FNT_M, "D", R_START.x + 24, R_START.y + 31, BTN_COL[3]);
  tft.fillTriangle(R_START.x + R_START.w - 36, R_START.y + 13, R_START.x + R_START.w - 36, R_START.y + 33, R_START.x + R_START.w - 20, R_START.y + 23, C_NAVY);
  labelIn("MULAI BELAJAR!", R_START.x + 42, R_START.y, R_START.w - 84, R_START.h - 4, C_NAVY, 18);
  fxPulseSet(R_START.x, R_START.y, R_START.w, R_START.h - 4, 11, C_WHITE, C_CORAL);
  fxStarAdd(310, 12, 6, 2);
  fxStarAdd(306, 100, 6, 6);
  fxStarAdd(120, 104, 5, 2);
  fxStarAdd(14, 106, 5, 6);
  fxBotStart(2, 4, 110, 104, 10, 1);
}

void drawLevelChip() {
  tft.fillRoundRect(112, 5, 204, 26, 13, shade(C_BOTB, 150));
  tft.fillRoundRect(112, 3, 204, 26, 13, C_WHITE);
  tft.drawRoundRect(112, 3, 204, 26, 13, C_BOTB);
  tft.drawRoundRect(113, 4, 202, 24, 12, C_BOTB);
  tft.fillRoundRect(119, 7, 24, 18, 8, C_VISOR);
  tft.fillCircle(126, 15, 2, C_EYE);
  tft.fillCircle(136, 15, 2, C_EYE);
  tft.drawLine(128, 20, 131, 21, C_EYE);
  tft.drawLine(131, 21, 134, 20, C_EYE);
  labelIn(LEVEL_LABEL[level], 146, 3, 118, 24, C_NAVY, 12);
  drawStar(tft, 266, 16, 6, C_SUNY);
  tft.setFont(); tft.setTextSize(1); tft.setTextColor(C_GOLDTXT);
  tft.setCursor(276, 12); tft.print("EXP"); tft.setCursor(300, 12); tft.print(exp_);
}

void drawTopicCard(int i) {
  const Rect &r = R_TOPIC[i];
  uint16_t c = TOPIC_COL[i];
  fxButton(r.x, r.y, r.w, r.h, c);
  tft.fillRoundRect(r.x + 3, r.y + 24, r.w - 6, 19, 8, shade(c, 165));
  labelIn(TOPIC_SHORT[i], r.x + 3, r.y + 24, r.w - 24, 19, C_WHITE, 12);
  tft.fillCircle(r.x + r.w - 14, r.y + 33, 7, C_WHITE);
  tft.fillTriangle(r.x + r.w - 17, r.y + 29, r.x + r.w - 17, r.y + 37, r.x + r.w - 11, r.y + 33, c);
  tft.fillRoundRect(r.x + 6, r.y + 5, 14, 14, 5, C_WHITE);
  tft.setFont(); tft.setTextSize(1); tft.setTextColor(inkOf(BTN_COL[i]));
  tft.setCursor(r.x + 10, r.y + 8); tft.print(BTN_LTR[i]);
  icoTopic(i, r.x + r.w / 2 + 4, r.y + 14);
}

void drawHome() {
  drawSky(true);
  drawBackButton("Kembali", C_BLUE2);
  drawLevelChip();
  fxPill(64, 33, 192, 28, C_SUNY, "Pilih Materi", C_NAVY, 12);
  gText(tft, FNT_S, "Yuk, pilih materi!", 160, 72, RGB(51,65,85));
  introWait(60);
  for (int i = 0; i < 4; i++) { drawTopicCard(i); introWait(80); }
  fxButton(R_MATERI.x, R_MATERI.y, R_MATERI.w, R_MATERI.h, C_SUNY);
  icoBulb(R_MATERI.x + 18, R_MATERI.y + 19);
  labelIn("Trik & Rumus", R_MATERI.x + 30, R_MATERI.y, R_MATERI.w - 32, R_MATERI.h - 4, C_NAVY, 12);
  introWait(80);
  fxButton(R_GAME.x, R_GAME.y, R_GAME.w, R_GAME.h, C_GRN2);
  icoPad(R_GAME.x + 22, R_GAME.y + 19);
  labelIn("Main Game!", R_GAME.x + 38, R_GAME.y, R_GAME.w - 40, R_GAME.h - 4, C_WHITE, 12);
  fxPulseSet(R_GAME.x, R_GAME.y, R_GAME.w, R_GAME.h - 4, 11, C_WHITE, C_SUNY);
  fxStarAdd(286, 47, 6, 2);
  fxStarAdd(304, 66, 4, 6);
  fxBotStart(4, 31, 54, 46, 5, 0);
}

int wrapFont(const GFXfont *f, const String &s, int maxW, String *out, int maxLines) {
  int n = 0, i = 0, len = s.length();
  String line = "";
  while (i <= len && n < maxLines) {
    int j = s.indexOf(' ', i);
    if (j < 0) j = len;
    String w = s.substring(i, j);
    if (line.length() == 0) line = w;
    else if (textW(f, line + " " + w) <= maxW) line += " " + w;
    else { out[n++] = line; line = w; }
    i = j + 1;
  }
  if (line.length() && n < maxLines) out[n++] = line;
  return n;
}

void drawParagraphs(const char *text, int x, int y, int w, int maxY) {
  String s(text);
  int start = 0;
  while (start <= (int)s.length()) {
    int e = s.indexOf('\n', start);
    if (e < 0) e = s.length();
    String para = s.substring(start, e);
    start = e + 1;
    uint16_t col = C_INK, bg = C_CARD;
    if (para.startsWith("#")) { col = C_INDIGO; bg = C_LIGHTIND; para.remove(0, 1); }
    else if (para.startsWith("!")) { col = RGB(183,129,3); bg = RGB(255,248,230); para.remove(0, 1); }
    String ln[12];
    int n = wrapFont(FNT_S, para, w, ln, 12);
    for (int i = 0; i < n; i++) {
      if (y + 16 > maxY) { tft.setFont(); return; }
      tft.fillRect(x - 2, y - 1, w + 4, 18, bg);
      tft.setFont(FNT_S); tft.setTextSize(1);
      tft.setTextColor(col);
      tft.setCursor(x, y + 13);
      tft.print(ln[i]);
      tft.setFont();
      y += 18;
    }
    y += 3;
    if (e >= (int)s.length()) break;
  }
}

void drawMateri() {
  uint16_t pc = BTN_COL[materiPage];
  drawSky(false);
  fxPill(4, 0, 262, 23, pc, MATERI_TITLE[level], txtOn(pc), 9);
  tft.fillRoundRect(272, 2, 44, 20, 10, C_WHITE);
  tft.drawRoundRect(272, 2, 44, 20, 10, pc);
  gText(tft, FNT_S, String(materiPage + 1) + "/4", 294, 17, inkOf(pc));

  tft.fillRoundRect(4, 24, 312, 174, 12, C_CARD);
  for (int t = 0; t < 3; t++) tft.drawRoundRect(4 + t, 24 + t, 312 - 2 * t, 174 - 2 * t, 12 - t, pc);
  tft.fillRoundRect(11, 31, 4, 160, 2, pc);
  const Materi &m = MATERI[level][materiPage];
  tft.setFont();
  gText(tft, fitFont(String(m.head), 280, 12), String(m.head), 160, 46, inkOf(pc));
  drawParagraphs(m.text, 18, 52, 288, 196);

  drawBtn(R_MAT_PREV, materiPage > 0 ? C_BOTB : RGB(203,213,225), "< Balik", C_WHITE, 2);
  drawBtn(R_MAT_MENU, C_BLUE2, "Menu", C_WHITE, 2);
  drawBtn(R_MAT_NEXT, materiPage < 3 ? C_SUNY : RGB(203,213,225), "Lanjut >", C_NAVY, 2);
  if (materiPage < 3) fxPulseSet(R_MAT_NEXT.x, R_MAT_NEXT.y, R_MAT_NEXT.w, R_MAT_NEXT.h - 4, 11, C_WHITE, C_CORAL);
  else                fxPulseSet(R_MAT_MENU.x, R_MAT_MENU.y, R_MAT_MENU.w, R_MAT_MENU.h - 4, 11, C_WHITE, C_SUNY);
  {
    String t = m.text;
    t.replace("\n#", "\n");
    t.replace("\n!", "\n");
    if (t.startsWith("#") || t.startsWith("!")) t.remove(0, 1);
    ttsSpeak(String(m.head) + ". " + t);
  }
}

void drawOption(int i, int state) {
  Rect r = optRect(i);
  uint16_t bg = (state == 1) ? C_OKBG : (state == 2) ? C_ERRBG : C_CARD;
  uint16_t bd = (state == 1) ? C_OKTXT : (state == 2) ? RGB(239,68,68) : BTN_COL[i];
  uint16_t tx = (state == 1) ? C_OKTXT : (state == 2) ? C_ERRTXT : C_INK;
  Rect f = { r.x, r.y, r.w, (int16_t)(r.h - 4) };
  tft.fillRoundRect(r.x, r.y + 3, r.w, r.h - 3, 12, shade(bd, 150));
  tft.fillRoundRect(f.x, f.y, f.w, f.h, 12, bg);
  for (int t = 0; t < 3; t++) tft.drawRoundRect(f.x + t, f.y + t, f.w - 2 * t, f.h - 2 * t, 12 - t, bd);
  tft.fillRoundRect(f.x + 5, f.y + 5, 16, 14, 5, bd);
  tft.setTextSize(1);
  tft.setTextColor(txtOn(bd));
  tft.setCursor(f.x + 11, f.y + 8);
  tft.print(BTN_LTR[i]);
  Rect t = { f.x, (int16_t)(f.y + 14), f.w, (int16_t)(f.h - 14) };
  textInBox(Q[qIdx].opt[i], t, tx, 3);
}

void drawHint(const String &msg, uint16_t col) {
  tft.fillRect(2, 108, 316, 14, C_BG);
  if (!msg.length()) return;
  const GFXfont *f = fitFont(msg, 310, 9);
  if (f) gText(tft, f, msg, 160, 119, col);
  else   printCenter(msg, 160, 111, 1, col);
}

void clapPreviewSet(int idx) {
  if (idx == clapPreview) return;
  if (clapPreview >= 0) drawOption(clapPreview, locked[clapPreview] ? 2 : 0);
  if (idx >= 0 && !locked[idx]) {
    Rect r = optRect(idx);
    for (int t = 0; t < 3; t++)
      tft.drawRoundRect(r.x + t, r.y + t, r.w - 2 * t, r.h - 4 - 2 * t, 12 - t, C_INK);
  }
  clapPreview = idx;
}

const Rect R_MIC = { 112, 0, 38, 19 };

void drawMicBtn() {
  uint16_t bg = micOn ? C_GREEN : RGB(148,163,184);
  tft.fillRoundRect(112, 5, 36, 14, 6, shade(bg, 150));
  tft.fillRoundRect(112, 2, 36, 15, 6, bg);
  int cx = 121;
  tft.fillRoundRect(cx - 2, 4, 5, 8, 2, C_WHITE);
  tft.drawFastVLine(cx - 4, 7, 4, C_WHITE);
  tft.drawFastVLine(cx + 4, 7, 4, C_WHITE);
  tft.drawFastHLine(cx - 3, 11, 7, C_WHITE);
  tft.drawFastVLine(cx, 12, 2, C_WHITE);
  tft.drawFastHLine(cx - 2, 14, 5, C_WHITE);
  if (!micOn) {
    tft.drawLine(cx - 5, 15, cx + 4, 3, C_RED);
    tft.drawLine(cx - 4, 15, cx + 5, 3, C_RED);
  }
  tft.setTextSize(1);
  tft.setTextColor(C_WHITE);
  tft.setCursor(129, 6);
  tft.print(micOn ? "ON" : "OFF");
}

void micToggle() {
  micOn = !micOn;
  ttsSpeak(micOn ? "Mikrofon nyala. Ucapkan A, B, C, atau D untuk menjawab." : "Mikrofon mati.");
  micClear();
  clapPreviewSet(-1);
  drawMicBtn();
}

void restoreHint();

String ttsExplainText(const Question &q) { return String("Yuk lihat caranya. ") + q.ex; }

void drawQuiz() {
  Question &q = Q[qIdx];
  tft.fillScreen(C_BG);

  drawBackButton("Keluar", C_CORAL);
  gText(tft, FNT_S, "Soal " + String(qIdx + 1) + "/" + String(N_Q), 198, 17, C_INDIGO);
  String sub = q.sub;
  if (sub.length() > 15) sub = sub.substring(0, 15);
  printCenter(sub, 198, 21, 1, C_MUTED);
  drawPill(250, 4, 66, String(exp_) + " EXP", C_GOLDBG, C_GOLDTXT);
  drawMicBtn();

  tft.drawRoundRect(4, 30, 312, 9, 4, RGB(148,163,184));

  Rect qr = { 4, 40, 312, 68 };
  tft.fillRoundRect(qr.x, qr.y, qr.w, qr.h, 10, C_CARD);
  tft.drawRoundRect(qr.x, qr.y, qr.w, qr.h, 10, C_INDIGO);
  tft.drawRoundRect(qr.x + 1, qr.y + 1, qr.w - 2, qr.h - 2, 9, C_LIGHTIND);
  textInBox(q.q, qr, C_INK, 3);
  for (int i = 0; i < 4; i++) { locked[i] = false; drawOption(i, 0); }
  clapPreview = -1;
  micClear();
  bargeFails = 0; bargeOpen = false;
  attemptsLeft = 2;
  restoreHint();

  lastBarW = -1; lastBarCol = 0; lastSec = 99;
  drawTimerBar(Q_TIME_MS, true);
  qStart = millis();
  qActive = true;
  ttsSpeakQuestion(q, qIdx + 1);
  String pfEx = q.ex.length() ? (String("Waktu habis!\x01Jawabanmu belum tepat.\x01") + ttsExplainText(q)) : String("");
  if (qIdx + 1 < N_Q) ttsPrefetchQuestion(Q[qIdx + 1], qIdx + 2, pfEx);
  else if (pfEx.length()) ttsPrefetchRaw(pfEx);

}

void drawSummary() {
  sndPlay(SND_WIN);
  ttsSpeak(String("Misi selesai! Kamu hebat! Kamu telah menyelesaikan ") + N_Q + " petualangan seru! Total EXP kamu " + exp_ + ".");
  endBg = RGB(255,243,196);
  fxFlatBg = endBg;
  tft.fillScreen(endBg);
  for (int i = 0; i < 8; i++) drawStar(tft, 14 + i * 42, 238, 3, CONF_COL[i]);
  fxPill(40, 4, 240, 38, C_SUNY, "Misi Selesai!", C_NAVY, 18);
  fxPill(176, 45, 132, 21, C_PINK2, "Kamu Hebat!", C_WHITE, 12);

  Rect c1 = { 172, 68, 140, 54 }, c2 = { 172, 126, 140, 54 };
  tft.fillRoundRect(c1.x, c1.y, c1.w, c1.h, 14, C_WHITE);
  tft.drawRoundRect(c1.x, c1.y, c1.w, c1.h, 14, C_BOTB);
  tft.drawRoundRect(c1.x + 1, c1.y + 1, c1.w - 2, c1.h - 2, 13, C_BOTB);
  printCenter("LEVEL", c1.x + c1.w / 2, c1.y + 6, 2, C_MUTED);
  printCenter(String(LEVEL_NAME[level]), c1.x + c1.w / 2, c1.y + 28, 3, LV_COL[level]);
  tft.fillRoundRect(c2.x, c2.y, c2.w, c2.h, 14, C_GOLDBG);
  tft.drawRoundRect(c2.x, c2.y, c2.w, c2.h, 14, C_ORANGE);
  tft.drawRoundRect(c2.x + 1, c2.y + 1, c2.w - 2, c2.h - 2, 13, C_ORANGE);
  printCenter("TOTAL EXP", c2.x + c2.w / 2, c2.y + 6, 2, C_GOLDTXT);
  printCenter(String(exp_), c2.x + c2.w / 2, c2.y + 28, 3, C_GOLDTXT);

  drawBtn(R_AGAIN, C_CORAL, "MAIN LAGI", C_WHITE, 2);
  drawDancer(4, 50, 0, false, endBg);
}

const char *PRAISE[] = { "Hebat! Benar sekali!", "Luar biasa! Tepat!", "Keren! Kamu pinter!",
                         "Mantap! 100 buat kamu!", "Jawabanmu tepat sekali!", "Wow! Kamu jago banget!",
                         "Yeay! Kamu berhasil!", "Pintar sekali! Lanjut!", "Super! Kamu bintangnya!",
                         "Asyik! Jawabanmu benar!", "Kamu memang juara!", "Brilian! Terus semangat!",
                         "Top banget! Hebat kamu!", "Cerdas! Kamu luar biasa!" };
const int N_PRAISE = sizeof(PRAISE) / sizeof(PRAISE[0]);
int lastPraise = -1;

const char *pickPraise() {
  int k;
  do { k = random(N_PRAISE); } while (k == lastPraise);
  lastPraise = k;
  return PRAISE[k];
}

struct Conf { float x, y, vx, vy; int16_t ox, oy; uint8_t w, h, col; bool alive, drawn, round; };
const int N_CONF = 110;
Conf cf[N_CONF];

void confSpawn(float x, float y, float vx, float vy) {
  for (int i = 0; i < N_CONF; i++) if (!cf[i].alive) {
    cf[i].x = x; cf[i].y = y; cf[i].vx = vx; cf[i].vy = vy;
    cf[i].w = 3 + random(4); cf[i].h = 3 + random(4);
    cf[i].col = random(8); cf[i].round = (random(3) == 0);
    cf[i].alive = true; cf[i].drawn = false;
    return;
  }
}

void confBurst(float x, float y, int n) {
  for (int i = 0; i < n; i++) {
    float a = random(0, 628) / 100.0f;
    float sp = 3.0f + random(0, 50) / 10.0f;
    confSpawn(x, y, cosf(a) * sp, sinf(a) * sp - 2.0f);
  }
}

void confPopper(bool right, int n) {
  for (int i = 0; i < n; i++) {
    float ang = (35 + random(0, 40)) * 0.017453f;
    float sp = 9.0f + random(0, 40) / 10.0f;
    float vx = cosf(ang) * sp * 0.45f, vy = -sinf(ang) * sp;
    if (right) confSpawn(290, 206, -vx, vy); else confSpawn(30, 206, vx, vy);
  }
}

void drawPopper(bool right) {
  int s = right ? -1 : 1, ox = right ? 320 : 0;
  int x0 = ox + s * 6, y0 = 232, x1 = ox + s * 19, y1 = 197, x2 = ox + s * 41, y2 = 219;
  tft.fillTriangle(x0, y0, x1, y1, x2, y2, C_CORAL);
  thickLine(tft, ox + s * 12, 214, ox + s * 24, 226, C_YELLOW);
  thickLine(tft, x1, y1, x2, y2, C_PINK);
}

void celebrate() {
  const uint16_t bg = C_CELEB;
  const int DX = 80, DY = 66;
  tft.fillScreen(bg);
  drawStripe(0, 6);
  drawStripe(234, 6);
  uint16_t bc = BANNER_COL[random(6)];
  Rect br = { 8, 8, 304, 52 };
  tft.fillRoundRect(br.x, br.y + 4, br.w, br.h, 14, shade(bc, 140));
  tft.fillRoundRect(br.x, br.y, br.w, br.h, 14, bc);
  tft.drawRoundRect(br.x + 2, br.y + 2, br.w - 4, br.h - 4, 12, C_WHITE);
  { const char *pr = pickPraise(); labelIn(pr, br.x, br.y, br.w, br.h, C_WHITE, 18); ttsSpeak(pr); }
  drawPopper(false);
  drawPopper(true);

  for (int i = 0; i < N_CONF; i++) { cf[i].alive = false; cf[i].drawn = false; }
  uint32_t t0 = millis(), nextWave = 0;
  int wave = 0;
  while (millis() - t0 < 2200) {
    uint32_t el = millis() - t0;
    int step = el / 150;

    for (int i = 0; i < N_CONF; i++) if (cf[i].drawn) {
      bool didalamRobot = cf[i].ox >= DX && cf[i].oy >= DY && cf[i].ox + cf[i].w <= DX + DW && cf[i].oy + cf[i].h <= DY + DH;
      if (!didalamRobot) tft.fillRect(cf[i].ox, cf[i].oy, cf[i].w, cf[i].h, bg);
      cf[i].drawn = false;
    }

    if (wave < 5 && el >= nextWave) {
      if (wave == 0) confBurst(160, 140, 40);
      confPopper(false, 14);
      confPopper(true, 14);
      wave++; nextWave += 330;
    }

    drawDancer(DX, DY, step, true, bg);

    for (int i = 0; i < N_CONF; i++) if (cf[i].alive) {
      cf[i].x += cf[i].vx; cf[i].y += cf[i].vy;
      cf[i].vy += 0.6f; cf[i].vx *= 0.99f;
      int x = (int)cf[i].x, y = (int)cf[i].y;
      if (y >= 230 || x < 0 || x > 312 || y < -120) { cf[i].alive = false; continue; }
      bool zonaPopper = (y > 192 && (x < 46 || x > 274));
      if (y < 68 || zonaPopper) continue;
      uint8_t w = cf[i].round ? 5 : cf[i].w, h = cf[i].round ? 5 : cf[i].h;
      if (cf[i].round) tft.fillCircle(x + 2, y + 2, 2, CONF_COL[cf[i].col]);
      else             tft.fillRect(x, y, w, h, CONF_COL[cf[i].col]);
      cf[i].ox = x; cf[i].oy = y; cf[i].w = w; cf[i].h = h; cf[i].drawn = true;
    }
  }
  freeCanvas();
}

void goTo(Screen s);

void textInBoxOn(Adafruit_GFX &g, const String &s, const Rect &r, uint16_t col, int maxSize = 2) {
  String ln[10];
  int size = maxSize, n = 0;
  while (true) {
    int cpl = (r.w - 8) / (6 * size);
    if (cpl < 1) cpl = 1;
    n = wrapText(s, cpl, ln, 10);
    if (n * 8 * size <= r.h - 2 || size == 1) break;
    size--;
  }
  int lh = 8 * size;
  int y = r.y + (r.h - n * lh) / 2;
  g.setTextSize(size);
  g.setTextColor(col);
  for (int i = 0; i < n; i++) {
    int w = ln[i].length() * 6 * size;
    g.setCursor(r.x + (r.w - w) / 2, y);
    g.print(ln[i]);
    y += lh;
  }
}

void drawHeart(int cx, int cy, uint16_t col) {
  tft.fillCircle(cx - 4, cy, 4, col);
  tft.fillCircle(cx + 4, cy, 4, col);
  tft.fillTriangle(cx - 8, cy + 1, cx + 8, cy + 1, cx, cy + 10, col);
}

void drawSadOn(Adafruit_GFX &g, int ox, int oy, int step, uint16_t bg) {
  const uint16_t CLOUD = RGB(160, 178, 203), CLOUD2 = RGB(120, 138, 165);
  int ph = step & 3;
  int hs = (ph == 1) ? -4 : (ph == 3) ? 4 : 0;
  int cx = ox + 80 + hs, top = oy + 36 + ((step & 1) ? 2 : 0);

  g.fillRoundRect(ox + 80 - 26, oy + 144, 52, 4, 2, shade(bg, 205));

  g.fillCircle(ox + 56, oy + 20, 10, CLOUD);
  g.fillCircle(ox + 72, oy + 13, 13, CLOUD);
  g.fillCircle(ox + 92, oy + 15, 12, CLOUD);
  g.fillCircle(ox + 106, oy + 21, 9,  CLOUD);
  g.fillRect(ox + 56, oy + 20, 51, 10, CLOUD);
  g.fillRect(ox + 58, oy + 27, 47, 3, CLOUD2);

  for (int i = 0; i < 6; i++) {
    int x = ox + 58 + i * 9;
    int y = oy + 32 + (step * 7 + i * 13) % 30;
    g.drawLine(x, y, x - 2, y + 6, C_BOTB);
  }

  drawBotOn(g, cx, top, 13, 2, 0, (ph & 1) ? 5 : 0, step);

  if (step & 1) {
    g.setFont(); g.setTextSize(3); g.setTextColor(C_BOTB);
    g.setCursor(ox + 124, oy + 44); g.print("?");
  }
  thickLine(g, ox + 20, oy + 90, ox + 32, oy + 102, C_CORAL);
  thickLine(g, ox + 32, oy + 90, ox + 20, oy + 102, C_CORAL);
}

void drawPanicOn(Adafruit_GFX &g, int ox, int oy, int step, uint16_t bg) {
  int sh = (step & 1) ? 3 : -3;
  int cx = ox + 80 + sh, top = oy + 32 - ((step & 1) ? 6 : 0);

  g.fillRoundRect(ox + 80 - 26, oy + 144, 52, 4, 2, shade(bg, 205));

  int clx = ox + 132 + sh, cly = oy + 114;
  g.fillCircle(clx - 12, cly - 15, 5, C_RED);
  g.fillCircle(clx + 12, cly - 15, 5, C_RED);
  g.drawLine(clx - 10, cly + 14, clx - 14, cly + 20, C_INK);
  g.drawLine(clx + 10, cly + 14, clx + 14, cly + 20, C_INK);
  g.fillCircle(clx, cly, 17, C_WHITE);
  g.drawCircle(clx, cly, 17, C_RED);
  g.drawCircle(clx, cly, 16, C_RED);
  g.drawLine(clx, cly, clx, cly - 10, C_INK);
  g.drawLine(clx, cly, clx + 7, cly + 3, C_INK);
  if (step & 1) { g.drawLine(clx - 24, cly - 4, clx - 21, cly - 4, C_RED); g.drawLine(clx + 24, cly - 4, clx + 21, cly - 4, C_RED); }

  drawBotOn(g, cx, top, 13, 3, (step & 1) ? 3 : 4, (step & 1) ? 4 : 3, step);

  int dy = (step * 5) % 16;
  g.fillCircle(cx - 40, top + 22 + dy, 3, C_EYE);
  g.fillCircle(cx + 40, top + 14 + dy, 3, C_EYE);
  g.setFont(); g.setTextSize(4); g.setTextColor(C_RED);
  g.setCursor(ox + 10 + ((step & 1) ? 2 : 0), oy + 22); g.print("!");
}

void drawFailFrame(int mode, int dx, int dy, int step, uint16_t bg) {
  GFXcanvas16 *cv = getCanvas();
  if (cv && cv->getBuffer()) {
    cv->fillScreen(bg);
    if (mode == 0) drawSadOn(*cv, 0, 0, step, bg); else drawPanicOn(*cv, 0, 0, step, bg);
    tft.drawRGBBitmap(dx, dy, cv->getBuffer(), DW, DH);
  } else {
    tft.fillRect(dx, dy, DW, DH, bg);
    if (mode == 0) drawSadOn(tft, dx, dy, step, bg); else drawPanicOn(tft, dx, dy, step, bg);
  }
}

const char *OOPS1[]      = { "Ups! Belum tepat!", "Hampir! Coba lagi ya!", "Tenang, coba sekali lagi!", "Jangan menyerah ya!" };
const char *OOPS2[]      = { "Yah, belum beruntung!", "Tidak apa-apa, lanjut!", "Semangat! Soal berikut bisa!" };
const char *TIMEUP_MSG[] = { "WAKTU HABIS!", "Yah, waktunya habis!", "Tik tok! Waktu habis!" };
int lastOops = -1, lastTimeMsg = -1;

int pickIdx(int n, int &last) {
  int k;
  do { k = random(n); } while (n > 1 && k == last);
  last = k;
  return k;
}

void failScene(int mode, const String &msg, uint32_t dur) {
  static const uint16_t PAS0[6] = { RGB(254,226,226), RGB(219,234,254), RGB(254,249,195), RGB(233,223,255), RGB(255,228,200), RGB(209,250,229) };
  static const uint16_t PAS1[3] = { RGB(237,220,255), RGB(207,240,250), RGB(255,222,222) };
  int h0 = msg.length() + (msg.length() ? (int)msg[0] : 0);
  const uint16_t bg = (mode == 0) ? PAS0[h0 % 6] : PAS1[h0 % 3];
  tft.fillScreen(bg);

  int cut = -1;
  for (int i = 0; i < (int)msg.length(); i++) if (msg[i] == '!' || msg[i] == ',') { cut = i; break; }
  String head = (cut >= 0) ? msg.substring(0, cut + 1) : msg;
  String rest = (cut >= 0 && cut + 2 < (int)msg.length()) ? msg.substring(cut + 2) : String("");
  uint16_t pc = (mode == 0) ? C_SUNY : C_CORAL;
  uint16_t tc = (mode == 0) ? C_NAVY : C_WHITE;
  tft.fillRoundRect(24, 10, 272, 62, 22, shade(pc, 150));
  tft.fillRoundRect(24, 6, 272, 62, 22, pc);
  tft.drawRoundRect(24, 6, 272, 62, 22, C_WHITE);
  if (rest.length()) {
    labelIn(head, 24, 6, 272, 34, tc, 18);
    labelIn(rest, 24, 36, 272, 28, tc, 12);
  } else {
    labelIn(head, 24, 6, 272, 62, tc, 18);
  }
  ttsSpeak(msg);

  uint32_t t0 = millis();
  int last = -1;
  while (millis() - t0 < dur) {
    int step = (millis() - t0) / 110;
    if (step != last) {
      last = step;
      if (mode == 1) {
        uint16_t c = (step & 1) ? C_RED : C_ORANGE;
        for (int t = 0; t < 3; t++) tft.drawRect(t, t, 320 - 2 * t, 240 - 2 * t, c);
      }
      drawFailFrame(mode, 80, 78, step, bg);
    }
    delay(5);
  }
  freeCanvas();
}

void wrongAnimation(bool fin) {
  if (fin) failScene(0, OOPS2[pickIdx(sizeof(OOPS2) / sizeof(OOPS2[0]), lastOops)], 1500);
  else     failScene(0, OOPS1[pickIdx(sizeof(OOPS1) / sizeof(OOPS1[0]), lastOops)], 1500);
}

void timeUpAnimation() {
  failScene(1, TIMEUP_MSG[pickIdx(sizeof(TIMEUP_MSG) / sizeof(TIMEUP_MSG[0]), lastTimeMsg)], 1900);
}

void redrawQuizKeep() {
  Question &q = Q[qIdx];
  tft.fillScreen(C_BG);
  drawBackButton("Keluar", C_CORAL);
  printCenter("Soal " + String(qIdx + 1) + "/" + String(N_Q), 179, 7, 1, C_INDIGO);
  String sub = q.sub;
  if (sub.length() > 21) sub = sub.substring(0, 21);
  printCenter(sub, 179, 18, 1, C_MUTED);
  drawPill(248, 5, 68, String(exp_) + " EXP", C_GOLDBG, C_GOLDTXT);
  drawMicBtn();
  tft.drawRoundRect(4, 30, 312, 9, 4, RGB(148,163,184));
  Rect qr = { 4, 40, 312, 68 };
  tft.fillRoundRect(qr.x, qr.y, qr.w, qr.h, 10, C_CARD);
  tft.drawRoundRect(qr.x, qr.y, qr.w, qr.h, 10, C_INDIGO);
  tft.drawRoundRect(qr.x + 1, qr.y + 1, qr.w - 2, qr.h - 2, 9, C_LIGHTIND);
  textInBox(q.q, qr, C_INK, 2);
  drawHint("", C_INK);
  for (int i = 0; i < 4; i++) drawOption(i, locked[i] ? 2 : 0);
  clapPreview = -1;
  micClear();
  long rem = (long)Q_TIME_MS - (long)(millis() - qStart);
  if (rem < 0) rem = 0;
  lastBarW = -1; lastBarCol = 0; lastSec = 99;
  drawTimerBar(rem, true);
}

const int G_ROUNDS = 10, G_LIVES = 3;
const int PF_TOP = 78, PF_BOT = 186;
const int BAL_W = 72, BAL_H = 52;
const int PL_W = 64, PL_H = 48;
const int PLAYER_Y = 186, TRAY_HALF = 26;
#define G_SKY   RGB(186,230,253)
#define G_GRASS RGB(187,247,208)
enum { G_PLAY, G_OVER };

struct Balloon { float y; int16_t x; int16_t iy; bool active; GFXcanvas16 *cv; };
Balloon gb[4];
GFXcanvas16 *gpl = nullptr;
Question gq;
int gTopic = 0, gRound = 0, gScore = 0, gLives = G_LIVES, gStreak = 0, gOk = 0, gState = G_OVER;
float gPx = 160, gSpeed = 12;
int gTarget = 160, gWalk = 0;
uint32_t gT = 0;
bool gTouchDown = false;
int16_t gTouchX = 0, gTouchY = 0;
int gOverStep = 0;
uint32_t gOverT = 0;
bool gWon = false;

int gameKind = 1;
GFXcanvas16 *gsp = nullptr;
const char *GK_OK[3]  = { "Balon benar", "Domba benar", "Tikus benar" };
const char *GK_LBL[3] = { "TANGKAP BENAR", "MASUK KANDANG", "PUKUL BENAR" };
void game2Tick();
void game3Tick();

void gameFreeSprites() {
  for (int k = 0; k < 4; k++) if (gb[k].cv) { delete gb[k].cv; gb[k].cv = nullptr; }
  if (gpl) { delete gpl; gpl = nullptr; }
  if (gsp) { delete gsp; gsp = nullptr; }
}
void gameFree() { gameFreeSprites(); gState = G_OVER; }

#include <new>
GFXcanvas16 *canvasAlloc(int w, int h) {
  GFXcanvas16 *c = new (std::nothrow) GFXcanvas16(w, h);
  if (c && !c->getBuffer()) { delete c; c = nullptr; }
  return c;
}
bool gameAlloc(bool player, int sw, int sh, bool balloons) {
  for (int attempt = 0; attempt < 3; attempt++) {
    gameFreeSprites();
    bool ok = true;
    if (player)  { gpl = canvasAlloc(PL_W, PL_H); ok = ok && gpl; }
    if (sw > 0)  { gsp = canvasAlloc(sw, sh);     ok = ok && gsp; }
    if (balloons) for (int k = 0; k < 4; k++) { gb[k].active = false; gb[k].cv = canvasAlloc(BAL_W, BAL_H); ok = ok && gb[k].cv; }
    if (ok) return true;
    Serial.printf("GAME: sprite gagal (percobaan %d). RAM bebas %u, blok terbesar %u -> melepas RAM suara\n",
                  attempt + 1, (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap());
    gameFreeSprites();
    ttsFreeMemory();
    fxFree();
    freeCanvas();
    delay(120);
  }
  return false;
}

void renderBalloon(GFXcanvas16 &c, const String &txt, uint16_t col) {
  c.fillScreen(G_SKY);
  c.fillRoundRect(0, 3, BAL_W, 34, 17, col);
  c.drawRoundRect(0, 3, BAL_W, 34, 17, shade(col, 170));
  c.fillRoundRect(10, 7, 14, 3, 1, C_WHITE);
  c.fillTriangle(32, 36, 40, 36, 36, 42, shade(col, 170));
  c.drawLine(36, 42, 32, 46, C_MUTED);
  c.drawLine(32, 46, 39, 49, C_MUTED);
  c.drawLine(39, 49, 35, 51, C_MUTED);
  c.setTextWrap(false);
  Rect t = { 6, 5, 60, 30 };
  textInBoxOn(c, txt, t, txtOn(col), 2);
}

void blitBalloon(int bx, int biy, GFXcanvas16 *bcv) {
  int sy = 0, dy = biy, dh = BAL_H;
  if (dy < PF_TOP) { sy = PF_TOP - dy; dy = PF_TOP; dh -= sy; }
  if (dy + dh > PF_BOT) dh = PF_BOT - dy;
  if (dh <= 0) return;
  tft.drawRGBBitmap(bx, dy, bcv->getBuffer() + sy * BAL_W, BAL_W, dh);
}

void renderPlayer(int expr, int phase) {
  GFXcanvas16 &c = *gpl;
  c.fillScreen(G_GRASS);
  thickLine(c, 21, 34, 13, 8, C_PURPLE);
  thickLine(c, 43, 34, 51, 8, C_PURPLE);
  c.fillRoundRect(6, 0, 52, 7, 3, C_ORANGE);
  c.drawFastHLine(8, 1, 48, RGB(253, 186, 116));
  c.fillCircle(13, 8, 4, C_YELLOW);
  c.fillCircle(51, 8, 4, C_YELLOW);
  c.fillRoundRect(22, phase ? 41 : 43, 9, 5, 2, C_CORAL);
  c.fillRoundRect(33, phase ? 43 : 41, 9, 5, 2, C_CORAL);
  c.fillRoundRect(21, 30, 22, 13, 5, C_INDIGO);
  c.fillRoundRect(26, 33, 12, 7, 2, C_WHITE);
  c.fillRoundRect(18, 10, 28, 21, 8, C_PURPLE);
  for (int s = 0; s < 2; s++) {
    int ex = s ? 38 : 26;
    if (expr == 1) {
      c.drawLine(ex - 3, 21, ex, 17, C_INK);
      c.drawLine(ex, 17, ex + 3, 21, C_INK);
    } else {
      c.fillCircle(ex, 19, 3, C_WHITE);
      c.fillCircle(ex, expr == 2 ? 20 : 19, 1, C_INK);
      if (expr == 2) {
        int o = s ? -1 : 1;
        c.drawLine(ex - 4 * o, 14, ex + 3 * o, 12, C_INK);
        c.fillCircle(ex, phase ? 23 : 25, 1, C_SKY);
      }
    }
  }
  if (expr == 1) {
    c.fillRoundRect(27, 23, 10, 5, 2, C_INK);
  } else if (expr == 2) {
    c.drawLine(26, 27, 29, 25, C_INK); c.drawLine(29, 25, 35, 25, C_INK); c.drawLine(35, 25, 38, 27, C_INK);
  } else {
    c.drawLine(27, 25, 30, 27, C_INK); c.drawLine(30, 27, 34, 27, C_INK); c.drawLine(34, 27, 37, 25, C_INK);
  }
  if (expr != 2) { c.fillCircle(22, 24, 2, RGB(255, 170, 190)); c.fillCircle(42, 24, 2, RGB(255, 170, 190)); }
}

void gameDrawPlayer(int expr, int xoff = 0) {
  if (!gpl) return;
  renderPlayer(expr, (gWalk >> 1) & 1);
  tft.drawRGBBitmap((int)gPx - PL_W / 2 + xoff, PLAYER_Y, gpl->getBuffer(), PL_W, PL_H);
}

void gameDrawHud() {
  tft.fillRect(0, 0, 320, 31, C_BG);
  drawBackButton("Keluar", C_CORAL);
  drawPill(112, 5, 104, "SKOR " + String(gScore), C_GOLDBG, C_GOLDTXT);
  for (int h = 0; h < 3; h++) drawHeart(228 + h * 20, 9, h < gLives ? C_RED : C_TRACK);
  printCenter(String(gRound) + "/" + String(G_ROUNDS), 296, 8, 2, C_INDIGO);
}

void gameDrawCard(const String &text, uint16_t col, char chip) {
  ttsSpeak(text);
  Rect qr = { 4, 32, 312, 44 };
  tft.fillRoundRect(qr.x, qr.y, qr.w, qr.h, 10, C_CARD);
  tft.drawRoundRect(qr.x, qr.y, qr.w, qr.h, 10, col);
  tft.drawRoundRect(qr.x + 1, qr.y + 1, qr.w - 2, qr.h - 2, 9, C_LIGHTIND);
  Rect tb = { 6, 33, 308, 42 };
  if (chip) {
    tft.fillRoundRect(8, 38, 18, 24, 6, col);
    tft.setTextSize(2);
    tft.setTextColor(txtOn(col));
    tft.setCursor(11, 43);
    tft.print(chip);
    tb.x = 28; tb.w = 284;
  }
  textInBox(text, tb, C_INK, 3);
}

void drawGameOver() {
  ttsSpeak(String(gWon ? "Game selesai! Kamu hebat! " : "Game over! Coba lagi yuk! ") + GK_OK[gameKind - 1] + " " + gOk + " dari " + gRound +
           " ronde. Skor game kamu " + gScore + ". Tekan A untuk main lagi, atau B untuk menu.");
  endBg = gWon ? RGB(219,234,254) : RGB(237,226,255);
  fxFlatBg = endBg;
  tft.fillScreen(endBg);
  for (int i = 0; i < 8; i++) drawStar(tft, 14 + i * 42, 238, 3, CONF_COL[i]);
  uint16_t bc = gWon ? RGB(147,197,253) : RGB(196,181,253);
  fxPill(40, 4, 240, 38, bc, gWon ? "Game Selesai!" : "Game Over!", C_NAVY, 18);
  fxPill(176, 45, 132, 21, gWon ? C_PINK2 : C_CORAL, gWon ? "Kamu Hebat!" : "Coba Lagi Yuk", C_WHITE, 12);

  Rect c1 = { 172, 68, 140, 54 }, c2 = { 172, 126, 140, 54 };
  tft.fillRoundRect(c1.x, c1.y, c1.w, c1.h, 14, C_WHITE);
  tft.drawRoundRect(c1.x, c1.y, c1.w, c1.h, 14, C_BOTB);
  tft.drawRoundRect(c1.x + 1, c1.y + 1, c1.w - 2, c1.h - 2, 13, C_BOTB);
  printCenter("SKOR GAME", c1.x + c1.w / 2, c1.y + 6, 2, C_MUTED);
  printCenter(String(gScore), c1.x + c1.w / 2, c1.y + 28, 3, C_INDIGO);
  tft.fillRoundRect(c2.x, c2.y, c2.w, c2.h, 14, C_GOLDBG);
  tft.drawRoundRect(c2.x, c2.y, c2.w, c2.h, 14, C_ORANGE);
  tft.drawRoundRect(c2.x + 1, c2.y + 1, c2.w - 2, c2.h - 2, 13, C_ORANGE);
  gText(tft, FNT_S, String(GK_LBL[gameKind - 1]), c2.x + c2.w / 2, c2.y + 18, C_GOLDTXT);
  printCenter(String(gOk) + "/" + String(gRound), c2.x + c2.w / 2, c2.y + 28, 3, C_GOLDTXT);

  drawBtn(R_GAME_AGAIN, BTN_COL[0], "", C_WHITE, 2);
  { Rect lb = { (int16_t)(R_GAME_AGAIN.x + 22), R_GAME_AGAIN.y, (int16_t)(R_GAME_AGAIN.w - 22), (int16_t)(R_GAME_AGAIN.h - 4) };
    labelIn("MAIN LAGI", lb.x, lb.y, lb.w, lb.h, C_WHITE, 12); }
  keyChip(R_GAME_AGAIN.x + 5, R_GAME_AGAIN.y + 6, 0);
  drawBtn(R_GAME_MENU, BTN_COL[1], "", C_WHITE, 2);
  { Rect lb = { (int16_t)(R_GAME_MENU.x + 22), R_GAME_MENU.y, (int16_t)(R_GAME_MENU.w - 22), (int16_t)(R_GAME_MENU.h - 4) };
    labelIn("MENU", lb.x, lb.y, lb.w, lb.h, C_WHITE, 12); }
  keyChip(R_GAME_MENU.x + 5, R_GAME_MENU.y + 6, 1);
  gOverStep = 0; gOverT = millis();
  if (gWon) drawDancer(4, 50, 0, false, endBg);
  else      drawFailFrame(0, 4, 50, 0, endBg);
}

void gameOver() {
  ttsWait(4000);
  gameFreeSprites();
  gState = G_OVER;
  gWon = (gLives > 0);
  sndPlay(gWon ? SND_WIN : SND_LOSE);
  drawGameOver();
}

void gameStartRound() {
  ttsWait(4000);
  gRound++;
  for (int tries = 0; tries < 40; tries++) {
    gTopic = random(4);
    genQuestion(gTopic, level, 1 + random(BANK_N), gq);
    int mx = 0;
    for (int k = 0; k < 4; k++) mx = max(mx, (int)gq.opt[k].length());
    if (mx <= 20) break;
  }
  gameDrawHud();
  gameDrawCard(gq.q, BTN_COL[gTopic], BTN_LTR[gTopic]);
  tft.fillRect(0, PF_TOP, 320, PF_BOT - PF_TOP, G_SKY);
  int stag = 24 + level * 6;
  for (int k = 0; k < 4; k++) {
    gb[k].x = 4 + k * 80;
    gb[k].y = PF_TOP - BAL_H - random(0, stag + 1);
    gb[k].iy = -999;
    gb[k].active = true;
    renderBalloon(*gb[k].cv, gq.opt[k], BTN_COL[k]);
  }
  gTarget = (int)gPx;
  gameDrawPlayer(0);
  gT = millis();
}

void gameResult(bool ok, const String &msg) {
  ttsSpeak(msg);
  tft.fillRect(0, PF_TOP, 320, PF_BOT - PF_TOP, G_SKY);
  uint16_t col = ok ? C_GREEN : C_RED;
  Rect br = { 10, 94, 300, 46 };
  tft.fillRoundRect(br.x, br.y + 4, br.w, br.h, 14, shade(col, 140));
  tft.fillRoundRect(br.x, br.y, br.w, br.h, 14, col);
  tft.drawRoundRect(br.x + 2, br.y + 2, br.w - 4, br.h - 4, 12, C_WHITE);
  textInBox(msg, br, C_WHITE, 2);

  float sx[7], sy[7], svx[7];
  int16_t spx[7], spy[7];
  bool sd[7];
  for (int k = 0; k < 7; k++) { sx[k] = gPx; sy[k] = 176; svx[k] = (k - 3) * 1.8f; sd[k] = false; spx[k] = 0; spy[k] = 0; }
  uint32_t t0 = millis();
  int last = -1;
  while (millis() - t0 < 1200) {
    int f = (millis() - t0) / 90;
    if (f == last) { delay(5); continue; }
    last = f;
    gWalk++;
    if (ok) {
      for (int k = 0; k < 7; k++) {
        if (sd[k]) { tft.fillRect(spx[k] - 7, spy[k] - 7, 14, 14, G_SKY); sd[k] = false; }
        if (f <= 7) {
          sx[k] += svx[k];
          if (sx[k] < 10) sx[k] = 10;
          if (sx[k] > 310) sx[k] = 310;
          sy[k] -= 3.0f;
          spx[k] = (int)sx[k]; spy[k] = (int)sy[k];
          drawStar(tft, spx[k], spy[k], 5, CONF_COL[k]);
          sd[k] = true;
        }
      }
    }
    gameDrawPlayer(ok ? 1 : 2, ok ? 0 : ((f & 1) ? 3 : -3));
  }
  gT = millis();
}

void gameFinishRound(bool ok, const String &msg) {
  if (ok) { gScore += 10 + (gStreak >= 2 ? 5 : 0); gStreak++; gOk++; exp_ += 10; }
  else    { gLives--; gStreak = 0; }
  sndPlay(ok ? SND_OK : SND_WRONG);
  gameDrawHud();
  gameResult(ok, msg);
  if (gLives <= 0 || gRound >= G_ROUNDS) gameOver();
  else gameStartRound();
}

void gameTick() {
  if (screen != S_GAME) return;
  if (gState == G_PLAY && gameKind == 2) { game2Tick(); return; }
  if (gState == G_PLAY && gameKind == 3) { game3Tick(); return; }
  if (gState == G_OVER) {
    if (millis() - gOverT >= 160) {
      gOverT = millis();
      gOverStep++;
      if (gWon) drawDancer(4, 50, gOverStep, false, endBg);
      else      drawFailFrame(0, 4, 50, gOverStep, endBg);
    }
    return;
  }
  uint32_t now = millis();
  if (now - gT < 30) return;
  float dt = (now - gT) / 1000.0f;
  if (dt > 0.1f) dt = 0.1f;
  gT = now;

  if (gTouchDown && gTouchY > 40) gTarget = constrain((int)gTouchX, 36, 284);
  float d = gTarget - gPx;
  if (d > 0.5f || d < -0.5f) {
    if (d > 8.0f) d = 8.0f;
    if (d < -8.0f) d = -8.0f;
    gPx += d;
    gWalk++;
    gameDrawPlayer(0);
  }

  int caught = -1;
  bool missed = false;
  for (int k = 0; k < 4 && caught < 0 && !missed; k++) {
    Balloon &b = gb[k];
    if (!b.active) continue;
    b.y += gSpeed * dt;
    int iy = (int)b.y;
    if (iy + BAL_H >= PLAYER_Y + 2) {
      int px = (int)gPx;
      int l = (b.x > px - TRAY_HALF) ? b.x : px - TRAY_HALF;
      int r = (b.x + BAL_W < px + TRAY_HALF) ? b.x + BAL_W : px + TRAY_HALF;
      int y0 = (b.iy > PF_TOP) ? b.iy : PF_TOP;
      tft.fillRect(b.x, y0, BAL_W, PF_BOT - y0, G_SKY);
      b.active = false;
      if (r - l >= 14) caught = k;
      else if (k == gq.correct) missed = true;
    } else if (iy != b.iy) {
      b.iy = iy;
      blitBalloon(b.x, b.iy, b.cv);
    }
  }
  if (caught >= 0) {
    if (caught == gq.correct) gameFinishRound(true, String(pickPraise()));
    else gameFinishRound(false, String("Ups! Jawabannya: ") + gq.opt[gq.correct]);
  } else if (missed) {
    gameFinishRound(false, String("Terlewat! Jawabannya: ") + gq.opt[gq.correct]);
  }
}

void drawGameBalon() {
  if (!gameAlloc(true, 0, 0, true)) { gameMemFail(); return; }
  gScore = 0; gLives = G_LIVES; gRound = 0; gStreak = 0; gOk = 0;
  gPx = 160; gTarget = 160; gWalk = 0;
  gSpeed = (level == 0) ? 12.0f : (level == 1) ? 15.0f : 18.0f;
  gState = G_PLAY;
  gTouchDown = false;
  tft.fillScreen(C_BG);
  tft.fillRect(0, PF_TOP, 320, PF_BOT - PF_TOP, G_SKY);
  tft.fillRect(0, PF_BOT, 320, 236 - PF_BOT, G_GRASS);
  drawStripe(236, 4);
  gameDrawHud();
  gameDrawCard("Geser robot, tangkap balon jawaban benar!", C_INDIGO, 0);
  gameDrawPlayer(0);
  printCenterShadow("SIAP?", 160, 118, 3, C_CORAL, C_WHITE);
  ttsSpeak("Siap?", true);
  delay(1900);
  gameStartRound();
}

const Rect R_GM[3] = { {6, 58, 238, 50}, {6, 114, 238, 50}, {6, 170, 238, 50} };
const char *GM_LABEL[3] = { "Tangkap Balon", "Domba Ke Kandang", "Pukul Tikus" };

void drawGameMenu() {
  drawSky(true);
  drawBackButton("Menu", C_BLUE2);
  fxPill(112, 3, 204, 27, C_SUNY, "Pilih Game Seru", C_NAVY, 12);
  gText(tft, FNT_S, "Sentuh game / tekan A, B, C", 160, 50, RGB(51,65,85));
  const uint16_t gc[3] = { RGB(250,204,21), RGB(59,130,246), RGB(168,85,247) };
  for (int i = 0; i < 3; i++) {
    const Rect &r = R_GM[i];
    fxButton(r.x, r.y, r.w, r.h, gc[i]);
    Rect lb = { (int16_t)(r.x + 50), r.y, (int16_t)(r.w - 94), (int16_t)(r.h - 4) };
    labelIn(GM_LABEL[i], lb.x, lb.y, lb.w, lb.h, (i == 0) ? C_NAVY : C_WHITE, 12);

    int kx = r.x + r.w - 24, ky = r.y + 22;
    tft.fillCircle(kx, ky, 15, C_WHITE);
    tft.drawCircle(kx, ky, 15, BTN_COL[i]);
    tft.drawCircle(kx, ky, 14, BTN_COL[i]);
    gText(tft, FNT_M, String(BTN_LTR[i]), kx, ky + 8, inkOf(BTN_COL[i]));
    int cx = r.x + 30, cy = r.y + 22;
    tft.fillCircle(cx, cy, 19, C_WHITE);
    if (i == 0) {
      tft.fillCircle(cx, cy - 4, 11, C_RED);
      tft.fillTriangle(cx - 3, cy + 6, cx + 3, cy + 6, cx, cy + 11, C_RED);
      tft.drawLine(cx, cy + 11, cx - 3, cy + 17, C_MUTED);
      tft.fillCircle(cx - 4, cy - 8, 2, C_WHITE);
    } else if (i == 1) {
      uint16_t wool = RGB(203,213,225);
      tft.fillRect(cx - 6, cy + 8, 3, 7, C_INK);
      tft.fillRect(cx + 4, cy + 8, 3, 7, C_INK);
      tft.fillCircle(cx - 6, cy + 1, 7, wool);
      tft.fillCircle(cx, cy - 4, 8, wool);
      tft.fillCircle(cx + 5, cy + 1, 7, wool);
      tft.fillCircle(cx - 1, cy + 5, 6, wool);
      tft.fillRoundRect(cx + 8, cy - 4, 8, 10, 3, C_INK);
    } else {
      tft.fillRoundRect(cx - 17, cy + 8, 34, 9, 4, RGB(146,100,52));
      tft.fillCircle(cx, cy, 12, RGB(120,81,50));
      tft.fillCircle(cx - 5, cy - 3, 3, C_WHITE);
      tft.fillCircle(cx + 5, cy - 3, 3, C_WHITE);
      tft.fillCircle(cx - 5, cy - 3, 1, C_INK);
      tft.fillCircle(cx + 5, cy - 3, 1, C_INK);
      tft.fillCircle(cx, cy + 3, 3, C_PINK);
      tft.fillRoundRect(cx - 17, cy + 10, 34, 7, 3, RGB(146,100,52));
    }
    introWait(90);
  }
  fxStarAdd(120, 46, 4, 2);
  fxBotStart(248, 50, 70, 188, 8, 2);
}

Rect R4(int x, int y, int w, int h) { Rect r; r.x = x; r.y = y; r.w = w; r.h = h; return r; }

void gameMemFail() {
  gameFree();
  tft.fillScreen(C_BG);
  printCenter("Memori tidak cukup untuk game", 160, 100, 2, C_ERRTXT);
  printCenter("RAM bebas " + String((unsigned)(ESP.getFreeHeap() / 1024)) + " KB", 160, 130, 2, C_MUTED);
  delay(2000);
  goTo(S_HOME);
}

void pickGameQuestion() {
  for (int tries = 0; tries < 40; tries++) {
    gTopic = random(4);
    genQuestion(gTopic, level, 1 + random(BANK_N), gq);
    int mx = 0;
    for (int k = 0; k < 4; k++) mx = max(mx, (int)gq.opt[k].length());
    if (mx <= 20) break;
  }
}

void game2StartRound();
void game3StartRound();

void fieldResult(bool ok, const String &msg) {
  ttsSpeak(msg);
  uint16_t col = ok ? C_GREEN : C_RED;
  Rect br = { 10, 94, 300, 46 };
  tft.fillRoundRect(br.x, br.y + 4, br.w, br.h, 14, shade(col, 140));
  tft.fillRoundRect(br.x, br.y, br.w, br.h, 14, col);
  tft.drawRoundRect(br.x + 2, br.y + 2, br.w - 4, br.h - 4, 12, C_WHITE);
  textInBox(msg, br, C_WHITE, 2);
  uint32_t t0 = millis();
  int n = 0;
  while (millis() - t0 < 1300) {
    if (ok && n < 8 && millis() - t0 >= (uint32_t)(n * 110)) {
      drawStar(tft, 14 + random(292), 150 + random(70), 5 + random(4), CONF_COL[n]);
      n++;
    }
    delay(5);
  }
}

void fieldFinish(bool ok, const String &msg) {
  if (ok) { gScore += 10 + (gStreak >= 2 ? 5 : 0); gStreak++; gOk++; exp_ += 10; }
  else    { gLives--; gStreak = 0; }
  sndPlay(ok ? SND_OK : SND_WRONG);
  gameDrawHud();
  fieldResult(ok, msg);
  if (gLives <= 0 || gRound >= G_ROUNDS) gameOver();
  else if (gameKind == 2) game2StartRound();
  else game3StartRound();
}

const int G2_W = 72, G2_H = 48, G2_SY = 86, G2_TY = 174;
const int PEN_X = 4, PEN_Y = 150, PEN_W = 312, PEN_H = 82;
inline int g2sx(int k) { return 8 + k * 80; }
bool g2Prev = false;

void drawPenOn(Adafruit_GFX &g, int ox, int oy) {
  const uint16_t W1 = RGB(146, 100, 52), W2 = RGB(101, 67, 33);
  int x0 = PEN_X - ox, y0 = PEN_Y - oy;
  g.fillRect(x0, y0 + 6, PEN_W, 5, W1);
  g.fillRect(x0, y0 + 16, PEN_W, 5, W1);
  g.fillRect(x0, y0 + PEN_H - 6, PEN_W, 6, W1);
  for (int px = 0; px <= PEN_W - 6; px += 34) g.fillRect(x0 + px, y0, 6, 24, W2);
  g.fillRect(x0, y0 + 24, 6, PEN_H - 24, W2);
  g.fillRect(x0 + PEN_W - 6, y0 + 24, 6, PEN_H - 24, W2);
  g.fillRoundRect(x0 + 116, y0 - 12, 80, 16, 4, W2);
  g.setTextWrap(false);
  g.setTextSize(1);
  g.setTextColor(C_WHITE);
  g.setCursor(x0 + 135, y0 - 8);
  g.print("KANDANG");
}

void drawSheepOn(Adafruit_GFX &g, int ox, int oy, const String &txt, uint16_t col, int step) {
  const uint16_t WOOL = RGB(250, 250, 252), WOOLD = RGB(203, 213, 225);
  static const int8_t LX[4] = { 14, 24, 40, 50 };
  static const int8_t WX[7] = { 16, 30, 44, 52, 22, 36, 46 };
  static const int8_t WY[7] = { 22, 15, 15, 24, 32, 31, 33 };
  static const int8_t WR[7] = { 12, 13, 13, 11, 10, 11, 9 };
  g.fillRoundRect(ox + 8, oy + 44, 52, 4, 2, shade(G_GRASS, 205));
  for (int i = 0; i < 4; i++) {
    int lift = ((i + step) & 1) ? 2 : 0;
    g.fillRect(ox + LX[i], oy + 38, 5, 9 - lift, C_INK);
  }
  for (int i = 0; i < 7; i++) g.fillCircle(ox + WX[i], oy + WY[i], WR[i] + 1, WOOLD);
  for (int i = 0; i < 7; i++) g.fillCircle(ox + WX[i], oy + WY[i], WR[i], WOOL);
  g.fillRoundRect(ox + 55, oy + 14, 17, 20, 7, C_INK);
  g.fillRoundRect(ox + 52, oy + 16, 7, 9, 3, RGB(71, 85, 105));
  g.fillCircle(ox + 65, oy + 21, 3, C_WHITE);
  g.fillCircle(ox + 66, oy + 21, 1, C_INK);
  g.fillCircle(ox + 68, oy + 28, 2, C_PINK);
  Rect lb = R4(ox + 5, oy + 10, 50, 28);
  g.fillRoundRect(lb.x, lb.y, lb.w, lb.h, 8, col);
  g.drawRoundRect(lb.x, lb.y, lb.w, lb.h, 8, shade(col, 150));
  textInBoxOn(g, txt, lb, txtOn(col), 2);
}

void game2StartRound() {
  ttsWait(4000);
  gRound++;
  pickGameQuestion();
  gameDrawHud();
  gameDrawCard(gq.q, BTN_COL[gTopic], BTN_LTR[gTopic]);
  tft.fillRect(0, PF_TOP, 320, 236 - PF_TOP, G_GRASS);
  drawPenOn(tft, 0, 0);
  for (int k = 0; k < 4; k++) drawSheepOn(tft, g2sx(k), G2_SY, gq.opt[k], BTN_COL[k], 0);
}

void game2Jump(int k) {
  int cx = g2sx(k), cy = G2_SY, base = G2_SY, f = 0;
  while (base < G2_TY) {
    base = min(base + 8, G2_TY);
    f++;
    int hop = (base >= G2_TY) ? 0 : ((f & 1) ? 6 : 0);
    int ny = base - hop;
    int dy = ny - cy;
    if (dy > 0) tft.fillRect(cx, cy, G2_W, dy, G_GRASS);
    else if (dy < 0) tft.fillRect(cx, cy + G2_H + dy, G2_W, -dy, G_GRASS);
    if (ny + G2_H > PEN_Y - 14) drawPenOn(tft, 0, 0);
    gsp->fillScreen(G_GRASS);
    drawPenOn(*gsp, cx, ny);
    drawSheepOn(*gsp, 0, 0, gq.opt[k], BTN_COL[k], f);
    tft.drawRGBBitmap(cx, ny, gsp->getBuffer(), G2_W, G2_H);
    cy = ny;
    delay(35);
  }
  bool ok = (k == gq.correct);
  fieldFinish(ok, ok ? String(pickPraise()) : String("Ups! Jawabannya: ") + gq.opt[gq.correct]);
}

void game2Tick() {
  bool tap = gTouchDown && !g2Prev;
  g2Prev = gTouchDown;
  if (!tap) return;
  int k = -1;
  for (int i = 0; i < 4; i++) {
    if (hit(R4(g2sx(i) - 4, G2_SY - 4, G2_W + 8, G2_H + 8), gTouchX, gTouchY)) { k = i; break; }
  }
  if (k < 0) return;
  game2Jump(k);
  g2Prev = true;
}

void drawGame2() {
  if (!gameAlloc(false, G2_W, G2_H, false)) { gameMemFail(); return; }
  gsp->setTextWrap(false);
  gScore = 0; gLives = G_LIVES; gRound = 0; gStreak = 0; gOk = 0;
  gState = G_PLAY;
  gTouchDown = false; g2Prev = true;
  tft.fillScreen(C_BG);
  tft.fillRect(0, PF_TOP, 320, 236 - PF_TOP, G_GRASS);
  drawStripe(236, 4);
  gameDrawHud();
  gameDrawCard("Sentuh domba yang membawa jawaban benar, biar masuk kandang!", C_INDIGO, 0);
  drawPenOn(tft, 0, 0);
  printCenterShadow("SIAP?", 160, 112, 3, C_CORAL, C_WHITE);
  ttsSpeak("Siap?", true);
  delay(1900);
  game2StartRound();
}

const int MOLE_MAXH = 38;
struct Mole { uint8_t st; int16_t h; uint32_t t; };
Mole mo[4];
uint32_t g3Start = 0;
int g3LastBar = -1;
uint16_t g3Col = 0;
bool g3Prev = false;
inline int moleX(int k) { return 4 + k * 80; }
inline int moleY(int k) { return (k & 1) ? 144 : 92; }
inline long g3Total() { return (level == 0) ? 20000L : (level == 1) ? 16000L : 13000L; }
inline uint32_t g3UpMs() { return (level == 0) ? 2300 : (level == 1) ? 1800 : 1400; }

void renderMole(GFXcanvas16 &c, int k, int h) {
  const uint16_t DIRT = RGB(146, 100, 52), DARK = RGB(76, 52, 30), FUR = RGB(120, 81, 50);
  c.setTextWrap(false);
  c.fillScreen(G_GRASS);
  c.fillRoundRect(4, 38, 64, 13, 6, DARK);
  if (h > 0) {
    int top = 44 - h;
    c.fillRoundRect(16, top, 40, 24, 11, FUR);
    c.fillCircle(19, top + 3, 5, FUR);
    c.fillCircle(53, top + 3, 5, FUR);
    c.fillCircle(29, top + 9, 3, C_WHITE);
    c.fillCircle(43, top + 9, 3, C_WHITE);
    c.fillCircle(29, top + 10, 1, C_INK);
    c.fillCircle(43, top + 10, 1, C_INK);
    c.fillCircle(36, top + 15, 3, C_PINK);
    Rect sg = R4(2, top + 19, 68, 24);
    c.fillRoundRect(sg.x, sg.y, sg.w, sg.h, 6, BTN_COL[k]);
    c.drawRoundRect(sg.x, sg.y, sg.w, sg.h, 6, shade(BTN_COL[k], 150));
    textInBoxOn(c, gq.opt[k], sg, txtOn(BTN_COL[k]), 2);
  }
  c.fillRoundRect(0, 46, 72, 6, 3, DIRT);
}

void blitMole(int k) {
  tft.drawRGBBitmap(moleX(k), moleY(k), gb[k].cv->getBuffer(), BAL_W, BAL_H);
}

void g3Bar(long rem) {
  long tot = g3Total();
  if (rem < 0) rem = 0;
  int w = (int)(rem * 308 / tot);
  uint16_t col = (rem > tot / 2) ? C_GREEN : (rem > tot / 4) ? C_ORANGE : C_RED;
  if (g3LastBar < 0 || col != g3Col) {
    tft.fillRect(6, 224, 308, 6, C_TRACK);
    if (w > 0) tft.fillRect(6, 224, w, 6, col);
  } else if (w < g3LastBar) {
    tft.fillRect(6 + w, 224, g3LastBar - w, 6, C_TRACK);
  }
  g3LastBar = w; g3Col = col;
}

void game3StartRound() {
  ttsWait(4000);
  gRound++;
  pickGameQuestion();
  gameDrawHud();
  gameDrawCard(gq.q, BTN_COL[gTopic], BTN_LTR[gTopic]);
  tft.fillRect(0, PF_TOP, 320, 236 - PF_TOP, G_GRASS);
  uint32_t now = millis();
  for (int k = 0; k < 4; k++) {
    mo[k].st = 0; mo[k].h = 0;
    mo[k].t = now + 200 + random(800);
    renderMole(*gb[k].cv, k, 0);
    blitMole(k);
  }
  mo[gq.correct].t = now + 300 + random(300);
  g3Start = now; g3LastBar = -1;
  g3Bar(g3Total());
  gT = now;
}

void game3Tick() {
  bool tap = gTouchDown && !g3Prev;
  g3Prev = gTouchDown;
  if (tap) {
    for (int k = 0; k < 4; k++) {
      if (mo[k].h >= 24 && hit(R4(moleX(k), moleY(k), BAL_W, BAL_H), gTouchX, gTouchY)) {
        bool ok = (k == gq.correct);
        fieldFinish(ok, ok ? String(pickPraise()) : String("Ups! Jawabannya: ") + gq.opt[gq.correct]);
        g3Prev = true;
        return;
      }
    }
  }
  uint32_t now = millis();
  if (now - gT < 40) return;
  gT = now;
  uint32_t upMs = g3UpMs();
  for (int k = 0; k < 4; k++) {
    Mole &m = mo[k];
    int16_t oldh = m.h;
    if (m.st == 0) { if (now >= m.t) m.st = 1; }
    else if (m.st == 1) { m.h += 8; if (m.h >= MOLE_MAXH) { m.h = MOLE_MAXH; m.st = 2; m.t = now + upMs; } }
    else if (m.st == 2) { if (now >= m.t) m.st = 3; }
    else { m.h -= 8; if (m.h <= 0) { m.h = 0; m.st = 0; m.t = now + 350 + random(900); } }
    if (m.h != oldh) { renderMole(*gb[k].cv, k, m.h); blitMole(k); }
  }
  long rem = (long)g3Total() - (long)(now - g3Start);
  if (rem <= 0) {
    fieldFinish(false, String("Waktu habis! Jawabannya: ") + gq.opt[gq.correct]);
    g3Prev = true;
    return;
  }
  g3Bar(rem);
}

void drawGame3() {
  if (!gameAlloc(false, 0, 0, true)) { gameMemFail(); return; }
  gScore = 0; gLives = G_LIVES; gRound = 0; gStreak = 0; gOk = 0;
  gState = G_PLAY;
  gTouchDown = false; g3Prev = true;
  tft.fillScreen(C_BG);
  tft.fillRect(0, PF_TOP, 320, 236 - PF_TOP, G_GRASS);
  drawStripe(236, 4);
  gameDrawHud();
  gameDrawCard("Sentuh tikus yang membawa jawaban benar sebelum waktu habis!", C_INDIGO, 0);
  printCenterShadow("SIAP?", 160, 112, 3, C_CORAL, C_WHITE);
  ttsSpeak("Siap?", true);
  delay(1900);
  game3StartRound();
}

void gameButton(int k) {
  if (screen != S_GAME || gState != G_PLAY) return;
  if (gameKind == 2) {
    game2Jump(k);
    g2Prev = true;
  } else if (gameKind == 3) {
    if (mo[k].h >= 24) {
      bool ok = (k == gq.correct);
      fieldFinish(ok, ok ? String(pickPraise()) : String("Ups! Jawabannya: ") + gq.opt[gq.correct]);
      g3Prev = true;
    }
  } else {
    if (gb[k].active) gTarget = constrain((int)gb[k].x + BAL_W / 2, 36, 284);
  }
}

void drawGame() {
  if (gameKind == 2) drawGame2();
  else if (gameKind == 3) drawGame3();
  else drawGameBalon();
}

void sayLevelIntro() {
  ttsSpeak("Halo! Aku MathBot AI. Pilih tingkat kelasmu dulu ya! Kelas 1 sampai 2 SD, kelas 3 sampai 4 SD, atau kelas 5 sampai 6 SD. Tekan tombol A, B, atau C untuk memilih kelas. Lalu tekan tombol D untuk Mulai Belajar!");
}
void sayHomeIntro() {
  String t = "Pilih topik dengan menyentuh kotak di bawah, atau tekan tombol A, B, C, atau D ya! ";
  for (int i = 0; i < 4; i++) { t += BTN_LTR[i]; t += ", "; t += TOPIC_NAME[i]; t += ". "; }
  t += "Atau pilih Trik dan Rumus, atau Main Game!";
  ttsSpeak(t);
}
void sayGameMenuIntro() {
  String t = "Pilih game seru! Sentuh game-nya, atau tekan tombol A, B, atau C ya! ";
  for (int i = 0; i < 3; i++) { t += BTN_LTR[i]; t += ", "; t += GM_LABEL[i]; t += ". "; }
  ttsSpeak(t);
}

void goTo(Screen s) {
  ttsStop();
  screen = s;
  twList = nullptr;
  fxReset();
  fxIntro = true;
  qActive = false;
  if (s != S_SUMMARY) freeCanvas();
  if (s != S_GAME) gameFree();
  switch (s) {
    case S_LEVEL:   drawLevelScreen(); sayLevelIntro(); break;
    case S_HOME:    drawHome(); sayHomeIntro(); break;
    case S_MATERI:  drawMateri(); break;
    case S_QUIZ:    drawQuiz(); break;
    case S_SUMMARY: drawSummary(); break;
    case S_GAME:    drawGame(); break;
    case S_GMENU:   drawGameMenu(); sayGameMenuIntro(); break;
  }
  fxIntro = false;
}

void prepareQuestion(int idx, uint32_t maxMs) {
#if TTS_ENABLED && TTS_PREFETCH && TTS_CACHE
  if (idx < 0 || idx >= N_Q || ttsQuestionReady(Q[idx], idx + 1) || ttsWifiUnset() || !ttsWifiOK()) return;
  tft.fillScreen(C_BG);
  drawBotOn(tft, 160, 30, 10, 0, 1, 2, 0);
  labelIn("Menyiapkan soal...", 10, 128, 300, 40, C_INDIGO, 18);
  printCenter("Sentuh layar untuk lewati", 160, 215, 1, C_MUTED);
  ttsPreloadQuestion(Q[idx], idx + 1, maxMs);
  uint32_t t2 = millis();
  while (ts.touched() && millis() - t2 < 1500) delay(10);
#endif
}

void startTopic(int topic) {
  int order[BANK_N];
  for (int i = 0; i < BANK_N; i++) order[i] = i + 1;
  for (int i = BANK_N - 1; i > 0; i--) { int j = random(i + 1); int t = order[i]; order[i] = order[j]; order[j] = t; }
  for (int k = 0; k < N_Q; k++) genQuestion(topic, level, order[k], Q[k]);
  qIdx = 0;
  prepareQuestion(0, 8000);
  goTo(S_QUIZ);
}

void waitRelease() {
  uint32_t t = millis();
  while (ts.touched() && millis() - t < 1500) delay(10);
}

void nextQuestion() {
  qIdx++;
  waitRelease();
  ttsWait();
  if (qIdx < N_Q) { prepareQuestion(qIdx, 5000); drawQuiz(); }
  else goTo(S_SUMMARY);
}

void drawExplainCard(const String &txt) {
  const uint16_t BG = RGB(237,233,254);
  tft.fillScreen(BG);
  for (int i = 0; i < 9; i++) drawStar(tft, 10 + i * 38, 237, 3, CONF_COL[i % 8]);

  tft.fillRoundRect(4, 5, 312, 34, 14, shade(C_PURPLE, 150));
  tft.fillRoundRect(4, 2, 312, 34, 14, C_PURPLE);
  tft.fillRoundRect(10, 5, 300, 12, 6, mix565(C_PURPLE, 0xFFFF, 70));
  tft.drawRoundRect(4, 2, 312, 34, 14, C_WHITE);
  tft.fillCircle(25, 19, 14, C_WHITE);
  tft.fillRoundRect(14, 11, 22, 16, 7, C_VISOR);
  tft.fillCircle(20, 18, 2, C_EYE); tft.fillCircle(30, 18, 2, C_EYE);
  tft.drawLine(21, 23, 25, 25, C_EYE); tft.drawLine(25, 25, 29, 23, C_EYE);
  gText(tft, FNT_M, "MathBot Menjelaskan", 172, 27, C_WHITE);
  drawStar(tft, 300, 12, 6, C_SUNY);
  drawStar(tft, 282, 28, 4, C_CELEB);

  String body = txt, ans = "";
  int k = txt.indexOf("Jadi jawaban yang benar adalah ");
  if (k >= 0) {
    body = txt.substring(0, k); body.trim();
    ans = txt.substring(k + 31); ans.trim();
    if (ans.endsWith(".")) ans.remove(ans.length() - 1);
  }
  bool hasAns = ans.length() > 0;
  int bodyTop = 42, bodyBot = hasAns ? 172 : 206;

  String st[8]; int ns = 0, i0 = 0;
  while (i0 < (int)body.length() && ns < 8) {
    int e = body.indexOf(". ", i0);
    String s = (e < 0) ? body.substring(i0) : body.substring(i0, e + 1);
    s.trim();
    if (s.endsWith(".")) s.remove(s.length() - 1);
    if (s.length()) st[ns++] = s;
    if (e < 0) break;
    i0 = e + 2;
  }
  if (ns == 0) { st[0] = body; ns = 1; }

  const GFXfont *fonts[3] = { FNT_M, FNT_S, nullptr };
  const int lhs[3] = { 22, 18, 11 }, asc[3] = { 17, 13, 1 };
  String ln[8][6]; int nl[8];
  int fi = 0;
  for (; fi < 3; fi++) {
    int tot = 0;
    for (int s = 0; s < ns; s++) {
      nl[s] = (fonts[fi] ? wrapFont(fonts[fi], st[s], 262, ln[s], 6) : wrapText(st[s], 262 / 6, ln[s], 6));
      tot += nl[s] * lhs[fi] + 8 + 3;
    }
    if (tot <= bodyBot - bodyTop || fi == 2) break;
  }
  if (fi > 2) fi = 2;

  const uint16_t SBG[5] = { C_LIGHTIND, RGB(254,243,199), C_OKBG, RGB(252,231,243), RGB(224,242,254) };
  const uint16_t SBD[5] = { C_INDIGO, C_ORANGE, C_GREEN, C_PINK, C_SKY };
  int y = bodyTop;
  for (int s = 0; s < ns; s++) {
    int h = nl[s] * lhs[fi] + 8;
    if (y + h > bodyBot + 2) break;
    uint16_t bg = SBG[s % 5], bd = SBD[s % 5];
    tft.fillRoundRect(6, y, 308, h, 9, bg);
    tft.drawRoundRect(6, y, 308, h, 9, bd);
    tft.fillRoundRect(6, y + 3, 5, h - 6, 2, bd);
    int by = y + h / 2;
    tft.fillCircle(25, by, 10, bd);
    tft.drawCircle(25, by, 10, C_WHITE);
    gText(tft, FNT_S, String(s + 1), 25, by + 6, C_WHITE);
    for (int j = 0; j < nl[s]; j++) {
      int ty = y + 4 + j * lhs[fi];
      tft.setFont(fonts[fi]); tft.setTextSize(1); tft.setTextColor(C_INK);
      tft.setCursor(41, ty + asc[fi]);
      tft.print(ln[s][j]);
      tft.setFont();
    }
    y += h + 3;
  }

  if (hasAns) {
    tft.fillRoundRect(6, 178, 308, 32, 14, shade(C_GREEN, 150));
    tft.fillRoundRect(6, 175, 308, 32, 14, C_GREEN);
    tft.fillRoundRect(12, 178, 296, 10, 5, mix565(C_GREEN, 0xFFFF, 70));
    tft.drawRoundRect(6, 175, 308, 32, 14, C_WHITE);
    tft.fillCircle(26, 191, 11, C_WHITE);
    tft.drawLine(20, 191, 25, 196, C_GREEN); tft.drawLine(21, 191, 25, 195, C_GREEN);
    tft.drawLine(25, 196, 33, 185, C_GREEN); tft.drawLine(25, 195, 32, 185, C_GREEN);
    String t = "Jawaban: " + ans;
    labelIn(t, 42, 175, 268, 29, C_WHITE, 12);
  }

  fxPill(66, 211, 188, 21, C_SUNY, "Dengarkan penjelasannya ya!", C_NAVY, 9);
}

void showExplanation(const Question &q, const String &lead) {
  if (lead.length()) { ttsSpeak(lead); ttsWait(5000, false); }
  ttsSpeak(ttsExplainText(q), true);
  drawExplainCard(q.ex);
  uint32_t t0 = millis();
  uint32_t minMs = 2500 + (uint32_t)q.ex.length() * 40;
  ttsWait(90000, false);
  while (millis() - t0 < minMs && !(millis() - t0 > 800 && ts.touched())) delay(20);
}

void handleAnswer(int i) {
  if (locked[i]) return;
  ttsStop();
  Question &q = Q[qIdx];
  if (i == q.correct) {
    qActive = false;
    exp_ += 20;
    sndPlay(SND_OK);
    drawOption(i, 1);
    delay(350);
    celebrate();
    nextQuestion();
  } else {
    attemptsLeft--;
    locked[i] = true;
    sndPlay(SND_WRONG);
    drawOption(i, 2);
    {
      uint32_t a0 = millis();
      wrongAnimation(attemptsLeft <= 0);
      qStart += millis() - a0;
      redrawQuizKeep();
    }
    if (attemptsLeft == 1) {
      drawHint("Petunjuk: " + q.clue, C_INDIGO);
      ttsSpeak("Petunjuk: " + q.clue, true);
    } else {
      qActive = false;
      drawOption(q.correct, 1);
      if (q.ex.length()) {
        delay(700);
        showExplanation(q, "Jawabanmu belum tepat.");
      } else {
        drawHint("Yuk lanjut ke soal berikutnya!", C_ERRTXT);
        ttsSpeak(String("Yuk lanjut ke soal berikutnya! Jawabannya adalah ") + q.opt[q.correct], true);
        delay(1400);
      }
      nextQuestion();
    }
  }
}

void timeUp() {
  qActive = false;
  Question &q = Q[qIdx];
  sndPlay(SND_TIMEUP);
  timeUpAnimation();
  redrawQuizKeep();
  drawTimerBar(0, true);
  tft.fillRoundRect(114, 3, 130, 26, 13, C_RED);
  tft.setTextColor(C_WHITE);
  tft.setTextSize(1); tft.setCursor(124, 12); tft.print("WAKTU");
  tft.setTextSize(2); tft.setCursor(164, 8);  tft.print("HABIS!");
  drawOption(q.correct, 1);
  drawHint("Waktu habis! Jawabannya yang hijau ya.", C_ERRTXT);
  if (q.ex.length()) {
    delay(450);
    showExplanation(q, "Waktu habis!");
  } else {
    ttsSpeak(String("Waktu habis! Jawabannya adalah ") + q.opt[q.correct], true);
    delay(1300);
  }
  nextQuestion();
}

void quizTimerTick() {
  static uint32_t lastT = 0;
  uint32_t nowT = millis();
  if (screen != S_QUIZ || !qActive) { lastT = nowT; return; }

  if (sttBusy || (ttsBusy && nowT - ttsStartMs < TTS_MAX_FREEZE_MS)) {
    qStart += nowT - lastT;
    lastT = nowT;
    return;
  }
  lastT = nowT;
  long rem = (long)Q_TIME_MS - (long)(millis() - qStart);
  if (rem <= 0) {
    drawTimerBar(0);
    if (ttsBusy && nowT - ttsStartMs < TTS_MAX_FREEZE_MS) return;
    timeUp();
    return;
  }
  drawTimerBar(rem);
  int sec = (int)((rem + 999) / 1000);
  if (sec <= WARN_FROM && sec != lastSec) { lastSec = sec; sndPlay(SND_TICK); drawWarning(sec); }
}

void restoreHint() {
  if (attemptsLeft == 1) drawHint("Petunjuk: " + Q[qIdx].clue, C_INDIGO);
  else if (!micOn) drawHint("Mic mati - sentuh ikon mic", C_MUTED);
  else if (micHw == 2) drawHint("Mic tidak terdeteksi - cek kabel", C_ERRTXT);
  else drawHint("Ucapkan: A, B, C, atau D", C_MUTED);
}

void micTick() {
  static uint8_t shown = 0, hwShown = 0, lastBucket = 255;
  static uint32_t shownAt = 0, errSeqShown = 0, errShownAt = 0, meterAt = 0;
  if (screen != S_QUIZ || !qActive) { shown = 0; hwShown = 0; lastBucket = 255; errSeqShown = ttsErrSeq; errShownAt = 0; return; }

  if (ttsErrSeq != errSeqShown) {
    errSeqShown = ttsErrSeq;
    errShownAt = millis();
    drawHint(String("Suara bacaan gagal: ") + ttsErrMsg, C_ERRTXT);
  } else if (errShownAt && millis() - errShownAt > 9000) {
    errShownAt = 0;
    restoreHint();
  }

  if (!micOn) { if (shown) { shown = 0; restoreHint(); } return; }

  if (micHw == 2 && hwShown != 2) { hwShown = 2; if (!errShownAt) restoreHint(); }
  else if (micHw != 2 && hwShown == 2) { hwShown = 0; if (!errShownAt) restoreHint(); }

  uint8_t res = micResult;
  if (res) {
    micResult = 0;
    shown = 0;
    bargeOpen = false;
    if (res >= 1 && res <= 4) handleAnswer(res - 1);
    return;
  }

  if (bargeOpen && !sttBusy && micState != 1 && micState != 2 && (int32_t)(millis() - bargeAt) > BARGE_RESUME_MS) {
    bargeOpen = false;
    if (!bargeUttered) {
      bargeFails = bargeFails + 1;
      Serial.println("BARGE: salah picu (tidak ada ucapan A-D) -> bacaan dilanjutkan, barge-in dimatikan untuk soal ini");
      ttsSpeakQuestion(Q[qIdx], qIdx + 1);
    }
  }
  uint8_t st = micState;
  if (st != shown) {
    shown = st;
    shownAt = millis();
    switch (st) {
      case 1: drawHint("Mendengarkan...", C_INDIGO); break;
      case 2: drawHint("Memproses suaramu...", C_INDIGO); break;
      case 3: drawHint("Belum jelas. Ucapkan A, B, C, atau D ya!", C_ERRTXT); break;
      case 4: drawHint("Suara gagal (cek WiFi/model). Pakai tombol A/B/C/D!", C_ERRTXT); break;
      default: restoreHint(); break;
    }
  }
  if ((shown == 3 || shown == 4) && millis() - shownAt > 2200 && micState == shown) micState = 0;

  if (shown == 0 && micState == 0 && attemptsLeft == 2 && !errShownAt && micHw == 1 && !ttsPlaying && !sndBusy && millis() - meterAt > 180) {
    meterAt = millis();
    float r = micRms;
    uint8_t b = r < 40 ? 0 : r < 80 ? 1 : r < 160 ? 2 : r < 320 ? 3 : r < 640 ? 4 : 5;
    if (b != lastBucket) {
      lastBucket = b;
      String bars = "[";
      for (int i = 0; i < 5; i++) bars += (i < b) ? '|' : ' ';
      bars += "]";
      drawHint(String("Mic ") + bars + " Ucapkan: A, B, C, atau D", b ? C_GREEN : C_MUTED);
    }
  } else if (shown != 0) {
    lastBucket = 255;
  }
}

uint8_t keyAddr = 0;

void buttonsInit() {
  Wire.begin(KEY_SDA, KEY_SCL, 100000);
  Wire.setTimeOut(10);
  const uint8_t cand[16] = { 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
                             0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F };
  for (int i = 0; i < 16 && !keyAddr; i++) {
    Wire.beginTransmission(cand[i]);
    Wire.write(0xFF);
    if (Wire.endTransmission() == 0) keyAddr = cand[i];
  }
  if (keyAddr) Serial.printf("Tombol: PCF8574 ditemukan di 0x%02X\n", keyAddr);
  else Serial.println("Tombol: PCF8574 TIDAK ditemukan (cek SDA=GPIO3, SCL=GPIO46, VCC, GND)");
}

uint8_t keyBits = 0;
bool keyRead() {
  if (!keyAddr) return false;
  if (Wire.requestFrom((int)keyAddr, 1) != 1) return false;
  keyBits = Wire.read();
  return true;
}

void buttonsTick() {
  static bool    stable[5]  = { false, false, false, false, false };
  static bool    last[5]    = { false, false, false, false, false };
  static uint32_t since[5]  = { 0, 0, 0, 0, 0 };
  uint32_t now = millis();
  static uint32_t lastPoll = 0;
  if (now - lastPoll < 5) return;
  lastPoll = now;
  if (!keyRead()) return;
  for (int i = 0; i < 5; i++) {
    bool pressed = !(keyBits & (1 << i));
    if (pressed != last[i]) { last[i] = pressed; since[i] = now; }
    if (now - since[i] < 30 || pressed == stable[i]) continue;
    stable[i] = pressed;
    if (!pressed) continue;
    if (i == 4) {
      if (screen == S_QUIZ) { sndPlay(SND_CLICK); micToggle(); }
      continue;
    }
    if (screen == S_LEVEL) {
      sndPlay(SND_CLICK);
      if (i < 3) { level = i; drawLevelBtns(); ttsSpeak(LEVEL_SAY[i]); }
      else goTo(S_HOME);
    } else if (screen == S_HOME) {
      sndPlay(SND_CLICK);
      startTopic(i);
    } else if (screen == S_GMENU) {
      if (i < 3) { sndPlay(SND_CLICK); gameKind = i + 1; goTo(S_GAME); }
    } else if (screen == S_QUIZ && qActive) {
      sndPlay(SND_CLICK);
      handleAnswer(i);
    } else if (screen == S_GAME && gState == G_PLAY) {
      sndPlay(SND_CLICK);
      gameButton(i);
    } else if (screen == S_GAME && gState == G_OVER) {
      if (i == 0) { sndPlay(SND_CLICK); goTo(S_GAME); }
      else if (i == 1) { sndPlay(SND_CLICK); goTo(S_HOME); }
    }
  }
}

int sumStep = 0;
uint32_t sumT = 0;
void summaryTick() {
  if (screen != S_SUMMARY || millis() - sumT < 160) return;
  sumT = millis();
  sumStep++;
  drawDancer(4, 50, sumStep, false, endBg);
}

void onTouch(int16_t x, int16_t y) {
  switch (screen) {
    case S_LEVEL:
      for (int i = 0; i < 3; i++) if (hit(R_LEVEL[i], x, y)) { level = i; drawLevelBtns(); ttsSpeak(LEVEL_SAY[i]); return; }
      if (hit(R_START, x, y)) goTo(S_HOME);
      break;
    case S_HOME:
      if (hit(R_HOME_BACK, x, y)) { goTo(S_LEVEL); return; }
      for (int i = 0; i < 4; i++) if (hit(R_TOPIC[i], x, y)) { startTopic(i); return; }
      if (hit(R_MATERI, x, y)) { materiPage = 0; goTo(S_MATERI); return; }
      if (hit(R_GAME, x, y)) { goTo(S_GMENU); }
      break;
    case S_MATERI:
      if (hit(R_MAT_PREV, x, y) && materiPage > 0) { materiPage--; drawMateri(); }
      else if (hit(R_MAT_NEXT, x, y) && materiPage < 3) { materiPage++; drawMateri(); }
      else if (hit(R_MAT_MENU, x, y)) goTo(S_HOME);
      break;
    case S_QUIZ:
      if (hit(R_MIC, x, y)) { micToggle(); return; }
      if (hit(R_QUIT, x, y)) { goTo(S_HOME); return; }
      for (int i = 0; i < 4; i++) if (hit(optRect(i), x, y)) { handleAnswer(i); return; }
      break;
    case S_SUMMARY:
      if (hit(R_AGAIN, x, y)) goTo(S_HOME);
      break;
    case S_GMENU:
      if (hit(R_HOME_BACK, x, y)) { goTo(S_HOME); return; }
      for (int i = 0; i < 3; i++) if (hit(R_GM[i], x, y)) { gameKind = i + 1; goTo(S_GAME); return; }
      break;
    case S_GAME:
      if (gState == G_PLAY) {
        if (hit(R_QUIT, x, y)) goTo(S_HOME);
      } else {
        if (hit(R_GAME_AGAIN, x, y)) goTo(S_GAME);
        else if (hit(R_GAME_MENU, x, y)) goTo(S_HOME);
      }
      break;
  }
}

bool readTouch(int16_t &x, int16_t &y) {
  if (!ts.touched()) return false;
  TS_Point p = ts.getPoint();
  if (p.z < TS_MINZ) return false;
#if DEBUG_TOUCH
  Serial.printf("raw x=%d y=%d z=%d\n", p.x, p.y, p.z);
#endif
  x = constrain(map(p.x, TS_MINX, TS_MAXX, 0, 320), 0, 319);
  y = constrain(map(p.y, TS_MINY, TS_MAXY, 0, 240), 0, 239);
  return true;
}

void drawSym(int type, int x, int y, uint16_t c) {
  switch (type) {
    case 0: tft.fillRoundRect(x - 12, y - 4, 24, 8, 3, c); tft.fillRoundRect(x - 4, y - 12, 8, 24, 3, c); break;
    case 1: thickLine(tft, x - 9, y - 9, x + 9, y + 9, c); thickLine(tft, x + 9, y - 9, x - 9, y + 9, c);
            thickLine(tft, x - 9, y - 8, x + 9, y + 10, c); thickLine(tft, x + 9, y - 8, x - 9, y + 10, c); break;
    case 2: tft.fillRoundRect(x - 12, y - 3, 24, 6, 3, c); tft.fillCircle(x, y - 11, 4, c); tft.fillCircle(x, y + 11, 4, c); break;
    case 3: tft.fillRoundRect(x - 13, y - 4, 26, 8, 3, c); break;
    default: gText(tft, FNT_M, "123", x, y + 8, c); break;
  }
}

void splashScreen() {
  fxReset();
  fxFlatBg = RGB(255,248,230);
  fxClouds = false;
  tft.fillScreen(fxFlatBg);
  fxPill(70, 4, 180, 44, C_SUNY, "Haloo!!!", C_NAVY, 18);
  gText(tft, FNT_M, "Saya", 160, 72, C_NAVY);
  const int wa = textW(FNT_L, "MathBot"), wb = textW(FNT_L, "AI"), gap = 10;
  int x0 = 160 - (wa + gap + wb) / 2;
  int ca = x0 + wa / 2, cb = x0 + wa + gap + wb / 2;
  gText(tft, FNT_L, "MathBot", ca + 3, 107, C_NAVY);
  gText(tft, FNT_L, "AI",      cb + 3, 107, C_NAVY);
  gOutline(FNT_L, "MathBot", ca, 104, C_BLUE2, C_WHITE, 2);
  gOutline(FNT_L, "AI",      cb, 104, C_SUNY2, C_WHITE, 2);
  txtB(160, 116, "Yuk, belajar matematika bareng aku!", RGB(51,65,85));

  fxBx = 110; fxBy = 130; fxBw = 100; fxBh = 108; fxBk = 10; fxBdeco = nullptr;
  const int16_t SYM[5][3] = { {36,150,0}, {286,152,1}, {36,206,4}, {286,206,2}, {160,0,3} };
  const uint16_t SYC[5] = { C_BLUE2, C_RED, C_GRN2, C_PUR2, C_ORANGE };
  uint32_t t0 = millis();
  int step = 0;
  sndPlay(SND_OK);
  while (millis() - t0 < 2800) {
    if (ts.touched()) break;
    for (int i = 0; i < 4; i++) {
      int by = SYM[i][1];
      tft.fillRect(SYM[i][0] - 32, by - 22, 64, 44, fxFlatBg);
      drawSym(SYM[i][2], SYM[i][0], by + (int)(sinf(step * 0.55f + i * 1.7f) * 5), SYC[i]);
    }
    fxBStep = step;
    fxBotDraw();
    step++;
    delay(70);
  }
  fxReset();
}

void wifiBootCheck() {
#if TTS_ENABLED
  if (ttsWifiOK()) return;
  const bool unset = ttsWifiUnset();

  if (!unset) {
    tft.fillScreen(C_BG);
    labelIn("Menyambung WiFi...", 10, 60, 300, 44, C_INDIGO, 18);
    String ss = String("\"") + WIFI_SSID + "\"";
    printCenter(ss, 160, 120, ss.length() > 24 ? 1 : 2, C_MUTED);
    printCenter("Sentuh layar untuk lewati", 160, 215, 1, C_MUTED);
    uint32_t t0 = millis();
    while (!ttsWifiOK() && millis() - t0 < (uint32_t)TTS_WIFI_BOOT_WAIT_MS) {
      if (millis() - t0 > 500 && ts.touched()) break;
      delay(100);
    }
    if (ttsWifiOK()) return;
  }

  tft.fillScreen(RGB(254, 242, 242));
  fxPill(20, 6, 280, 40, C_RED, "WiFi belum tersambung", C_WHITE, 12);
  tft.setTextWrap(false);
  tft.setTextSize(2); tft.setTextColor(C_ERRTXT);
  tft.setCursor(10, 58);
  tft.print(unset ? "Nama & password WiFi" : "Tidak bisa tersambung");
  tft.setCursor(10, 78);
  tft.print(unset ? "belum diisi." : "ke WiFi.");

  String body;
  if (unset) body = "Buka src/WifiConfig.h, isi WIFI_SSID dan WIFI_PASS (WiFi 2,4 GHz, bukan 5 GHz), lalu upload ulang.";
  else       body = String("WiFi \"") + WIFI_SSID + "\": " + ttsWifiWhy() + ". Cek juga password, dan dekatkan alat ke router.";
  String ln[6];
  int n = wrapText(body, 48, ln, 6);
  tft.setTextSize(1); tft.setTextColor(C_INK);
  for (int i = 0; i < n; i++) { tft.setCursor(10, 108 + i * 12); tft.print(ln[i]); }

  tft.setTextColor(C_MUTED);
  tft.setCursor(10, 108 + n * 12 + 8);
  tft.print("Tanpa WiFi, soal & penjelasan TIDAK dibacakan.");
  printCenter("Sentuh layar untuk lanjut tanpa suara", 160, 218, 1, C_INDIGO);
  Serial.printf("WiFi: layar peringatan ditampilkan (%s)\n", ttsWifiWhy());

  uint32_t t1 = millis();
  while (millis() - t1 < (uint32_t)TTS_WIFI_NOTICE_MS && !(millis() - t1 > 600 && ts.touched())) {
    if (ttsWifiOK()) break;
    delay(50);
  }
  uint32_t t2 = millis();
  while (ts.touched() && millis() - t2 < 1500) delay(10);
#endif
}

void runMicTest() {
  uint32_t t0 = millis();
  ttsStop();
  micOn = true;
  micClear();
  micTestMode = true;
  micLastEv = 0;
  micState = 0;
  micResult = 0;
  const Rect bk = { 70, 200, 180, 34 };
  uint32_t until = millis() + 1500;
  while (ts.touched() && millis() < until) delay(10);

  tft.fillScreen(C_BG);
  printCenter("TES MIC", 160, 6, 2, C_INDIGO);
  printCenter("Ucapkan A / B / C / D satu per satu, jarak 15-25 cm", 160, 26, 1, C_MUTED);
  tft.drawRoundRect(10, 70, 300, 16, 6, C_MUTED);
  int thrX = 10 + (int)(sqrtf(220.0f / MIC_GAIN) * 295.0f / 55.0f);
  uint8_t lastRes = 0; uint32_t resAt = 0, stAt = 0;
  uint8_t lastSt = 255;
  uint32_t lastDraw = 0;
  int lastW = -1;
  drawBtn(bk, C_CORAL, "KELUAR", C_WHITE, 2);

  for (;;) {
    int16_t x, y;
    if (readTouch(x, y) && hit(bk, x, y)) break;
    uint32_t now = millis();

    if (micResult) { lastRes = micResult; resAt = now; micResult = 0; micState = 0; }
    uint8_t st = micState;
    if ((st == 3 || st == 4)) { if (!stAt) stAt = now; else if (now - stAt > 2200) { micState = 0; stAt = 0; } } else stAt = 0;

    if (now - lastDraw >= 90) {
      lastDraw = now;
      float r = micRms;
      int w = (int)(sqrtf(r) * 295.0f / 55.0f);
      if (w > 295) w = 295;
      if (w != lastW) {
        tft.fillRect(12, 72, 296, 12, C_BG);
        tft.fillRect(12, 72, w, 12, (w >= thrX - 10) ? C_GREEN : C_ORANGE);
        tft.drawFastVLine(thrX, 68, 20, C_RED);
        lastW = w;
      }
      tft.fillRect(0, 40, 320, 26, C_BG);
      tft.setTextSize(2);
      if (micHw == 2) { tft.setTextColor(C_ERRTXT); tft.setCursor(10, 44); tft.print("Mic TIDAK ADA sinyal"); tft.setTextSize(1); tft.setCursor(10, 60); tft.print("Cek kabel SCK/WS/SD, VDD 3V3, pin L/R"); }
      else { tft.setTextColor(C_OKTXT); tft.setCursor(10, 44); tft.print("Mic OK  "); tft.setTextColor(C_MUTED); tft.setTextSize(1); tft.setCursor(130, 50); tft.print("suara "); tft.print((int)r); }
      tft.setTextSize(1); tft.setTextColor(C_MUTED);
      tft.setCursor(thrX - 18, 90); tft.fillRect(0, 90, 320, 10, C_BG); tft.print("batas ucapan (garis merah)");

      tft.fillRect(0, 104, 320, 28, C_BG);
      tft.setTextSize(1); tft.setTextColor(C_INK);
      tft.setCursor(10, 106); tft.print("Penyaring: ");
      if (!micLastEv) { tft.setTextColor(C_MUTED); tft.print("belum ada ucapan"); }
      else if (micLastEv == 1) { tft.setTextColor(C_OKTXT); tft.print("ucapan lolos, "); tft.print((int)micLastUttMs); tft.print(" ms"); }
      else { tft.setTextColor(C_ERRTXT); tft.print("ditolak: harus 110-900 ms, jangan ngobrol panjang"); }

      tft.fillRect(0, 124, 320, 70, C_BG);
      tft.setTextSize(2);
      if (lastRes && now - resAt < 4000) {
        tft.setTextColor(C_OKTXT); tft.setCursor(10, 134); tft.print("Terdengar: ");
        tft.setTextSize(3); tft.print((char)('A' + lastRes - 1));
      } else if (st == 1) { tft.setTextColor(C_INDIGO); tft.setCursor(10, 140); tft.print("Mendengarkan..."); }
      else if (st == 2) { tft.setTextColor(C_INDIGO); tft.setCursor(10, 140); tft.print("Memproses..."); }
      else if (st == 3) { tft.setTextColor(C_ERRTXT); tft.setCursor(10, 130); tft.print("Tidak dikenali"); tft.setTextSize(1); tft.setCursor(10, 150); tft.print("Suara terdengar tapi model ragu (< batas yakin). Ulangi lebih jelas / dekat."); }
      else if (st == 4) { tft.setTextColor(C_ERRTXT); tft.setCursor(10, 130); tft.print("Pengenal GAGAL"); tft.setTextSize(1); tft.setCursor(10, 150); tft.print("Cek model / WiFi + token (lihat Serial Monitor)."); }
      else { tft.setTextColor(C_MUTED); tft.setCursor(10, 140); tft.print("Silakan bicara"); }
      lastSt = st;
    }
    delay(15);
  }
  micTestMode = false;
  micOn = true;
  micClear();
  while (ts.touched()) delay(10);
  qStart += millis() - t0;
  redrawQuizKeep();
  restoreHint();
  drawMicBtn();
}

void micBootCheck() {
#if STT_ENABLED && STT_MODE != 3
  uint32_t t0 = millis();
  while (millis() - t0 < 8500) {
    if (micHw == 2) break;
    if ((int32_t)(millis() - micLastLive) < 400) return;
    delay(50);
  }
  if (micHw != 2) return;
  tft.fillScreen(RGB(254, 242, 242));
  fxPill(20, 6, 280, 40, C_RED, "Mic tidak terdeteksi", C_WHITE, 12);
  tft.setTextWrap(false);
  String ln[6];
  int n = wrapText("Mikrofon INMP441 tidak mengirim sinyal. Cek kabel: VDD ke 3V3, GND, SCK ke GPIO4, WS ke GPIO5, SD ke GPIO13, pin L/R ke GND (atau ke 3V3). Cek juga solderan pin. Alat mencoba kanal KIRI & KANAN otomatis.", 48, ln, 6);
  tft.setTextSize(1); tft.setTextColor(C_INK);
  for (int i = 0; i < n; i++) { tft.setCursor(10, 60 + i * 12); tft.print(ln[i]); }
  tft.setTextColor(C_MUTED);
  tft.setCursor(10, 60 + n * 12 + 8);
  tft.print("Tanpa mic, jawab pakai tombol A/B/C/D atau sentuh layar.");
  printCenter("Sentuh layar untuk lanjut", 160, 218, 1, C_INDIGO);
  Serial.println("Mic: layar peringatan ditampilkan (tidak ada sinyal dari INMP441)");
  uint32_t t1 = millis();
  while (millis() - t1 < 12000 && !(millis() - t1 > 600 && ts.touched())) {
    if (micHw == 1) break;
    delay(50);
  }
  uint32_t t2 = millis();
  while (ts.touched() && millis() - t2 < 1500) delay(10);
#endif
}

void setup() {
  Serial.begin(115200);
#if STT_ENABLED && STT_MODE == 3
  Serial.updateBaudRate(REC_BAUD);
#endif
  randomSeed(esp_random());

  SPI.begin(TFT_SCK, -1, TFT_MOSI, TFT_CS);
  tft.begin(10000000);
  tft.setRotation(1);
  tft.setTextWrap(false);

  touchSPI.begin(T_CLK, T_DO, T_DIN, T_CS);
  ts.begin(touchSPI);
  ts.setRotation(3);

  micInit();
  sndInit();
  ttsInit();
  buttonsInit();
  Serial.printf("RAM bebas setelah semua modul siap: %u byte (blok terbesar %u) | PSRAM: %s (%u byte)\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMaxAllocHeap(), psramFound() ? "aktif" : "TIDAK aktif", (unsigned)ESP.getPsramSize());

  splashScreen();
  wifiBootCheck();
  micBootCheck();
  goTo(S_LEVEL);
}

void loop() {
  static bool wasDown = false;
  static uint32_t lastTap = 0;
  int16_t x, y;
  bool down = readTouch(x, y);
  gTouchDown = down;
  if (down) { gTouchX = x; gTouchY = y; }
  if (down && !wasDown && millis() - lastTap > 150) {
    lastTap = millis();
    sndPlay(SND_CLICK);
    onTouch(x, y);
  }
  wasDown = down;
  {
    static uint32_t micHoldAt = 0;
    if (screen == S_QUIZ && qActive && down && hit(R_MIC, x, y)) {
      if (!micHoldAt) micHoldAt = millis();
      else if (millis() - micHoldAt > 1400) { micHoldAt = 0; runMicTest(); wasDown = true; }
    } else micHoldAt = 0;
  }
  quizTimerTick();
  micTick();
  buttonsTick();
  twinkleTick();
  fxTick();
  summaryTick();
  gameTick();
  delay(10);
}
